<?php
require_once __DIR__ . '/../config/session.php';
require_login();
if (!has_role('Admin')) json_response(['success' => false, 'message' => 'Access denied.'], 403);

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) json_response(['success' => false, 'message' => 'Invalid request data.'], 400);

$action = $data['action'] ?? '';
$type   = $data['type']   ?? 'classroom';

try {
    if ($type === 'seats') {

        if ($action === 'add') {
            if (empty($data['grade_level_id']) || !isset($data['available_seats']) || $data['available_seats'] === '') {
                json_response(['success' => false, 'message' => 'Grade level and available seats are required.'], 400);
            }
            $strandId = ($data['strand_id'] !== '' && $data['strand_id'] !== null) ? (int)$data['strand_id'] : null;
            $s = $pdo->prepare("INSERT INTO seats_data (grade_level_id, strand_id, available_seats, school_year) VALUES (?, ?, ?, ?)");
            $s->execute([(int)$data['grade_level_id'], $strandId, (int)$data['available_seats'], clean($data['school_year'] ?? '')]);
            log_activity($pdo, current_user_id(), "Added seats record", 'Facilities');
            json_response(['success' => true, 'message' => 'Seats record added successfully.']);

        } elseif ($action === 'edit') {
            if (empty($data['id'])) json_response(['success' => false, 'message' => 'Missing record ID.'], 400);
            $strandId = ($data['strand_id'] !== '' && $data['strand_id'] !== null) ? (int)$data['strand_id'] : null;
            $s = $pdo->prepare("UPDATE seats_data SET grade_level_id=?, strand_id=?, available_seats=?, school_year=? WHERE id=?");
            $s->execute([(int)$data['grade_level_id'], $strandId, (int)$data['available_seats'], clean($data['school_year'] ?? ''), (int)$data['id']]);
            log_activity($pdo, current_user_id(), "Updated seats record ID:{$data['id']}", 'Facilities');
            json_response(['success' => true, 'message' => 'Seats record updated successfully.']);
        }

    } else {
        // ── Classroom ──────────────────────────────────────────────

        if ($action === 'add') {
            if (empty($data['room_code'])) json_response(['success' => false, 'message' => 'Room Code is required.'], 400);
            if (empty($data['length_m']) || (float)$data['length_m'] <= 0) json_response(['success' => false, 'message' => 'Length must be greater than 0.'], 400);
            if (empty($data['width_m'])  || (float)$data['width_m']  <= 0) json_response(['success' => false, 'message' => 'Width must be greater than 0.'], 400);

            $s = $pdo->prepare("INSERT INTO classrooms (room_code, length_m, width_m, is_functional, notes) VALUES (?, ?, ?, ?, ?)");
            $s->execute([
                clean($data['room_code']),
                (float)$data['length_m'],
                (float)$data['width_m'],
                (int)($data['is_functional'] ?? 1),
                clean($data['notes'] ?? '')
            ]);
            log_activity($pdo, current_user_id(), "Added classroom: " . clean($data['room_code']), 'Facilities');
            json_response(['success' => true, 'message' => 'Classroom "' . clean($data['room_code']) . '" added successfully.']);

        } elseif ($action === 'edit') {
            if (empty($data['id'])) json_response(['success' => false, 'message' => 'Missing classroom ID.'], 400);

            $s = $pdo->prepare("UPDATE classrooms SET room_code=?, length_m=?, width_m=?, is_functional=?, notes=? WHERE id=?");
            $s->execute([
                clean($data['room_code'] ?? ''),
                (float)$data['length_m'],
                (float)$data['width_m'],
                (int)($data['is_functional'] ?? 1),
                clean($data['notes'] ?? ''),
                (int)$data['id']
            ]);
            log_activity($pdo, current_user_id(), "Updated classroom ID:{$data['id']}", 'Facilities');
            json_response(['success' => true, 'message' => 'Classroom updated successfully.']);
        }
    }

    json_response(['success' => false, 'message' => 'Unknown action: "' . $action . '"'], 400);

} catch (PDOException $e) {
    $msg = $e->getMessage();
    if (strpos($msg, 'Duplicate') !== false) {
        json_response(['success' => false, 'message' => 'A classroom with that Room Code already exists. Please use a different code.'], 409);
    }
    json_response(['success' => false, 'message' => 'Database error: ' . $msg], 500);
}
