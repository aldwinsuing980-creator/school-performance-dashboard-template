<?php
// approvals.php
require_once __DIR__ . '/config/session.php';
require_login();

// Restrict page to Admin role only
if (!has_role('Admin')) {
    $page_title = 'Access Denied';
    $breadcrumb = 'User Approvals';
    include 'includes/header.php';
    echo '<div class="d-flex align-items-center justify-content-center" style="min-height:50vh;">
      <div class="text-center">
        <div style="font-size:4rem;margin-bottom:1rem;">🔒</div>
        <h2 class="fw-700 text-dark mb-2">Access Denied</h2>
        <p class="text-muted mb-3">You need <strong>Admin</strong> privilege to access User Approvals.</p>
        <a href="index.php" class="btn-primary-nhs"><i class="bi bi-arrow-left me-1"></i> Back to Dashboard</a>
      </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

$page_title = 'User Approvals & Account Control';
$breadcrumb = 'User Approvals';

// Fetch users
$pending_users = $pdo->query("SELECT * FROM users WHERE status = 'Pending' ORDER BY created_at DESC")->fetchAll();
$active_users  = $pdo->query("SELECT * FROM users WHERE status = 'Approved' ORDER BY role, username")->fetchAll();

// Counts for KPI Cards
$count_pending = count($pending_users);
$count_admins  = count(array_filter($active_users, fn($u) => $u['role'] === 'Admin'));
$count_viewers = count(array_filter($active_users, fn($u) => $u['role'] === 'Viewer'));
$count_encoders = count(array_filter($active_users, fn($u) => $u['role'] === 'Encoder'));

include 'includes/header.php';
?>

<div class="container-fluid py-2">
    <!-- Header -->
    <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
        <div class="section-header mb-0">
            <h1 class="section-title"><i class="bi bi-person-check-fill me-2 text-primary-nhs"></i>Account Access & Approvals</h1>
            <p class="section-sub">Approve newly registered personnel, manage roles, and review audit accesses.</p>
        </div>
        <a href="dashboard.php" class="btn-primary-nhs text-white text-decoration-none">
            <i class="bi bi-speedometer2 me-1"></i> Dashboard Overview
        </a>
    </div>

    <!-- KPI Metrics Row -->
    <div class="row g-3 mb-4">
        <div class="col-md-4 col-sm-6">
            <div class="kpi-card <?= $count_pending > 0 ? 'kpi-warn shadow-sm' : 'kpi-info' ?>" style="border-radius: 16px;">
                <div class="d-flex align-items-center gap-3">
                    <div class="kpi-icon <?= $count_pending > 0 ? 'yellow' : 'navy' ?>">
                        <i class="bi bi-person-exclamation fs-4"></i>
                    </div>
                    <div>
                        <div class="kpi-label">Pending Approval</div>
                        <div class="kpi-value text-dark"><?= $count_pending ?></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class="kpi-card kpi-info" style="border-radius: 16px;">
                <div class="d-flex align-items-center gap-3">
                    <div class="kpi-icon navy">
                        <i class="bi bi-shield-lock-fill fs-4"></i>
                    </div>
                    <div>
                        <div class="kpi-label">Active Administrators</div>
                        <div class="kpi-value text-dark"><?= $count_admins ?></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div class="kpi-card kpi-info" style="border-radius: 16px;">
                <div class="d-flex align-items-center gap-3">
                    <div class="kpi-icon teal">
                        <i class="bi bi-people-fill fs-4"></i>
                    </div>
                    <div>
                        <div class="kpi-label">Active Viewers</div>
                        <div class="kpi-value text-dark"><?= $count_viewers ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabs Container -->
    <ul class="nav nav-pills mb-4" id="approvalTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active position-relative px-4 py-2.5 fw-600" id="pending-tab" data-bs-toggle="pill" data-bs-target="#pending" type="button" role="tab">
                <i class="bi bi-clock-history me-2"></i>Pending Requests
                <?php if ($count_pending > 0): ?>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger shadow-sm border border-white" style="font-size: 0.72rem; padding: 0.35em 0.65em;">
                        <?= $count_pending ?>
                    </span>
                <?php endif; ?>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link px-4 py-2.5 fw-600" id="active-tab" data-bs-toggle="pill" data-bs-target="#active" type="button" role="tab">
                <i class="bi bi-person-check me-2"></i>Active Accounts
            </button>
        </li>
    </ul>

    <!-- Tabs Content -->
    <div class="tab-content" id="approvalTabsContent">
        <!-- PENDING REQUESTS PANEL -->
        <div class="tab-pane fade show active" id="pending" role="tabpanel">
            <div class="data-card shadow-sm border" style="border-radius: 16px; overflow: hidden;">
                <div class="data-card-header bg-light py-3 border-bottom d-flex align-items-center justify-content-between">
                    <span class="data-card-title fw-bold mb-0 text-dark"><i class="bi bi-person-plus-fill me-2 text-warning"></i>Access Access Registrants</span>
                    <span class="badge bg-warning text-dark fw-600 small"><?= $count_pending ?> Pending Review</span>
                </div>
                
                <?php if (empty($pending_users)): ?>
                    <div class="p-5 text-center text-muted">
                        <div style="font-size: 3rem;" class="mb-3">🎉</div>
                        <h5 class="fw-700 text-dark mb-1">Clean Slate!</h5>
                        <p class="mb-0 text-muted small">Walang nakabinbing hiling sa pag-access sa ngayon.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="nhs-table align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Full Name</th>
                                    <th>Username</th>
                                    <th>Email Address</th>
                                    <th>Requested Role</th>
                                    <th>Registration Date</th>
                                    <th class="text-center" style="width: 200px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pending_users as $user): ?>
                                    <tr id="row-pending-<?= $user['id'] ?>">
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="avatar-sm shadow-sm" style="background-color: #fef3c7; color: #d97706; font-weight: 700; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.85rem;">
                                                    <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                                                </div>
                                                <div class="fw-600 text-dark"><?= htmlspecialchars($user['full_name']) ?></div>
                                            </div>
                                        </td>
                                        <td><code>@<?= htmlspecialchars($user['username']) ?></code></td>
                                        <td class="text-muted"><?= htmlspecialchars($user['email'] ?? 'No email') ?></td>
                                        <td>
                                            <span class="badge <?= $user['role'] === 'Admin' ? 'bg-danger-subtle text-danger' : 'bg-info-subtle text-info' ?> fw-600">
                                                <i class="bi <?= $user['role'] === 'Admin' ? 'bi-shield-fill-check' : 'bi-eye-fill' ?> me-1"></i>
                                                <?= htmlspecialchars($user['role']) ?>
                                            </span>
                                        </td>
                                        <td class="text-muted small"><?= date('M d, Y h:i A', strtotime($user['created_at'])) ?></td>
                                        <td>
                                            <div class="d-flex justify-content-center gap-2">
                                                <button class="btn btn-sm btn-success px-3 d-inline-flex align-items-center gap-1 shadow-sm fw-600" style="border-radius: 8px;" onclick="approveUser(<?= $user['id'] ?>, '<?= htmlspecialchars($user['full_name']) ?>')">
                                                    <i class="bi bi-check-lg"></i> Approve
                                                </button>
                                                <button class="btn btn-sm btn-outline-danger px-2 d-inline-flex align-items-center gap-1" style="border-radius: 8px;" onclick="deleteUser(<?= $user['id'] ?>, '<?= htmlspecialchars($user['full_name']) ?>', true)">
                                                    <i class="bi bi-x-circle"></i> Deny
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ACTIVE ACCOUNTS PANEL -->
        <div class="tab-pane fade" id="active" role="tabpanel">
            <div class="data-card shadow-sm border" style="border-radius: 16px; overflow: hidden;">
                <div class="data-card-header bg-light py-3 border-bottom d-flex align-items-center justify-content-between">
                    <span class="data-card-title fw-bold mb-0 text-dark"><i class="bi bi-person-check-fill me-2 text-success"></i>System Approved Personnel</span>
                    <span class="badge bg-success text-white fw-600 small"><?= count($active_users) ?> Active Members</span>
                </div>
                
                <div class="table-responsive">
                    <table class="nhs-table align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th style="width: 180px;">Role Assignment</th>
                                <th>Status</th>
                                <th class="text-center" style="width: 120px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($active_users as $user): 
                                $is_self = ($user['id'] === (int)$_SESSION['user_id']);
                            ?>
                                <tr id="row-active-<?= $user['id'] ?>">
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="avatar-sm shadow-sm" style="background-color: #d1fae5; color: #059669; font-weight: 700; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.85rem;">
                                                <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                                            </div>
                                            <div>
                                                <div class="fw-600 text-dark"><?= htmlspecialchars($user['full_name']) ?></div>
                                                <?php if ($is_self): ?>
                                                    <span class="badge bg-primary-subtle text-primary" style="font-size: 0.65rem;">IKAW (You)</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td><code>@<?= htmlspecialchars($user['username']) ?></code></td>
                                    <td class="text-muted small"><?= htmlspecialchars($user['email'] ?? '—') ?></td>
                                    <td>
                                        <?php if ($is_self): ?>
                                            <span class="badge bg-danger px-3 py-1.5 fw-600" style="border-radius: 8px;">
                                                <i class="bi bi-shield-fill-check me-1"></i>Administrator
                                            </span>
                                            <select class="form-select form-select-sm fw-600" style="border-radius: 8px; border-color: #cbd5e1;" onchange="updateUserRole(<?= $user['id'] ?>, this.value, '<?= htmlspecialchars($user['full_name']) ?>')">
                                                <option value="Student" <?= $user['role'] === 'Student' ? 'selected' : '' ?>>Student</option>
                                                <option value="Faculty" <?= $user['role'] === 'Faculty' ? 'selected' : '' ?>>Faculty</option>
                                                <option value="Admin" <?= $user['role'] === 'Admin' ? 'selected' : '' ?>>Admin</option>
                                                <option value="Viewer" <?= $user['role'] === 'Viewer' ? 'selected' : '' ?>>Viewer (Legacy)</option>
                                            </select>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="kpi-badge badge-good">Approved</span>
                                    </td>
                                    <td class="text-center">
                                        <?php if ($is_self): ?>
                                            <button class="btn btn-sm btn-outline-secondary px-2 border-0" disabled title="Cannot delete your own account">
                                                <i class="bi bi-trash-fill text-muted"></i> Locked
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-outline-danger px-2 border-0" style="border-radius: 8px;" onclick="deleteUser(<?= $user['id'] ?>, '<?= htmlspecialchars($user['full_name']) ?>', false)" title="Revoke access & Delete account">
                                                <i class="bi bi-trash-fill"></i> Remove
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
/**
 * Approve pending user account access
 */
function approveUser(id, name) {
    Swal.fire({
        title: 'Approve Account?',
        html: `Sigurado ka bang nais mong aprubahan ang access ni <strong>${name}</strong> sa dashboard?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#10b981',
        cancelButtonColor: '#6c757d',
        confirmButtonText: '<i class="bi bi-check-lg me-1"></i> Approve Access',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showSpinner();
            fetch('ajax/approve_user.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: id })
            })
            .then(r => r.json())
            .then(res => {
                hideSpinner();
                if (res.success) {
                    toastSuccess(res.message);
                    // Fade out & remove row
                    const row = document.getElementById('row-pending-' + id);
                    if (row) {
                        row.style.transition = 'opacity 0.5s ease';
                        row.style.opacity = '0';
                        setTimeout(() => {
                            location.reload(); // Reload to refresh metrics and lists accurately
                        }, 600);
                    }
                } else {
                    toastError(res.message || 'Approval failed.');
                }
            })
            .catch(() => {
                hideSpinner();
                toastError('Network error occurred.');
            });
        }
    });
}

/**
 * Update active user account role
 */
function updateUserRole(id, newRole, name) {
    showSpinner();
    fetch('ajax/user_crud.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update_role', id: id, role: newRole })
    })
    .then(r => r.json())
    .then(res => {
        hideSpinner();
        if (res.success) {
            toastSuccess(`Role updated! ${name} is now a ${newRole}.`);
        } else {
            toastError(res.message || 'Failed to update role.');
            setTimeout(() => location.reload(), 1000);
        }
    })
    .catch(() => {
        hideSpinner();
        toastError('Network request failed.');
    });
}

/**
 * Delete a user account (deny pending request or remove active member)
 */
function deleteUser(id, name, isPending = false) {
    const titleText = isPending ? 'Reject Registration Request?' : 'Delete User Account?';
    const bodyText = isPending 
        ? `Nais mo bang tanggihan ang hiling sa pag-access ni <strong>${name}</strong>? Ang account na ito ay ganap na mabubura.`
        : `Sigurado ka bang nais mong tanggalin si <strong>${name}</strong>? Siya ay hindi na makakapag-log in at mawawalan ng access sa analytics.`;
        
    Swal.fire({
        title: titleText,
        html: bodyText,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc2626',
        cancelButtonColor: '#6c757d',
        confirmButtonText: isPending ? '<i class="bi bi-trash3-fill me-1"></i> Deny & Delete' : '<i class="bi bi-trash3-fill me-1"></i> Delete Permanent',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showSpinner();
            fetch('ajax/user_crud.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'delete', id: id })
            })
            .then(r => r.json())
            .then(res => {
                hideSpinner();
                if (res.success) {
                    toastSuccess(res.message);
                    const rowId = isPending ? 'row-pending-' + id : 'row-active-' + id;
                    const row = document.getElementById(rowId);
                    if (row) {
                        row.style.transition = 'opacity 0.5s ease';
                        row.style.opacity = '0';
                        setTimeout(() => {
                            location.reload();
                        }, 600);
                    }
                } else {
                    toastError(res.message || 'Operation failed.');
                }
            })
            .catch(() => {
                hideSpinner();
                toastError('Request timed out or endpoint is offline.');
            });
        }
    });
}
</script>

<?php include 'includes/footer.php'; ?>
