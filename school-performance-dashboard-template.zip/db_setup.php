<?php
/**
 * Natividad Academy Dashboard - Database Auto-Setup Script
 * Run this once by opening http://localhost/natividad/db_setup.php in your browser
 */

header('Content-Type: text/html; charset=utf-8');

// 1. Connection settings (default XAMPP credentials)
$host = "localhost";
$username = "root";
$password = "";

echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Database Auto-Setup - Natividad Academy</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #0f172a; color: #f8fafc; padding: 2rem; margin: 0; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .setup-card { background-color: #1e293b; border: 1px solid #334155; border-radius: 16px; padding: 2.5rem; max-width: 600px; width: 100%; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.3); }
        h1 { font-size: 1.75rem; margin-top: 0; color: #3b82f6; border-bottom: 2px solid #334155; padding-bottom: 1rem; }
        .log-box { background-color: #020617; border-radius: 8px; padding: 1rem; font-family: monospace; font-size: 0.9rem; max-height: 250px; overflow-y: auto; border: 1px solid #334155; margin: 1.5rem 0; line-height: 1.5; color: #38bdf8; }
        .success-btn { display: inline-block; background-color: #10b981; color: white; padding: 0.75rem 1.5rem; text-decoration: none; border-radius: 8px; font-weight: 600; text-align: center; width: 100%; box-sizing: border-box; transition: background-color 0.2s; }
        .success-btn:hover { background-color: #059669; }
        .status-success { color: #10b981; font-weight: bold; }
        .status-error { color: #f43f5e; font-weight: bold; }
    </style>
</head>
<body>
<div class='setup-card'>
    <h1>🗄️ Database Setup Wizard</h1>
    <p>Initializing database and tables for the Natividad Academy School Profile Dashboard...</p>
    <div class='log-box'>";

// 2. Establish baseline MySQL Connection (using robust error trapping)
try {
    $conn = @new mysqli($host, $username, $password);
    if ($conn->connect_error) {
        throw new mysqli_sql_exception($conn->connect_error);
    }
} catch (mysqli_sql_exception $e) {
    echo "<span class='status-error'>[DATABASE CONNECTION REFUSED]</span><br><br>";
    echo "<strong style='color: #f43f5e;'>Why is this happening?</strong><br>";
    echo "This means PHP cannot connect to your local MySQL database because it is turned off.<br><br>";
    echo "<strong style='color: #3b82f6;'>How to resolve this right now:</strong><br>";
    echo "1. Open your <strong>XAMPP Control Panel</strong>.<br>";
    echo "2. Look at the <strong>MySQL</strong> module row.<br>";
    echo "3. Click the <strong>Start</strong> button next to 'MySQL' so the box turns green.<br>";
    echo "4. Refresh this page to run the Setup Wizard successfully!<br><br>";
    echo "<em>Technical details: " . htmlspecialchars($e->getMessage()) . "</em>";
    echo "</div></div></body></html>";
    exit();
}
echo "[SUCCESS] Connected to MySQL Server successfully.<br>";

// 3. Create Database
$db_name = "natividad_db";
$sql = "CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if ($conn->query($sql) === TRUE) {
    echo "[SUCCESS] Database `$db_name` checked/created.<br>";
} else {
    echo "<span class='status-error'>[ERROR]</span> Error creating database: " . $conn->error . "<br></div></div></body></html>";
    $conn->close();
    exit();
}

// 4. Select Database
$conn->select_db($db_name);

// 5. Create Tables
$tables = [
    "student_cohorts" => "CREATE TABLE IF NOT EXISTS `student_cohorts` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `cohort_key` VARCHAR(50) NOT NULL,
        `cohort_name` VARCHAR(100) NOT NULL,
        `start_year` INT NOT NULL,
        `base_size` INT NOT NULL,
        `subgroup` VARCHAR(50) NOT NULL DEFAULT 'all',
        `g7_rate` FLOAT NOT NULL,
        `g8_rate` FLOAT NOT NULL,
        `g9_rate` FLOAT NOT NULL,
        `g10_rate` FLOAT NOT NULL,
        `g11_rate` FLOAT NOT NULL,
        `g12_rate` FLOAT NOT NULL,
        UNIQUE KEY `cohort_subgroup` (`cohort_key`, `subgroup`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
    
    "historical_matrix" => "CREATE TABLE IF NOT EXISTS `historical_matrix` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `cohort_name` VARCHAR(100) NOT NULL UNIQUE,
        `size` INT NOT NULL,
        `g7_rate` FLOAT NOT NULL,
        `g8_rate` FLOAT NOT NULL,
        `g9_rate` FLOAT NOT NULL,
        `g10_rate` FLOAT NOT NULL,
        `g11_rate` FLOAT NOT NULL,
        `g12_rate` FLOAT NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

    "teacher_cohorts" => "CREATE TABLE IF NOT EXISTS `teacher_cohorts` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `label` VARCHAR(100) NOT NULL UNIQUE,
        `y1_rate` FLOAT NOT NULL,
        `y2_rate` FLOAT NOT NULL,
        `y3_rate` FLOAT NOT NULL,
        `y4_rate` FLOAT NOT NULL,
        `y5_rate` FLOAT NOT NULL,
        `border_color` VARCHAR(20) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

    "enrollment_history" => "CREATE TABLE IF NOT EXISTS `enrollment_history` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `year` VARCHAR(20) NOT NULL UNIQUE,
        `jhs_count` INT NOT NULL,
        `shs_count` INT NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
];

foreach ($tables as $name => $sql) {
    if ($conn->query($sql) === TRUE) {
        echo "[SUCCESS] Table `$name` checked/created.<br>";
    } else {
        echo "<span class='status-error'>[ERROR]</span> Error creating table `$name`: " . $conn->error . "<br>";
    }
}

// 6. Seed/Populate Data (Insert if empty)

// A. Seed student cohorts
$check_cohorts = $conn->query("SELECT COUNT(*) as count FROM `student_cohorts`")->fetch_assoc();
if ($check_cohorts['count'] == 0) {
    $cohorts_seed = [
        // Class of 2026
        ['class_2026', 'Class of 2026', 2020, 520, 'all', 100, 96.5, 93.8, 91.2, 89.2, 87.5],
        ['class_2026', 'Class of 2026', 2020, 520, 'low_income', 100, 92.4, 88.1, 84.8, 80.2, 78.4],
        ['class_2026', 'Class of 2026', 2020, 520, 'ell', 100, 90.5, 85.2, 81.0, 77.5, 75.2],
        ['class_2026', 'Class of 2026', 2020, 520, 'sped', 100, 93.5, 89.8, 86.2, 82.5, 81.1],
        // Class of 2025
        ['class_2025', 'Class of 2025', 2019, 480, 'all', 100, 95.8, 92.5, 90.0, 88.5, 86.8],
        ['class_2025', 'Class of 2025', 2019, 480, 'low_income', 100, 91.8, 87.2, 83.5, 79.8, 77.2],
        ['class_2025', 'Class of 2025', 2019, 480, 'ell', 100, 89.2, 84.1, 80.5, 76.2, 74.5],
        ['class_2025', 'Class of 2025', 2019, 480, 'sped', 100, 92.1, 88.5, 85.0, 81.2, 79.5],
        // Class of 2024
        ['class_2024', 'Class of 2024', 2018, 450, 'all', 100, 94.2, 91.5, 88.4, 86.2, 84.1],
        ['class_2024', 'Class of 2024', 2018, 450, 'low_income', 100, 89.5, 85.1, 81.2, 77.8, 75.0],
        ['class_2024', 'Class of 2024', 2018, 450, 'ell', 100, 87.6, 82.0, 78.1, 74.0, 71.8],
        ['class_2024', 'Class of 2024', 2018, 450, 'sped', 100, 90.5, 86.2, 82.4, 79.0, 77.2]
    ];
    
    $stmt = $conn->prepare("INSERT INTO `student_cohorts` (`cohort_key`, `cohort_name`, `start_year`, `base_size`, `subgroup`, `g7_rate`, `g8_rate`, `g9_rate`, `g10_rate`, `g11_rate`, `g12_rate`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($cohorts_seed as $row) {
        $stmt->bind_param("ssiisdddddd", $row[0], $row[1], $row[2], $row[3], $row[4], $row[5], $row[6], $row[7], $row[8], $row[9], $row[10]);
        $stmt->execute();
    }
    echo "[SEED] Inserted student cohort progression records.<br>";
}

// B. Seed historical matrices
$check_matrix = $conn->query("SELECT COUNT(*) as count FROM `historical_matrix`")->fetch_assoc();
if ($check_matrix['count'] == 0) {
    $matrix_seed = [
        ["Class of 2021", 410, 100, 93.2, 89.5, 85.4, 82.1, 80.5],
        ["Class of 2022", 430, 100, 93.8, 90.2, 86.8, 83.9, 81.8],
        ["Class of 2023", 440, 100, 94.1, 91.0, 87.5, 84.8, 83.2],
        ["Class of 2024", 450, 100, 94.2, 91.5, 88.4, 86.2, 84.1],
        ["Class of 2025", 480, 100, 95.8, 92.5, 90.0, 88.5, 86.8],
        ["Class of 2026", 520, 100, 96.5, 93.8, 91.2, 89.2, 87.5]
    ];
    
    $stmt = $conn->prepare("INSERT INTO `historical_matrix` (`cohort_name`, `size`, `g7_rate`, `g8_rate`, `g9_rate`, `g10_rate`, `g11_rate`, `g12_rate`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($matrix_seed as $row) {
        $stmt->bind_param("sidddddd", $row[0], $row[1], $row[2], $row[3], $row[4], $row[5], $row[6], $row[7]);
        $stmt->execute();
    }
    echo "[SEED] Inserted historical progression matrix heatmap records.<br>";
}

// C. Seed teacher cohorts
$check_teachers = $conn->query("SELECT COUNT(*) as count FROM `teacher_cohorts`")->fetch_assoc();
if ($check_teachers['count'] == 0) {
    $teachers_seed = [
        ["2021 Hires (n=18)", 100, 94.4, 88.9, 83.3, 83.3, "#3b82f6"],
        ["2022 Hires (n=20)", 100, 95.0, 90.0, 85.0, 80.0, "#10b981"],
        ["2023 Hires (n=15)", 100, 86.7, 80.0, 73.3, 73.3, "#fbbf24"]
    ];
    
    $stmt = $conn->prepare("INSERT INTO `teacher_cohorts` (`label`, `y1_rate`, `y2_rate`, `y3_rate`, `y4_rate`, `y5_rate`, `border_color`) VALUES (?, ?, ?, ?, ?, ?, ?)");
    foreach ($teachers_seed as $row) {
        $stmt->bind_param("sddddds", $row[0], $row[1], $row[2], $row[3], $row[4], $row[5], $row[6]);
        $stmt->execute();
    }
    echo "[SEED] Inserted faculty longevity records.<br>";
}

// D. Seed enrollment history
$check_enrollment = $conn->query("SELECT COUNT(*) as count FROM `enrollment_history`")->fetch_assoc();
if ($check_enrollment['count'] == 0) {
    $enrollment_seed = [
        ["2021-22", 1420, 1110],
        ["2022-23", 1445, 1140],
        ["2023-24", 1490, 1180],
        ["2024-25", 1515, 1220],
        ["2025-26", 1540, 1305]
    ];
    
    $stmt = $conn->prepare("INSERT INTO `enrollment_history` (`year`, `jhs_count`, `shs_count`) VALUES (?, ?, ?)");
    foreach ($enrollment_seed as $row) {
        $stmt->bind_param("sii", $row[0], $row[1], $row[2]);
        $stmt->execute();
    }
    echo "[SEED] Inserted longitudinal enrollment records.<br>";
}

echo "--- Setup Complete! ---<br>";
$conn->close();

echo "</div>
    <p class='status-success'>🎉 Database and mock tables are successfully connected, created, and seeded!</p>
    <a href='index.html' class='success-btn'>Go to Dashboard Home</a>
</div>
</body>
</html>";
?>
