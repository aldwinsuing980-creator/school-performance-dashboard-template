<?php
require_once __DIR__ . '/config/session.php';
require_login();

// Restrict strictly to Admin and Faculty roles
if (!has_role('Admin', 'Faculty')) {
    $page_title = 'Access Denied';
    $breadcrumb = 'Access Denied';
    include 'includes/header.php';
    echo '<div class="d-flex align-items-center justify-content-center" style="min-height:50vh;">
      <div class="text-center">
        <div style="font-size:4rem;margin-bottom:1rem;">🔒</div>
        <h2 class="fw-700 text-dark mb-2">Access Denied</h2>
        <p class="text-muted mb-3">You do not have permission to view this page. This area is reserved for staff members.</p>
        <a href="dashboard.php" class="btn-primary-nhs"><i class="bi bi-arrow-left me-1"></i> Back to Dashboard</a>
      </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

$page_title = 'Summary Report';
$sy_rows = $pdo->query("SELECT DISTINCT school_year FROM enrollment_data ORDER BY school_year DESC")->fetchAll();
$sy_list  = array_column($sy_rows, 'school_year');
$sel_sy   = $_GET['sy'] ?? ($sy_list[0] ?? '2025-2026');

// Fetch Grade stats with detailed GAD Male/Female breakdown
$allowed_level_types = [];
if (has_kinder()) $allowed_level_types[] = 'Kindergarten';
if (has_elementary()) $allowed_level_types[] = 'Elementary';
if (has_jhs()) $allowed_level_types[] = 'Junior High';
if (has_shs()) $allowed_level_types[] = 'Senior High';
if (empty($allowed_level_types)) $allowed_level_types = ['Junior High', 'Senior High'];

$grade_drop_q = $pdo->prepare("
  SELECT 
    gl.grade_name, 
    gl.level_type,
    (
      SELECT COALESCE(SUM(
        CASE 
          WHEN gl.level_type = 'Senior High' THEN (CASE WHEN e.semester = '1st Sem' THEN e.bosy_enrollment ELSE 0 END)
          ELSE e.bosy_enrollment
        END
      ),0)
      FROM enrollment_data e
      WHERE e.grade_level_id = gl.id AND e.school_year = ?
    ) as enroll,
    (
      SELECT COALESCE(SUM(
        CASE 
          WHEN gl.level_type = 'Senior High' THEN (CASE WHEN e.semester = '1st Sem' THEN e.male_count ELSE 0 END)
          ELSE e.male_count
        END
      ),0)
      FROM enrollment_data e
      WHERE e.grade_level_id = gl.id AND e.school_year = ?
    ) as enroll_male,
    (
      SELECT COALESCE(SUM(
        CASE 
          WHEN gl.level_type = 'Senior High' THEN (CASE WHEN e.semester = '1st Sem' THEN e.female_count ELSE 0 END)
          ELSE e.female_count
        END
      ),0)
      FROM enrollment_data e
      WHERE e.grade_level_id = gl.id AND e.school_year = ?
    ) as enroll_female,
    (
      SELECT COALESCE(SUM(d.dropouts_count),0)
      FROM dropouts_data d
      WHERE d.grade_level_id = gl.id AND d.school_year = ?
    ) as drops,
    (
      SELECT COALESCE(SUM(d.male_count),0)
      FROM dropouts_data d
      WHERE d.grade_level_id = gl.id AND d.school_year = ?
    ) as drops_male,
    (
      SELECT COALESCE(SUM(d.female_count),0)
      FROM dropouts_data d
      WHERE d.grade_level_id = gl.id AND d.school_year = ?
    ) as drops_female,
    (
      SELECT COALESCE(SUM(r.repeaters_count),0)
      FROM repeaters_data r
      WHERE r.grade_level_id = gl.id AND r.school_year = ?
    ) as reps,
    (
      SELECT COALESCE(SUM(r.male_count),0)
      FROM repeaters_data r
      WHERE r.grade_level_id = gl.id AND r.school_year = ?
    ) as reps_male,
    (
      SELECT COALESCE(SUM(r.female_count),0)
      FROM repeaters_data r
      WHERE r.grade_level_id = gl.id AND r.school_year = ?
    ) as reps_female
  FROM grade_levels gl
  WHERE gl.level_type IN ('" . implode("','", $allowed_level_types) . "')
  ORDER BY gl.id
");
$grade_drop_q->execute([
    $sel_sy, $sel_sy, $sel_sy,
    $sel_sy, $sel_sy, $sel_sy,
    $sel_sy, $sel_sy, $sel_sy
]);
$grade_stats = $grade_drop_q->fetchAll();

// Calculate totals and overall rates
$jhs_enroll = 0;
$jhs_enroll_male = 0;
$jhs_enroll_female = 0;

$shs_enroll = 0;
$shs_enroll_male = 0;
$shs_enroll_female = 0;

$total_reps = 0;
$total_reps_male = 0;
$total_reps_female = 0;

$total_drops = 0;
$total_drops_male = 0;
$total_drops_female = 0;

foreach($grade_stats as $gs) {
    if($gs['level_type'] !== 'Senior High') {
        $jhs_enroll += (int)$gs['enroll'];
        $jhs_enroll_male += (int)$gs['enroll_male'];
        $jhs_enroll_female += (int)$gs['enroll_female'];
    } else {
        $shs_enroll += (int)$gs['enroll'];
        $shs_enroll_male += (int)$gs['enroll_male'];
        $shs_enroll_female += (int)$gs['enroll_female'];
    }
    $total_reps += (int)$gs['reps'];
    $total_reps_male += (int)$gs['reps_male'];
    $total_reps_female += (int)$gs['reps_female'];
    
    $total_drops += (int)$gs['drops'];
    $total_drops_male += (int)$gs['drops_male'];
    $total_drops_female += (int)$gs['drops_female'];
}

$total_enroll = $jhs_enroll + $shs_enroll;
$total_enroll_male = $jhs_enroll_male + $shs_enroll_male;
$total_enroll_female = $jhs_enroll_female + $shs_enroll_female;

$overall_rep_rate = $total_enroll > 0 ? round($total_reps / $total_enroll * 100, 2) : 0;
$overall_drop_rate = $total_enroll > 0 ? round($total_drops / $total_enroll * 100, 2) : 0;
$overall_ret_rate = round(100 - $overall_drop_rate, 2);

// Generate data-driven assessment paragraphs
$assessments = [];
$school_name_txt = $settings_data['school_name'] ?? 'our school';
$has_basic = has_jhs() || has_kinder() || has_elementary();

$basic_desc = "Junior High School";
if (!has_jhs() && (has_kinder() || has_elementary())) {
    $basic_desc = "Basic Education";
} else if (has_jhs() && (has_kinder() || has_elementary())) {
    $basic_desc = "Kinder, Elementary & JHS";
}

if ($has_basic && has_shs()) {
    $assessments[] = "For the School Year <strong>" . htmlspecialchars($sel_sy) . "</strong>, <strong>" . htmlspecialchars($school_name_txt) . "</strong> registered a total of <strong>" . number_format($total_enroll) . "</strong> enrollees. The student body is composed of <strong>" . number_format($jhs_enroll) . "</strong> " . $basic_desc . " students (" . ($total_enroll > 0 ? round($jhs_enroll/$total_enroll*100, 1) : 0) . "%) and <strong>" . number_format($shs_enroll) . "</strong> Senior High School students (" . ($total_enroll > 0 ? round($shs_enroll/$total_enroll*100, 1) : 0) . "%).";
} elseif ($has_basic) {
    $assessments[] = "For the School Year <strong>" . htmlspecialchars($sel_sy) . "</strong>, <strong>" . htmlspecialchars($school_name_txt) . "</strong> registered a total of <strong>" . number_format($total_enroll) . "</strong> enrollees in the " . $basic_desc . " department.";
} elseif (has_shs()) {
    $assessments[] = "For the School Year <strong>" . htmlspecialchars($sel_sy) . "</strong>, <strong>" . htmlspecialchars($school_name_txt) . "</strong> registered a total of <strong>" . number_format($total_enroll) . "</strong> enrollees in the Senior High School department.";
}

$assessments[] = "The <strong>Gender-Disaggregated GAD Profile</strong> reveals an enrollment distribution of <strong>" . number_format($total_enroll_male) . "</strong> Male students (" . ($total_enroll > 0 ? round($total_enroll_male/$total_enroll*100, 1) : 0) . "%) and <strong>" . number_format($total_enroll_female) . "</strong> Female students (" . ($total_enroll > 0 ? round($total_enroll_female/$total_enroll*100, 1) : 0) . "%), highlighting positive balance and accessibility across school years.";

$assessments[] = "An overall <strong>Retention Rate of " . $overall_ret_rate . "%</strong> was achieved, demonstrating that a vast majority of enrollees successfully remained in school. There were <strong>" . number_format($total_drops) . "</strong> recorded dropouts across all grade levels, leading to a minor overall <strong>Dropout Rate of " . $overall_drop_rate . "%</strong>.";

$assessments[] = "The overall <strong>Repeater Rate stands at " . $overall_rep_rate . "%</strong>, with a total of <strong>" . number_format($total_reps) . "</strong> repeater students. This indicates robust academic progress, though targeted intervention is recommended for grades showing localized challenges.";

// Strategic recommendation based on metrics
if ($overall_drop_rate > 5 || $overall_rep_rate > 3) {
    $assessments[] = "<strong>Strategic Recommendation:</strong> Given that some indicators exceed normal thresholds, it is recommended to initiate close academic counseling, strengthen the Dropout Reduction Program (DORP), and implement remedial programs for affected grade levels.";
} else {
    $assessments[] = "<strong>Strategic Recommendation:</strong> With all key metrics (Dropout Rate and Repeater Rate) well within excellent limits, the administration should focus on sustaining current academic support structures and documenting these successful practices for future school years.";
}

// Generate specific insights for JHS and SHS
$jhs_insights = [];
$shs_insights = [];

foreach($grade_stats as $gs){
    $e = (int)$gs['enroll'];
    $g_rate = $e > 0 ? round($gs['drops']/$e*100,1) : 0;
    $r_rate = $e > 0 ? round($gs['reps']/$e*100,1) : 0;
    
    $insights = [];
    if($g_rate > 10){
        $insights[] = "High Dropout Alert: {$g_rate}% ({$gs['drops']} students). Investigation and intervention programs are highly recommended.";
    } elseif ($g_rate > 0 && $g_rate <= 10) {
        $insights[] = "Dropout rate is at {$g_rate}%, which is within monitorable levels.";
    }
    
    if($r_rate > 8){
        $insights[] = "High Repeater Rate: {$r_rate}% ({$gs['reps']} students). Review of academic support and remedial classes recommended.";
    } elseif ($r_rate > 0 && $r_rate <= 8) {
        $insights[] = "Repeater rate is at {$r_rate}%, which is within acceptable levels.";
    }
    
    if($e > 0 && $gs['drops'] == 0 && $gs['reps'] == 0){
        $insights[] = "Excellent Performance: 0 repeaters, 0 dropouts! Document and replicate best practices.";
    }
    
    if(!empty($insights)){
        if($gs['level_type'] !== 'Senior High') {
            $jhs_insights[] = ['grade' => $gs['grade_name'], 'notes' => $insights];
        } else {
            $shs_insights[] = ['grade' => $gs['grade_name'], 'notes' => $insights];
        }
    }
}
if(empty($jhs_insights)) $jhs_insights[] = ['grade' => 'Overall JHS', 'notes' => ['All KPIs are within acceptable ranges. No critical issues detected.']];
if(empty($shs_insights)) $shs_insights[] = ['grade' => 'Overall SHS', 'notes' => ['All KPIs are within acceptable ranges. No critical issues detected.']];

include 'includes/header.php';
?>

<style>
/* Report Page Custom styling */
#summaryReportExport {
    background: #ffffff;
    box-shadow: 0 4px 20px rgba(0,0,0,0.05);
    font-family: 'Poppins', sans-serif;
    color: #334155;
    position: relative;
    border: 1px solid #e2e8f0;
}

.report-title-navy {
    color: #1B2A6B;
}

.text-print-navy {
    color: #1B2A6B;
}

/* Custom table styling for printing and high-DPI */
.report-table-gad {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 1.5rem;
    font-size: 0.9rem;
}

.report-table-gad th {
    background-color: #f8fafc;
    color: #1B2A6B;
    font-weight: 700;
    padding: 10px 12px;
    border: 1px solid #cbd5e1;
    font-size: 0.85rem;
}

.report-table-gad td {
    padding: 10px 12px;
    border: 1px solid #cbd5e1;
    font-size: 0.85rem;
}

.report-table-gad tr:nth-child(even) {
    background-color: #f8fafc;
}

.page-break-avoid {
    page-break-inside: avoid;
    break-inside: avoid;
}

.progress-bar-navy {
    background-color: #1B2A6B;
}
.progress-bar-gold {
    background-color: #C9A227;
}

/* Print CSS */
@media print {
    /* Hide dashboard chrome elements */
    .sidebar,
    .top-navbar,
    .report-controls-bar,
    #sidebarToggle,
    .sidebar-overlay,
    #sidebarOverlay,
    nav.top-navbar {
        display: none !important;
    }
    
    body {
        background-color: #fff !important;
        margin: 0 !important;
        padding: 0 !important;
    }
    
    .main-content {
        margin-left: 0 !important;
        padding: 0 !important;
        width: 100% !important;
    }
    
    .page-body {
        padding: 0 !important;
    }
    
    #summaryReportExport {
        border: none !important;
        box-shadow: none !important;
        padding: 0 !important;
        max-width: 100% !important;
        margin: 0 !important;
    }
    
    /* Optimize page breaks */
    .page-break-avoid {
        page-break-inside: avoid !important;
        break-inside: avoid !important;
    }
    
    @page {
        size: A4 landscape;
        margin: 1cm 1.5cm 1cm 1.5cm;
    }
}
</style>

<!-- ── COMMAND & CONTROL BAR (Interactive Controls - Hidden on print) ── -->
<div class="report-controls-bar d-flex justify-content-between align-items-center mb-4 p-3 bg-white shadow-sm rounded-3">
    <div class="d-flex align-items-center gap-3">
        <a href="dashboard.php?sy=<?= urlencode($sel_sy) ?>" class="btn btn-outline-secondary btn-sm rounded-2 d-inline-flex align-items-center gap-2">
            <i class="bi bi-arrow-left"></i> Back to Dashboard
        </a>
        <h5 class="mb-0 fw-600 text-dark">Official School Performance Profile</h5>
    </div>
    <div class="d-flex align-items-center gap-2">
        <span class="small text-muted me-1 fw-500">School Year:</span>
        <select class="form-select form-select-sm rounded-2 border-secondary-subtle py-1.5" style="width: auto;" onchange="window.location.href='summary_report.php?sy='+encodeURIComponent(this.value)">
            <?php foreach($sy_list as $sy): ?>
                <option value="<?= $sy ?>" <?= $sy === $sel_sy ? 'selected' : '' ?>><?= $sy ?></option>
            <?php endforeach; ?>
        </select>
        <button onclick="window.print()" class="btn btn-outline-primary btn-sm rounded-2 d-inline-flex align-items-center gap-2">
            <i class="bi bi-printer"></i> Print Official Copy
        </button>
        <button onclick="exportToPDF('summaryReportExport', 'NHS_Annual_Performance_Report_<?= htmlspecialchars($sel_sy) ?>.pdf')" class="btn btn-primary btn-sm rounded-2 d-inline-flex align-items-center gap-2" style="background-color: #1B2A6B; border-color: #1B2A6B;">
            <i class="bi bi-file-earmark-pdf"></i> Download PDF
        </button>
    </div>
</div>

<!-- Make a clean container for the PDF -->
<div id="summaryReportExport" style="background:#fff; padding:45px 50px; border-radius:12px; max-width: 1100px; margin: 0 auto;">
    
    <!-- ── OFFICIAL DEPED HEADER ── -->
    <div class="d-flex align-items-center justify-content-between pb-3 mb-4 border-bottom border-2" style="border-color: #1B2A6B !important;">
        <!-- Left Seal (Official DepEd Logo) -->
        <div class="logo-container text-start">
            <img src="assets/img/deped-logo.png" alt="DepEd Logo" style="height: 75px; width: auto; object-fit: contain;">
        </div>
        <!-- Center Text -->
        <div class="text-center flex-grow-1 px-3">
            <h6 class="mb-0 fw-normal text-uppercase" style="font-size:0.75rem; letter-spacing:1px; color:#475569;">Republic of the Philippines</h6>
            <h5 class="mb-0 fw-bold text-print-navy" style="font-size:1.1rem; color:#1B2A6B; font-weight:700;">Department of Education</h5>
            <div class="text-muted mt-0.5" style="font-size:0.75rem; font-weight:500; line-height: 1.3;">
                REGION III - CENTRAL LUZON<br>
                SCHOOLS DIVISION OF PAMPANGA<br>
                DISTRICT OF GUAGUA
            </div>
            <h4 class="mt-1.5 mb-0 fw-bold text-print-navy" style="font-size:1.25rem; color:#1B2A6B; font-weight:800; letter-spacing:0.5px;"><?= htmlspecialchars(strtoupper($settings_data['school_name'] ?? 'Natividad High School')) ?></h4>
            <span class="fst-italic text-muted" style="font-size:0.75rem;"><?= htmlspecialchars($settings_data['address'] ?? 'Natividad, Guagua, Pampanga') ?></span>
        </div>
        <!-- Right Seal (Official NHS Logo) -->
        <div class="logo-container text-end">
            <img src="assets/img/school-logo.png" alt="NHS Logo" style="height: 75px; width: auto; object-fit: contain; border-radius: 50%;">
        </div>
    </div>
    
    <div class="text-center mb-4">
        <h3 class="fw-bold mb-1" style="color:#1B2A6B; font-weight:800; letter-spacing: 0.5px; font-size: 1.5rem;">ANNUAL SCHOOL PERFORMANCE PROFILE</h3>
        <p class="text-muted mb-0" style="font-size: 0.95rem; font-weight: 500;">Comprehensive Metrics & GAD Performance Audit | School Year: <strong><?= htmlspecialchars($sel_sy) ?></strong></p>
    </div>

    <!-- ── EXECUTIVE SUMMARY & ANALYTICS ── -->
    <div class="p-4 mb-4" style="background:#f8fafc; border-left:5px solid #1B2A6B; border-radius:8px;">
        <h5 class="fw-bold mb-3" style="color:#1B2A6B;"><i class="bi bi-file-earmark-text-fill me-2"></i>Executive Summary & Administrative Assessment</h5>
        
        <!-- Key Metrics Cards -->
        <div class="row g-3 mb-4">
            <!-- Total BOSY Enrollment -->
            <div class="col-md-3">
                <div style="background:#fff; padding:15px; border-radius:8px; border:1px solid #cbd5e1; text-align:center;">
                    <div style="font-size:0.75rem; color:#64748b; font-weight:600; text-transform:uppercase; letter-spacing:0.5px;">BOSY Enrollment</div>
                    <div style="font-size:1.6rem; color:#1B2A6B; font-weight:800; margin:3px 0;"><?= number_format($total_enroll) ?></div>
                    <div style="font-size:0.7rem; color:#64748b;">M: <?= number_format($total_enroll_male) ?> | F: <?= number_format($total_enroll_female) ?></div>
                </div>
            </div>
            <!-- Overall Repeater Rate -->
            <div class="col-md-3">
                <div style="background:#fff; padding:15px; border-radius:8px; border:1px solid #cbd5e1; text-align:center;">
                    <div style="font-size:0.75rem; color:#64748b; font-weight:600; text-transform:uppercase; letter-spacing:0.5px;">Repeater Rate</div>
                    <div style="font-size:1.6rem; color:#d97706; font-weight:800; margin:3px 0;"><?= $overall_rep_rate ?>%</div>
                    <div style="font-size:0.7rem; color:#64748b;">Total: <?= number_format($total_reps) ?> students</div>
                </div>
            </div>
            <!-- Overall Dropout Rate -->
            <div class="col-md-3">
                <div style="background:#fff; padding:15px; border-radius:8px; border:1px solid #cbd5e1; text-align:center;">
                    <div style="font-size:0.75rem; color:#64748b; font-weight:600; text-transform:uppercase; letter-spacing:0.5px;">Dropout Rate</div>
                    <div style="font-size:1.6rem; color:#dc2626; font-weight:800; margin:3px 0;"><?= $overall_drop_rate ?>%</div>
                    <div style="font-size:0.7rem; color:#64748b;">Total: <?= number_format($total_drops) ?> students</div>
                </div>
            </div>
            <!-- Overall Retention Rate -->
            <div class="col-md-3">
                <div style="background:#fff; padding:15px; border-radius:8px; border:1px solid #cbd5e1; text-align:center;">
                    <div style="font-size:0.75rem; color:#64748b; font-weight:600; text-transform:uppercase; letter-spacing:0.5px;">Retention Rate</div>
                    <div style="font-size:1.6rem; color:#16a34a; font-weight:800; margin:3px 0;"><?= $overall_ret_rate ?>%</div>
                    <div style="font-size:0.7rem; color:#64748b;">Target: &ge; 95.0%</div>
                </div>
            </div>
        </div>

        <!-- Executive Narrative -->
        <div style="font-size:0.9rem; line-height: 1.6; color:#334155;">
            <?php foreach($assessments as $para): ?>
                <p class="mb-2"><?= $para ?></p>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ── GAD PROFILE PROGRESS BAR BARS ── -->
    <div class="row g-3 mb-4 page-break-avoid">
        <div class="col-md-4">
            <div style="background:#fff; padding:15px; border-radius:8px; border:1px solid #cbd5e1;">
                <h6 style="color:#1B2A6B; font-weight:700; margin-bottom:10px; font-size: 0.85rem;"><i class="bi bi-gender-ambiguous me-2"></i>Enrollment GAD Profile</h6>
                <div class="d-flex justify-content-between align-items-center mb-1.5" style="font-size:0.8rem;">
                    <span class="text-muted">Male Enrollees</span>
                    <span class="fw-bold" style="color:#1B2A6B;"><?= number_format($total_enroll_male) ?> (<?= $total_enroll > 0 ? round($total_enroll_male/$total_enroll*100,1) : 0 ?>%)</span>
                </div>
                <div class="progress" style="height:6px; background-color:#e2e8f0; border-radius:3px; margin-bottom: 8px;">
                    <div class="progress-bar progress-bar-navy" role="progressbar" style="width: <?= $total_enroll > 0 ? ($total_enroll_male/$total_enroll*100) : 0 ?>%;"></div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-1.5" style="font-size:0.8rem;">
                    <span class="text-muted">Female Enrollees</span>
                    <span class="fw-bold" style="color:#C9A227;"><?= number_format($total_enroll_female) ?> (<?= $total_enroll > 0 ? round($total_enroll_female/$total_enroll*100,1) : 0 ?>%)</span>
                </div>
                <div class="progress" style="height:6px; background-color:#e2e8f0; border-radius:3px;">
                    <div class="progress-bar progress-bar-gold" role="progressbar" style="width: <?= $total_enroll > 0 ? ($total_enroll_female/$total_enroll*100) : 0 ?>%;"></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div style="background:#fff; padding:15px; border-radius:8px; border:1px solid #cbd5e1;">
                <h6 style="color:#d97706; font-weight:700; margin-bottom:10px; font-size: 0.85rem;"><i class="bi bi-exclamation-triangle-fill me-2 text-warning"></i>Repeaters GAD Profile</h6>
                <div class="d-flex justify-content-between align-items-center mb-1.5" style="font-size:0.8rem;">
                    <span class="text-muted">Male Repeaters</span>
                    <span class="fw-bold" style="color:#d97706;"><?= number_format($total_reps_male) ?> (<?= $total_reps > 0 ? round($total_reps_male/$total_reps*100,1) : 0 ?>%)</span>
                </div>
                <div class="progress" style="height:6px; background-color:#e2e8f0; border-radius:3px; margin-bottom: 8px;">
                    <div class="progress-bar bg-warning" role="progressbar" style="width: <?= $total_reps > 0 ? ($total_reps_male/$total_reps*100) : 0 ?>%;"></div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-1.5" style="font-size:0.8rem;">
                    <span class="text-muted">Female Repeaters</span>
                    <span class="fw-bold" style="color:#d97706;"><?= number_format($total_reps_female) ?> (<?= $total_reps > 0 ? round($total_reps_female/$total_reps*100,1) : 0 ?>%)</span>
                </div>
                <div class="progress" style="height:6px; background-color:#e2e8f0; border-radius:3px;">
                    <div class="progress-bar" role="progressbar" style="width: <?= $total_reps > 0 ? ($total_reps_female/$total_reps*100) : 0 ?>%; background-color:#fed7aa;"></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div style="background:#fff; padding:15px; border-radius:8px; border:1px solid #cbd5e1;">
                <h6 style="color:#dc2626; font-weight:700; margin-bottom:10px; font-size: 0.85rem;"><i class="bi bi-x-circle-fill me-2 text-danger"></i>Dropouts GAD Profile</h6>
                <div class="d-flex justify-content-between align-items-center mb-1.5" style="font-size:0.8rem;">
                    <span class="text-muted">Male Dropouts</span>
                    <span class="fw-bold" style="color:#dc2626;"><?= number_format($total_drops_male) ?> (<?= $total_drops > 0 ? round($total_drops_male/$total_drops*100,1) : 0 ?>%)</span>
                </div>
                <div class="progress" style="height:6px; background-color:#e2e8f0; border-radius:3px; margin-bottom: 8px;">
                    <div class="progress-bar bg-danger" role="progressbar" style="width: <?= $total_drops > 0 ? ($total_drops_male/$total_drops*100) : 0 ?>%;"></div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-1.5" style="font-size:0.8rem;">
                    <span class="text-muted">Female Dropouts</span>
                    <span class="fw-bold" style="color:#dc2626;"><?= number_format($total_drops_female) ?> (<?= $total_drops > 0 ? round($total_drops_female/$total_drops*100,1) : 0 ?>%)</span>
                </div>
                <div class="progress" style="height:6px; background-color:#e2e8f0; border-radius:3px;">
                    <div class="progress-bar" role="progressbar" style="width: <?= $total_drops > 0 ? ($total_drops_female/$total_drops*100) : 0 ?>%; background-color:#fecaca;"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- ── JUNIOR HIGH SCHOOL / BASIC ED BREAKDOWN ── -->
    <?php if ($has_basic): 
      $table_title = "Junior High School Profile";
      if (!has_jhs() && (has_kinder() || has_elementary())) {
        $table_title = "Basic Education Profile";
      } else if (has_jhs() && (has_kinder() || has_elementary())) {
        $table_title = "Kinder, Elementary & JHS Profile";
      }
    ?>
    <div class="page-break-avoid">
        <h5 style="color:#1B2A6B; border-bottom:2px solid #1B2A6B; padding-bottom:6px; margin-bottom: 12px; font-weight:700; font-size: 1.1rem;"><i class="bi bi-mortarboard-fill me-2"></i><?= $table_title ?></h5>
        <table class="report-table-gad">
            <thead style="vertical-align: middle;">
                <tr>
                    <th rowspan="2" style="width: 16%; text-align: left;">Grade Level</th>
                    <th colspan="3" style="text-align: center;">Enrollment</th>
                    <th colspan="3" style="text-align: center;">Repeaters</th>
                    <th colspan="3" style="text-align: center;">Dropouts</th>
                    <th rowspan="2" style="text-align: center; width: 11%;">Rep. Rate</th>
                    <th rowspan="2" style="text-align: center; width: 11%;">Drop. Rate</th>
                </tr>
                <tr style="font-size: 0.8rem;">
                    <th style="text-align: center; color: #475569;">Total</th>
                    <th style="text-align: center; color: #64748b;">M</th>
                    <th style="text-align: center; color: #64748b;">F</th>
                    <th style="text-align: center; color: #475569;">Total</th>
                    <th style="text-align: center; color: #64748b;">M</th>
                    <th style="text-align: center; color: #64748b;">F</th>
                    <th style="text-align: center; color: #475569;">Total</th>
                    <th style="text-align: center; color: #64748b;">M</th>
                    <th style="text-align: center; color: #64748b;">F</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($grade_stats as $row): if($row['level_type'] === 'Senior High') continue; 
                      $e = $row['enroll']; $em = $row['enroll_male']; $ef = $row['enroll_female'];
                      $r = $row['reps']; $rm = $row['reps_male']; $rf = $row['reps_female'];
                      $d = $row['drops']; $dm = $row['drops_male']; $df = $row['drops_female'];
                      $r_rate = $e > 0 ? round($r/$e*100,1) : 0; $d_rate = $e > 0 ? round($d/$e*100,1) : 0;
                ?>
                <tr style="text-align: center;">
                    <td class="fw-600 text-start" style="color: #1B2A6B; font-weight: 600;"><?= htmlspecialchars($row['grade_name']) ?></td>
                    <td class="fw-bold"><?= number_format($e) ?></td>
                    <td style="color:#475569;"><?= number_format($em) ?></td>
                    <td style="color:#475569;"><?= number_format($ef) ?></td>
                    <td class="fw-bold text-warning"><?= number_format($r) ?></td>
                    <td style="color:#64748b;"><?= number_format($rm) ?></td>
                    <td style="color:#64748b;"><?= number_format($rf) ?></td>
                    <td class="fw-bold text-danger"><?= number_format($d) ?></td>
                    <td style="color:#64748b;"><?= number_format($dm) ?></td>
                    <td style="color:#64748b;"><?= number_format($df) ?></td>
                    <td class="fw-bold" style="color:#d97706;"><?= $r_rate ?>%</td>
                    <td class="fw-bold" style="color:#dc2626;"><?= $d_rate ?>%</td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="p-3 mb-4" style="background:#f8fafc; border-left:4px solid #C9A227; border-radius:6px; font-size: 0.85rem;">
            <span class="fw-bold text-uppercase d-block mb-1.5" style="color:#A07D0F; font-size: 0.8rem; letter-spacing:0.5px;"><i class="bi bi-lightbulb-fill me-1"></i><?= !has_jhs() && (has_kinder() || has_elementary()) ? 'Basic Education' : 'Junior High School' ?> Key Insights:</span>
            <ul class="mb-0 text-dark ps-3" style="line-height: 1.5;">
                <?php foreach($jhs_insights as $ins): ?>
                    <?php foreach($ins['notes'] as $n): ?>
                        <li class="mb-1"><strong><?= $ins['grade'] ?>:</strong> <?= $n ?></li>
                    <?php endforeach; ?>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>

    <!-- ── SENIOR HIGH SCHOOL BREAKDOWN ── -->
    <?php if (has_shs()): ?>
    <div class="page-break-avoid">
        <h5 style="color:#1B2A6B; border-bottom:2px solid #1B2A6B; padding-bottom:6px; margin-bottom: 12px; font-weight:700; font-size: 1.1rem;"><i class="bi bi-mortarboard-fill me-2"></i>Senior High School Profile</h5>
        <table class="report-table-gad">
            <thead style="vertical-align: middle;">
                <tr>
                    <th rowspan="2" style="width: 16%; text-align: left;">Grade Level</th>
                    <th colspan="3" style="text-align: center;">Enrollment</th>
                    <th colspan="3" style="text-align: center;">Repeaters</th>
                    <th colspan="3" style="text-align: center;">Dropouts</th>
                    <th rowspan="2" style="text-align: center; width: 11%;">Rep. Rate</th>
                    <th rowspan="2" style="text-align: center; width: 11%;">Drop. Rate</th>
                </tr>
                <tr style="font-size: 0.8rem;">
                    <th style="text-align: center; color: #475569;">Total</th>
                    <th style="text-align: center; color: #64748b;">M</th>
                    <th style="text-align: center; color: #64748b;">F</th>
                    <th style="text-align: center; color: #475569;">Total</th>
                    <th style="text-align: center; color: #64748b;">M</th>
                    <th style="text-align: center; color: #64748b;">F</th>
                    <th style="text-align: center; color: #475569;">Total</th>
                    <th style="text-align: center; color: #64748b;">M</th>
                    <th style="text-align: center; color: #64748b;">F</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($grade_stats as $row): if($row['level_type'] !== 'Senior High') continue; 
                      $e = $row['enroll']; $em = $row['enroll_male']; $ef = $row['enroll_female'];
                      $r = $row['reps']; $rm = $row['reps_male']; $rf = $row['reps_female'];
                      $d = $row['drops']; $dm = $row['drops_male']; $df = $row['drops_female'];
                      $r_rate = $e > 0 ? round($r/$e*100,1) : 0; $d_rate = $e > 0 ? round($d/$e*100,1) : 0;
                ?>
                <tr style="text-align: center;">
                    <td class="fw-600 text-start" style="color: #1B2A6B; font-weight: 600;"><?= htmlspecialchars($row['grade_name']) ?></td>
                    <td class="fw-bold"><?= number_format($e) ?></td>
                    <td style="color:#475569;"><?= number_format($em) ?></td>
                    <td style="color:#475569;"><?= number_format($ef) ?></td>
                    <td class="fw-bold text-warning"><?= number_format($r) ?></td>
                    <td style="color:#64748b;"><?= number_format($rm) ?></td>
                    <td style="color:#64748b;"><?= number_format($rf) ?></td>
                    <td class="fw-bold text-danger"><?= number_format($d) ?></td>
                    <td style="color:#64748b;"><?= number_format($dm) ?></td>
                    <td style="color:#64748b;"><?= number_format($df) ?></td>
                    <td class="fw-bold" style="color:#d97706;"><?= $r_rate ?>%</td>
                    <td class="fw-bold" style="color:#dc2626;"><?= $d_rate ?>%</td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="p-3 mb-4" style="background:#f8fafc; border-left:4px solid #C9A227; border-radius:6px; font-size: 0.85rem;">
            <span class="fw-bold text-uppercase d-block mb-1.5" style="color:#A07D0F; font-size: 0.8rem; letter-spacing:0.5px;"><i class="bi bi-lightbulb-fill me-1"></i>Senior High School Key Insights:</span>
            <ul class="mb-0 text-dark ps-3" style="line-height: 1.5;">
                <?php foreach($shs_insights as $ins): ?>
                    <?php foreach($ins['notes'] as $n): ?>
                        <li class="mb-1"><strong><?= $ins['grade'] ?>:</strong> <?= $n ?></li>
                    <?php endforeach; ?>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>

    <!-- ── DEPED-STANDARD SIGNATURES & APPROVED BY SECTION ── -->
    <div class="row mt-5 pt-4 border-top border-2 page-break-avoid" style="border-color:#1B2A6B !important; font-size: 0.85rem;">
        <div class="col-md-4 text-center">
            <div style="font-size: 0.8rem; color:#64748b; margin-bottom: 45px; text-transform: uppercase; letter-spacing: 0.5px;">Prepared by:</div>
            <div class="fw-bold text-dark border-bottom pb-1 mx-4" style="font-size:0.9rem; border-color:#94a3b8 !important;"><?= htmlspecialchars($_SESSION['full_name'] ?? 'System Encoder') ?></div>
            <div class="small text-muted mt-1" style="font-size:0.75rem; font-weight: 500;"><?= htmlspecialchars($_SESSION['user_role'] ?? 'Encoder') ?> / Registrar</div>
        </div>
        <div class="col-md-4 text-center">
            <div style="font-size: 0.8rem; color:#64748b; margin-bottom: 45px; text-transform: uppercase; letter-spacing: 0.5px;">Verified by:</div>
            <div class="fw-bold text-dark border-bottom pb-1 mx-4" style="font-size:0.9rem; border-color:#94a3b8 !important;">GIRLY L. PANGILINAN</div>
            <div class="small text-muted mt-1" style="font-size:0.75rem; font-weight: 500;">School Head</div>
        </div>
        <div class="col-md-4 text-center">
            <div style="font-size: 0.8rem; color:#64748b; margin-bottom: 45px; text-transform: uppercase; letter-spacing: 0.5px;">Approved by:</div>
            <div class="fw-bold text-dark border-bottom pb-1 mx-4" style="font-size:0.9rem; border-color:#94a3b8 !important;">ROMEO M. ALIP, PhD, CESO V</div>
            <div class="small text-muted mt-1" style="font-size:0.75rem; font-weight: 500;">School Division Superintendent</div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
