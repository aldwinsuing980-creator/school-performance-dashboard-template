<?php
require_once __DIR__ . '/../config/session.php';
require_login();

// Restricted to Admin and Encoder roles for write actions
if (!has_role('Admin', 'Encoder', 'Faculty')) {
    json_response(['success' => false, 'message' => 'Access denied. Unauthorized role.'], 403);
}

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';

try {
    if ($action === 'add') {
        $title      = clean($data['title'] ?? '');
        $content    = clean($data['content'] ?? '');
        $category   = clean($data['category'] ?? 'general');
        $is_active  = isset($data['is_active']) ? (int)$data['is_active'] : 1;
        $start_date = !empty($data['start_date']) ? clean($data['start_date']) : null;
        $end_date   = !empty($data['end_date']) ? clean($data['end_date']) : null;

        if (empty($title) || empty($content)) {
            json_response(['success' => false, 'message' => 'Title and content are required.'], 400);
        }

        $stmt = $pdo->prepare("
            INSERT INTO announcements (title, content, category, is_active, start_date, end_date) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$title, $content, $category, $is_active, $start_date, $end_date]);
        $new_id = $pdo->lastInsertId();

        log_activity($pdo, current_user_id(), "Added new announcement '{$title}' (ID:{$new_id})", 'Announcements');
        json_response(['success' => true, 'message' => 'Announcement created successfully.', 'id' => $new_id]);

    } elseif ($action === 'edit') {
        $id         = (int)($data['id'] ?? 0);
        $title      = clean($data['title'] ?? '');
        $content    = clean($data['content'] ?? '');
        $category   = clean($data['category'] ?? 'general');
        $is_active  = isset($data['is_active']) ? (int)$data['is_active'] : 1;
        $start_date = !empty($data['start_date']) ? clean($data['start_date']) : null;
        $end_date   = !empty($data['end_date']) ? clean($data['end_date']) : null;

        if (!$id) {
            json_response(['success' => false, 'message' => 'Invalid announcement ID.'], 400);
        }
        if (empty($title) || empty($content)) {
            json_response(['success' => false, 'message' => 'Title and content are required.'], 400);
        }

        $stmt = $pdo->prepare("
            UPDATE announcements 
            SET title = ?, content = ?, category = ?, is_active = ?, start_date = ?, end_date = ? 
            WHERE id = ?
        ");
        $stmt->execute([$title, $content, $category, $is_active, $start_date, $end_date, $id]);

        log_activity($pdo, current_user_id(), "Updated announcement ID:{$id}", 'Announcements');
        json_response(['success' => true, 'message' => 'Announcement updated successfully.']);

    } elseif ($action === 'toggle_active') {
        $id        = (int)($data['id'] ?? 0);
        $is_active = (int)($data['is_active'] ?? 0);

        if (!$id) {
            json_response(['success' => false, 'message' => 'Invalid announcement ID.'], 400);
        }

        $stmt = $pdo->prepare("UPDATE announcements SET is_active = ? WHERE id = ?");
        $stmt->execute([$is_active, $id]);

        $status = $is_active ? 'activated' : 'deactivated';
        log_activity($pdo, current_user_id(), "Toggled announcement ID:{$id} status to {$status}", 'Announcements');
        json_response(['success' => true, 'message' => "Announcement successfully {$status}."]);

    } elseif ($action === 'delete') {
        $id = (int)($data['id'] ?? 0);

        if (!$id) {
            json_response(['success' => false, 'message' => 'Invalid announcement ID.'], 400);
        }

        $stmt = $pdo->prepare("DELETE FROM announcements WHERE id = ?");
        $stmt->execute([$id]);

        log_activity($pdo, current_user_id(), "Deleted announcement ID:{$id}", 'Announcements');
        json_response(['success' => true, 'message' => 'Announcement deleted successfully.']);

    } else {
        json_response(['success' => false, 'message' => 'Unknown action request.'], 400);
    }
} catch (PDOException $e) {
    json_response(['success' => false, 'message' => 'Database error: ' . $e->getMessage()], 500);
}
?>
