<?php
require_once __DIR__ . '/config/session.php';
require_login();
if(!has_role('Admin')){
    $page_title = 'Access Denied';
    $breadcrumb = 'Database Audit';
    include 'includes/header.php';
    echo '<div class="d-flex align-items-center justify-content-center" style="min-height:50vh;">
      <div class="text-center">
        <div style="font-size:4rem;margin-bottom:1rem;">🔒</div>
        <h2 class="fw-700 text-dark mb-2">Access Denied</h2>
        <p class="text-muted mb-3">You need <strong>Admin</strong> privilege to access Database Audit tool.</p>
        <a href="index.php" class="btn-primary-nhs"><i class="bi bi-arrow-left me-1"></i> Back to Dashboard</a>
      </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

$page_title = 'Database Audit & Diagnostics';
$breadcrumb = 'DB Diagnostics';

// Action: Fix Duplicates
$fixed_message = "";
if (isset($_POST['fix_duplicates'])) {
    try {
        $pdo->beginTransaction();
        
        // 1. Delete duplicates in enrollment_data (keep highest ID)
        $q1 = $pdo->exec("
            DELETE e1 FROM enrollment_data e1
            INNER JOIN enrollment_data e2 
            ON e1.grade_level_id = e2.grade_level_id 
               AND COALESCE(e1.strand_id, 0) = COALESCE(e2.strand_id, 0) 
               AND e1.semester = e2.semester 
               AND e1.school_year = e2.school_year 
               AND e1.id < e2.id
        ");

        // 2. Delete duplicates in repeaters_data (keep highest ID)
        $q2 = $pdo->exec("
            DELETE r1 FROM repeaters_data r1
            INNER JOIN repeaters_data r2 
            ON r1.grade_level_id = r2.grade_level_id 
               AND COALESCE(r1.strand_id, 0) = COALESCE(r2.strand_id, 0) 
               AND r1.semester = r2.semester 
               AND r1.school_year = r2.school_year 
               AND r1.id < r2.id
        ");

        // 3. Delete duplicates in dropouts_data (keep highest ID)
        $q3 = $pdo->exec("
            DELETE d1 FROM dropouts_data d1
            INNER JOIN dropouts_data d2 
            ON d1.grade_level_id = d2.grade_level_id 
               AND COALESCE(d1.strand_id, 0) = COALESCE(d2.strand_id, 0) 
               AND d1.semester = d2.semester 
               AND d1.school_year = d2.school_year 
               AND d1.id < d2.id
        ");

        $pdo->commit();
        $total_fixed = $q1 + $q2 + $q3;
        $fixed_message = "<div class='alert alert-success alert-dismissible fade show shadow-sm' role='alert'>
            <strong>🎉 Diagnostics Complete!</strong> Cleaned up a total of <strong>$total_fixed</strong> duplicate records.
            <ul>
                <li>Enrollment duplicates removed: <strong>$q1</strong></li>
                <li>Repeaters duplicates removed: <strong>$q2</strong></li>
                <li>Dropouts duplicates removed: <strong>$q3</strong></li>
            </ul>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
        </div>";
        log_activity($pdo, current_user_id(), "Database Audit: Cleaned up $total_fixed duplicate records.", "Diagnostics");
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $fixed_message = "<div class='alert alert-danger' role='alert'>
            <strong>❌ Error during cleanup:</strong> " . htmlspecialchars($e->getMessage()) . "
        </div>";
    }
}

// ── AUDIT 1: Find Duplicates ───────────────────────────
$dup_enroll = $pdo->query("
    SELECT e.school_year, gl.grade_name, st.strand_code, e.semester, COUNT(*) as count, GROUP_CONCAT(e.id) as ids, GROUP_CONCAT(e.bosy_enrollment) as values_list
    FROM enrollment_data e
    JOIN grade_levels gl ON gl.id = e.grade_level_id
    LEFT JOIN strands st ON st.id = e.strand_id
    GROUP BY e.grade_level_id, e.strand_id, e.semester, e.school_year
    HAVING COUNT(*) > 1
")->fetchAll();

$dup_rep = $pdo->query("
    SELECT r.school_year, gl.grade_name, st.strand_code, r.semester, COUNT(*) as count, GROUP_CONCAT(r.id) as ids
    FROM repeaters_data r
    JOIN grade_levels gl ON gl.id = r.grade_level_id
    LEFT JOIN strands st ON st.id = r.strand_id
    GROUP BY r.grade_level_id, r.strand_id, r.semester, r.school_year
    HAVING COUNT(*) > 1
")->fetchAll();

$dup_drop = $pdo->query("
    SELECT d.school_year, gl.grade_name, st.strand_code, d.semester, COUNT(*) as count, GROUP_CONCAT(d.id) as ids
    FROM dropouts_data d
    JOIN grade_levels gl ON gl.id = d.grade_level_id
    LEFT JOIN strands st ON st.id = d.strand_id
    GROUP BY d.grade_level_id, d.strand_id, d.semester, d.school_year
    HAVING COUNT(*) > 1
")->fetchAll();

$has_duplicates = (count($dup_enroll) > 0 || count($dup_rep) > 0 || count($dup_drop) > 0);

// ── AUDIT 2: Data Summary by SY (2024-2025 and 2025-2026) ───────────
$q = $pdo->prepare("
    SELECT e.school_year, gl.grade_name, gl.level_type, st.strand_code, e.semester, e.bosy_enrollment, e.male_count, e.female_count
    FROM enrollment_data e
    JOIN grade_levels gl ON gl.id = e.grade_level_id
    LEFT JOIN strands st ON st.id = e.strand_id
    WHERE e.school_year IN ('2024-2025', '2025-2026')
    ORDER BY e.school_year, gl.id, st.id, e.semester
");
$q->execute();
$all_enrollments = $q->fetchAll();

// Group for quick summary totals
$totals_summary = [];
foreach ($all_enrollments as $row) {
    $sy = $row['school_year'];
    if (!isset($totals_summary[$sy])) {
        $totals_summary[$sy] = ['jhs' => 0, 'shs_1st' => 0, 'shs_2nd' => 0, 'total_bosy' => 0];
    }
    
    if ($row['level_type'] === 'Junior High') {
        $totals_summary[$sy]['jhs'] += (int)$row['bosy_enrollment'];
        $totals_summary[$sy]['total_bosy'] += (int)$row['bosy_enrollment'];
    } else {
        if ($row['semester'] === '1st Sem') {
            $totals_summary[$sy]['shs_1st'] += (int)$row['bosy_enrollment'];
            $totals_summary[$sy]['total_bosy'] += (int)$row['bosy_enrollment'];
        } else {
            $totals_summary[$sy]['shs_2nd'] += (int)$row['bosy_enrollment'];
        }
    }
}

include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <!-- Breadcrumb and Title -->
    <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
        <div class="section-header mb-0">
            <h1 class="section-title"><i class="bi bi-shield-fill-check me-2 text-primary-nhs"></i>Database Diagnostics Tool</h1>
            <p class="section-sub">Audit active records, check for duplicate rows, and fix calculation mismatch between Local and Live servers.</p>
        </div>
        <a href="dashboard.php" class="btn-primary-nhs text-white text-decoration-none">
            <i class="bi bi-speedometer2"></i> Back to Dashboard
        </a>
    </div>

    <?= $fixed_message ?>

    <!-- ── SUMMARY SECTION ── -->
    <div class="row g-3 mb-4">
        <?php foreach (['2024-2025', '2025-2026'] as $sy): 
            $vals = $totals_summary[$sy] ?? ['jhs'=>0, 'shs_1st'=>0, 'shs_2nd'=>0, 'total_bosy'=>0];
        ?>
        <div class="col-md-6">
            <div class="card border shadow-sm h-100">
                <div class="card-header bg-light py-3">
                    <h6 class="fw-bold mb-0 text-primary-nhs"><i class="bi bi-calendar-event me-2"></i>S.Y. <?= $sy ?> — Active Database Totals</h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-4 border-end">
                            <div class="text-muted small fw-600">JHS Total</div>
                            <h3 class="fw-bold text-dark mt-1"><?= number_format($vals['jhs']) ?></h3>
                        </div>
                        <div class="col-4 border-end">
                            <div class="text-muted small fw-600">SHS (1st Sem)</div>
                            <h3 class="fw-bold text-cyan mt-1" style="color: #0891b2;"><?= number_format($vals['shs_1st']) ?></h3>
                        </div>
                        <div class="col-4">
                            <div class="text-muted small fw-600">Total BOSY</div>
                            <h3 class="fw-bold text-success mt-1"><?= number_format($vals['total_bosy']) ?></h3>
                        </div>
                    </div>
                    <div class="mt-3 p-2 bg-light rounded text-center small text-muted border">
                        SHS 2nd Semester Total: <strong><?= number_format($vals['shs_2nd']) ?></strong> enrollees (Excluded from BOSY standard)
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- ── DUPLICATES DETECTED SECTION ── -->
    <div class="card border shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center py-3 <?= $has_duplicates ? 'bg-danger-subtle text-danger' : 'bg-success-subtle text-success' ?>">
            <h6 class="fw-bold mb-0">
                <i class="bi <?= $has_duplicates ? 'bi-exclamation-triangle-fill' : 'bi-check-circle-fill' ?> me-2"></i>
                <?= $has_duplicates ? 'Duplicate Rows Detected in Database!' : 'Excellent! No Duplicate Rows Found.' ?>
            </h6>
            <?php if ($has_duplicates): ?>
                <form method="POST" onsubmit="return confirm('Are you sure you want to delete all duplicate records? Only the latest clean records will be preserved.');">
                    <button type="submit" name="fix_duplicates" class="btn btn-danger btn-sm shadow-sm fw-600 px-3">
                        <i class="bi bi-magic me-1"></i> Awtomatikong Ayusin (Fix All Duplicates)
                    </button>
                </form>
            <?php endif; ?>
        </div>
        <div class="card-body p-0">
            <?php if (!$has_duplicates): ?>
                <div class="p-4 text-center text-muted">
                    <div class="fs-1 mb-2">🎉</div>
                    <p class="mb-0 fw-600 text-dark">Ang iyong database ay malinis at walang duplicate records!</p>
                    <p class="small text-muted mb-0">Kung may hindi pa rin nagtutugma, pakisigurong pareho ang mga numero sa Data Entry sa Local at Live.</p>
                </div>
            <?php else: ?>
                <div class="p-3 bg-light border-bottom small text-muted">
                    <i class="bi bi-info-circle-fill text-primary me-1"></i>
                    Ang mga listahan sa ibaba ay mga rows sa database na may magkakaparehong Grade, Strand, Semester, at School Year. Ang mga dulo o lumang duplicate rows na ito ang sanhi kaya lumalaki ang bilang sa live dashboard kumpara sa local.
                </div>
                
                <div class="p-3">
                    <?php if (count($dup_enroll) > 0): ?>
                        <h6 class="fw-bold text-dark mb-2"><i class="bi bi-table me-2 text-danger"></i>Duplicate Rows in Enrollment Data (<?= count($dup_enroll) ?> group/s)</h6>
                        <div class="table-responsive mb-4">
                            <table class="table table-bordered table-striped small align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>School Year</th>
                                        <th>Grade Level</th>
                                        <th>Strand</th>
                                        <th>Semester</th>
                                        <th class="text-center">Count</th>
                                        <th>Record IDs</th>
                                        <th>Enrollment Values</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($dup_enroll as $d): ?>
                                    <tr>
                                        <td class="fw-bold"><?= htmlspecialchars($d['school_year']) ?></td>
                                        <td><?= htmlspecialchars($d['grade_name']) ?></td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($d['strand_code'] ?? 'N/A') ?></span></td>
                                        <td><?= htmlspecialchars($d['semester']) ?></td>
                                        <td class="text-center fw-bold text-danger"><?= $d['count'] ?>x</td>
                                        <td><code><?= htmlspecialchars($d['ids']) ?></code></td>
                                        <td class="fw-600 text-danger"><?= htmlspecialchars($d['values_list']) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>

                    <?php if (count($dup_rep) > 0): ?>
                        <h6 class="fw-bold text-dark mb-2"><i class="bi bi-arrow-repeat me-2 text-danger"></i>Duplicate Rows in Repeaters Data (<?= count($dup_rep) ?> group/s)</h6>
                        <div class="table-responsive mb-4">
                            <table class="table table-bordered table-striped small align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>School Year</th>
                                        <th>Grade Level</th>
                                        <th>Strand</th>
                                        <th>Semester</th>
                                        <th class="text-center">Count</th>
                                        <th>Record IDs</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($dup_rep as $d): ?>
                                    <tr>
                                        <td class="fw-bold"><?= htmlspecialchars($d['school_year']) ?></td>
                                        <td><?= htmlspecialchars($d['grade_name']) ?></td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($d['strand_code'] ?? 'N/A') ?></span></td>
                                        <td><?= htmlspecialchars($d['semester']) ?></td>
                                        <td class="text-center fw-bold text-danger"><?= $d['count'] ?>x</td>
                                        <td><code><?= htmlspecialchars($d['ids']) ?></code></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>

                    <?php if (count($dup_drop) > 0): ?>
                        <h6 class="fw-bold text-dark mb-2"><i class="bi bi-person-dash me-2 text-danger"></i>Duplicate Rows in Dropouts Data (<?= count($dup_drop) ?> group/s)</h6>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped small align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>School Year</th>
                                        <th>Grade Level</th>
                                        <th>Strand</th>
                                        <th>Semester</th>
                                        <th class="text-center">Count</th>
                                        <th>Record IDs</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($dup_drop as $d): ?>
                                    <tr>
                                        <td class="fw-bold"><?= htmlspecialchars($d['school_year']) ?></td>
                                        <td><?= htmlspecialchars($d['grade_name']) ?></td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($d['strand_code'] ?? 'N/A') ?></span></td>
                                        <td><?= htmlspecialchars($d['semester']) ?></td>
                                        <td class="text-center fw-bold text-danger"><?= $d['count'] ?>x</td>
                                        <td><code><?= htmlspecialchars($d['ids']) ?></code></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ── RAW ENROLLMENT RECORDS AUDIT ── -->
    <div class="card border shadow-sm">
        <div class="card-header bg-light py-3">
            <h6 class="fw-bold mb-0 text-dark"><i class="bi bi-list-columns-reverse me-2 text-primary-nhs"></i>Detailed Database Records (S.Y. 2024-2025 & 2025-2026)</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm table-hover table-bordered small">
                    <thead class="table-dark">
                        <tr>
                            <th>S.Y.</th>
                            <th>Grade Level</th>
                            <th>Level Type</th>
                            <th>Strand</th>
                            <th>Semester</th>
                            <th class="text-center">Total BOSY</th>
                            <th class="text-center text-primary">♂ Male</th>
                            <th class="text-center text-danger">♀ Female</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($all_enrollments as $r): ?>
                        <tr>
                            <td class="fw-bold"><?= htmlspecialchars($r['school_year']) ?></td>
                            <td class="fw-600"><?= htmlspecialchars($r['grade_name']) ?></td>
                            <td>
                                <span class="badge <?= $r['level_type'] === 'Junior High' ? 'bg-info text-dark' : 'bg-primary' ?>">
                                    <?= $r['level_type'] ?>
                                </span>
                            </td>
                            <td><code><?= htmlspecialchars($r['strand_code'] ?? 'N/A') ?></code></td>
                            <td><span class="fw-500 text-muted"><?= htmlspecialchars($r['semester']) ?></span></td>
                            <td class="text-center fw-bold"><?= number_format($r['bosy_enrollment']) ?></td>
                            <td class="text-center text-primary"><?= number_format($r['male_count']) ?></td>
                            <td class="text-center text-danger"><?= number_format($r['female_count']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($all_enrollments)): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-4">No records found for these school years.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
