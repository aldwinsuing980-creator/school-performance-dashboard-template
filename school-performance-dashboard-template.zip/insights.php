<?php
require_once __DIR__ . '/config/session.php';
require_login();

// Restrict strictly to Admin and Faculty roles
if (!has_role('Admin', 'Faculty')) {
    $page_title = 'Access Denied';
    $breadcrumb = 'Access Denied';
    include 'includes/header.php';
    echo '<div class="d-flex align-items-center justify-content-center" style="min-height:50vh;">
      <div class="text-center">
        <div style="font-size:4rem;margin-bottom:1rem;">🔒</div>
        <h2 class="fw-700 text-dark mb-2">Access Denied</h2>
        <p class="text-muted mb-3">You do not have permission to view this page. This area is reserved for staff members.</p>
        <a href="dashboard.php" class="btn-primary-nhs"><i class="bi bi-arrow-left me-1"></i> Back to Dashboard</a>
      </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

$page_title = 'Management Insights';
$breadcrumb = 'Insights';

$sy_rows = $pdo->query("SELECT DISTINCT school_year FROM enrollment_data ORDER BY school_year DESC")->fetchAll();
$sy_list  = array_column($sy_rows, 'school_year');
$sel_sy   = $_GET['sy'] ?? ($sy_list[0] ?? '2025-2026');

// ── Data collection ──────────────────────────────────────────
$total_enroll_q = $pdo->prepare("
  SELECT COALESCE(SUM(
    CASE
      WHEN gl.level_type='Senior High' THEN (CASE WHEN e.semester='1st Sem' THEN e.bosy_enrollment ELSE 0 END)
      ELSE e.bosy_enrollment
    END
  ),0)
  FROM enrollment_data e
  JOIN grade_levels gl ON gl.id = e.grade_level_id
  WHERE e.school_year=?
");
$total_enroll_q->execute([$sel_sy]); $total_enroll = (int)$total_enroll_q->fetchColumn();

// JHS & SHS enrollment breakdown
$jhs_enroll_q = $pdo->prepare("
  SELECT COALESCE(SUM(e.bosy_enrollment),0)
  FROM enrollment_data e
  JOIN grade_levels gl ON gl.id = e.grade_level_id
  WHERE e.school_year=? AND gl.level_type='Junior High'
");
$jhs_enroll_q->execute([$sel_sy]); $jhs_enroll_kpi = (int)$jhs_enroll_q->fetchColumn();

$shs_enroll_q = $pdo->prepare("
  SELECT COALESCE(SUM(e.bosy_enrollment),0)
  FROM enrollment_data e
  JOIN grade_levels gl ON gl.id = e.grade_level_id
  WHERE e.school_year=? AND gl.level_type='Senior High' AND e.semester='1st Sem'
");
$shs_enroll_q->execute([$sel_sy]); $shs_enroll_kpi = (int)$shs_enroll_q->fetchColumn();

$total_drop_q = $pdo->prepare("SELECT COALESCE(SUM(dropouts_count),0) FROM dropouts_data WHERE school_year=?");
$total_drop_q->execute([$sel_sy]); $total_dropouts = (int)$total_drop_q->fetchColumn();

$total_rep_q = $pdo->prepare("SELECT COALESCE(SUM(repeaters_count),0) FROM repeaters_data WHERE school_year=?");
$total_rep_q->execute([$sel_sy]); $total_repeaters = (int)$total_rep_q->fetchColumn();

$dropout_rate  = $total_enroll > 0 ? round($total_dropouts/$total_enroll*100,2) : 0;
$repeater_rate = $total_enroll > 0 ? round($total_repeaters/$total_enroll*100,2) : 0;

// Per-grade dropout
$grade_drop_q = $pdo->prepare("
  SELECT 
    gl.id,
    gl.grade_name, 
    gl.level_type,
    (
      SELECT COALESCE(SUM(
        CASE 
          WHEN gl.level_type = 'Senior High' THEN (CASE WHEN e.semester = '1st Sem' THEN e.bosy_enrollment ELSE 0 END)
          ELSE e.bosy_enrollment
        END
      ),0)
      FROM enrollment_data e
      WHERE e.grade_level_id = gl.id AND e.school_year = ?
    ) as enroll,
    (
      SELECT COALESCE(SUM(d.dropouts_count),0)
      FROM dropouts_data d
      WHERE d.grade_level_id = gl.id AND d.school_year = ?
    ) as drops,
    (
      SELECT COALESCE(SUM(r.repeaters_count),0)
      FROM repeaters_data r
      WHERE r.grade_level_id = gl.id AND r.school_year = ?
    ) as reps
  FROM grade_levels gl
  ORDER BY gl.id
");
$grade_drop_q->execute([$sel_sy,$sel_sy,$sel_sy]);
$grade_stats = $grade_drop_q->fetchAll();

// Seats
$seat_q = $pdo->prepare("SELECT COALESCE(SUM(available_seats),0) FROM seats_data WHERE school_year=?");
$seat_q->execute([$sel_sy]); $total_seats = (int)$seat_q->fetchColumn();
$seat_ratio  = $total_enroll > 0 ? round($total_seats/$total_enroll*100,1) : 0;

// Classrooms area
$cls_q = $pdo->query("SELECT COALESCE(SUM(CASE WHEN is_functional=1 THEN total_area ELSE 0 END),0) as area, COUNT(*) as total, SUM(is_functional) as func FROM classrooms");
$cls   = $cls_q->fetch();
$area_per_student = $total_enroll > 0 ? round((float)$cls['area']/$total_enroll,2) : 0;
$util_pct = $cls['total'] > 0 ? round($cls['func']/$cls['total']*100,1) : 0;

// Science teachers
$sci_q = $pdo->prepare("SELECT COALESCE(SUM(teacher_count),0) FROM teachers_per_area WHERE learning_area LIKE '%Science%' AND school_year=?");
$sci_q->execute([$sel_sy]); $sci_count = (int)$sci_q->fetchColumn();

// Enrollment trend (3 years)
$trend_q = $pdo->query("
  SELECT e.school_year, 
    COALESCE(SUM(
      CASE
        WHEN gl.level_type='Senior High' THEN (CASE WHEN e.semester='1st Sem' THEN e.bosy_enrollment ELSE 0 END)
        ELSE e.bosy_enrollment
      END
    ),0) as total
  FROM enrollment_data e
  JOIN grade_levels gl ON gl.id = e.grade_level_id
  GROUP BY e.school_year 
  ORDER BY e.school_year ASC
");
$trend   = $trend_q->fetchAll();
$last3   = array_slice($trend, -3);
$forecast_growth = 0; $forecast_next = 0;
if(count($last3) >= 2){
    $vals   = array_column($last3,'total');
    $growth = 0;
    for($i=1;$i<count($vals);$i++) $growth += ($vals[$i]-$vals[$i-1])/$vals[$i-1]*100;
    $forecast_growth = round($growth/(count($vals)-1),1);
    $forecast_next   = round(end($vals)*(1+$forecast_growth/100));
}

// Generate insights
$insights = [];

// Scenario 1: High dropout per grade
foreach($grade_stats as $gs){
    $g_rate = $gs['enroll']>0 ? round($gs['drops']/$gs['enroll']*100,1) : 0;
    if($g_rate > 10){
        $insights[] = [
            'type'  => 'alert-type',
            'icon'  => '⚠️',
            'label' => 'HIGH DROPOUT ALERT',
            'title' => "{$gs['grade_name']} — High Dropout Rate",
            'body'  => "{$gs['grade_name']} shows a high dropout rate of {$g_rate}% ({$gs['drops']} students). Investigation and student intervention programs are highly recommended. Consider counseling services, family outreach, and financial assistance programs.",
        ];
    }
}

// Scenario 2: Overcrowding
if($seat_ratio < 90){
    $shortage = $total_enroll - $total_seats;
    $insights[] = [
        'type'  => 'facility',
        'icon'  => '🏗️',
        'label' => 'FACILITY ALERT',
        'title' => 'Overcrowding Detected — Seat Shortage',
        'body'  => "Seat sufficiency ratio is {$seat_ratio}% ({$shortage} seats short). Additional classrooms or shifting schedules are recommended. Current enrollment: ".number_format($total_enroll).", Available seats: ".number_format($total_seats).".",
    ];
}
if($area_per_student < 1.0 && $area_per_student > 0){
    $insights[] = [
        'type'  => 'facility',
        'icon'  => '🏗️',
        'label' => 'SPACE CONCERN',
        'title' => 'Floor Area Below DepEd Standard',
        'body'  => "Floor area per student is {$area_per_student} sqm, below the DepEd standard of 1.4 sqm/student. Classroom utilization is at {$util_pct}%. Review room scheduling and consider additional infrastructure.",
    ];
}

// Scenario 3: Science understaffed
if($sci_count < 2){
    $insights[] = [
        'type'  => 'resource',
        'icon'  => '👩‍🏫',
        'label' => 'STAFFING GAP',
        'title' => 'Science Learning Area — Understaffed',
        'body'  => "Science Learning Area has only {$sci_count} teacher(s). This may affect learning quality and increase teaching load. Hiring additional Science personnel is strongly advised to meet curriculum standards.",
    ];
}
// Check all areas with count=1
$understaffed_q = $pdo->prepare("SELECT learning_area, teacher_count FROM teachers_per_area WHERE teacher_count=1 AND school_year=?");
$understaffed_q->execute([$sel_sy]);
foreach($understaffed_q->fetchAll() as $u){
    if(stripos($u['learning_area'],'Science')===false){
        $area_display = htmlspecialchars($u['learning_area']);
        if ($area_display === 'Araling Panlipunan') $area_display = 'Social Studies (Araling Panlipunan)';
        if ($area_display === 'ESP/Values') $area_display = 'Values Education (EsP)';
        $insights[] = [
            'type'  => 'resource',
            'icon'  => '👨‍🏫',
            'label' => 'STAFFING NOTE',
            'title' => "{$area_display} — Minimum Staffing",
            'body'  => "{$area_display} has only 1 teacher, which represents minimum coverage. This may pose risks if the teacher is absent. Consider designating a backup or co-teacher.",
        ];
    }
}

// Scenario 4: Perfect grade
foreach($grade_stats as $gs){
    if($gs['enroll']>0 && $gs['drops']==0 && $gs['reps']==0){
        $insights[] = [
            'type'  => 'success',
            'icon'  => '🎉',
            'label' => 'ACADEMIC SUCCESS',
            'title' => "{$gs['grade_name']} — Excellent Performance",
            'body'  => "{$gs['grade_name']} shows excellent performance with 0 repeaters and 0 dropouts this S.Y. {$sel_sy}. Document and replicate best practices to other grade levels.",
        ];
    }
}

// Scenario 5: Enrollment forecast
if($forecast_growth > 0 && $forecast_next > 0){
    $insights[] = [
        'type'  => 'forecast',
        'icon'  => '📈',
        'label' => 'PREDICTIVE FORECAST',
        'title' => 'Enrollment Growth Projected',
        'body'  => "Based on the last 3 school years, enrollment has grown by an average of {$forecast_growth}% annually. Projected total enrollment for next school year: approximately ".number_format($forecast_next)." students. Prepare additional classrooms, teaching staff, and learning materials.",
    ];
} elseif($forecast_growth < 0){
    $insights[] = [
        'type'  => 'alert-type',
        'icon'  => '📉',
        'label' => 'DECLINING ENROLLMENT',
        'title' => 'Enrollment Decline Observed',
        'body'  => "Enrollment has been declining by ".abs($forecast_growth)."% annually on average. Projected enrollment next year: approximately ".number_format($forecast_next)." students. Investigate causes and implement recruitment or retention strategies.",
    ];
}

// Repeater rate insight
if($repeater_rate > 8){
    $insights[] = [
        'type'  => 'alert-type',
        'icon'  => '🔄',
        'label' => 'HIGH REPEATER RATE',
        'title' => 'Above-Average Repeater Rate Detected',
        'body'  => "Overall repeater rate is {$repeater_rate}%, which is above the acceptable threshold of 5%. Review academic support programs, remedial classes, and learning continuity plans to address non-promotion causes.",
    ];
}

if(empty($insights)){
    $insights[] = [
        'type'  => 'success',
        'icon'  => '✅',
        'label' => 'ALL GOOD',
        'title' => 'No Critical Issues Detected',
        'body'  => "All KPIs for S.Y. {$sel_sy} are within acceptable ranges. Continue monitoring and maintaining current performance standards.",
    ];
}

// --- Begin Smart Dashboard Enhancements ---
// 1. Fetch total teacher counts
$jhs_teachers_q = $pdo->prepare("SELECT COALESCE(SUM(teacher_count),0) FROM teachers_per_grade WHERE school_year=?");
$jhs_teachers_q->execute([$sel_sy]);
$jhs_teachers = (int)$jhs_teachers_q->fetchColumn();

$shs_teachers_q = $pdo->prepare("SELECT COALESCE(SUM(teacher_count),0) FROM teachers_per_area WHERE level_type='Senior High' AND school_year=?");
$shs_teachers_q->execute([$sel_sy]);
$shs_teachers = (int)$shs_teachers_q->fetchColumn();

$total_teachers = $jhs_teachers + $shs_teachers;

// 2. Fetch JHS grade levels for Heatmap
$jhs_heatmap = [];
foreach ($grade_stats as $gs) {
    if ($gs['level_type'] === 'Junior High') {
        $g_enroll = (int)$gs['enroll'];
        $g_drops = (int)$gs['drops'];
        $g_reps = (int)$gs['reps'];
        $g_rate = $g_enroll > 0 ? round(($g_drops / $g_enroll) * 100, 2) : 0;
        $jhs_heatmap[] = [
            'grade_name' => $gs['grade_name'],
            'enroll' => $g_enroll,
            'drops' => $g_drops,
            'reps' => $g_reps,
            'rate' => $g_rate
        ];
    }
}

// 3. Fetch SHS strand levels for Heatmap
$shs_heatmap_q = $pdo->prepare("
  SELECT 
    gl.grade_name,
    gl.id as grade_level_id,
    st.id as strand_id,
    st.strand_code,
    st.strand_name,
    (
      SELECT COALESCE(SUM(e.bosy_enrollment), 0)
      FROM enrollment_data e
      WHERE e.grade_level_id = gl.id AND e.strand_id = st.id AND e.school_year = ? AND e.semester = '1st Sem'
    ) as enroll_1st,
    (
      SELECT COALESCE(SUM(e.bosy_enrollment), 0)
      FROM enrollment_data e
      WHERE e.grade_level_id = gl.id AND e.strand_id = st.id AND e.school_year = ? AND e.semester = '2nd Sem'
    ) as enroll_2nd,
    (
      SELECT COALESCE(SUM(d.dropouts_count), 0)
      FROM dropouts_data d
      WHERE d.grade_level_id = gl.id AND d.strand_id = st.id AND d.school_year = ?
    ) as drops,
    (
      SELECT COALESCE(SUM(r.repeaters_count), 0)
      FROM repeaters_data r
      WHERE r.grade_level_id = gl.id AND r.strand_id = st.id AND r.school_year = ?
    ) as reps
  FROM grade_levels gl
  CROSS JOIN strands st
  WHERE gl.level_type = 'Senior High'
  ORDER BY gl.id, st.id
");
$shs_heatmap_q->execute([$sel_sy, $sel_sy, $sel_sy, $sel_sy]);
$shs_heatmap_raw = $shs_heatmap_q->fetchAll();

$shs_heatmap = [];
$shs_grades = [
    5 => 'Grade 11',
    6 => 'Grade 12'
];

foreach ($shs_grades as $gl_id => $gl_name) {
    $total_enroll_1st = 0;
    $total_enroll_2nd = 0;
    
    foreach ($shs_heatmap_raw as $shr) {
        if ((int)$shr['grade_level_id'] === $gl_id) {
            $total_enroll_1st += (int)$shr['enroll_1st'];
            $total_enroll_2nd += (int)$shr['enroll_2nd'];
        }
    }
    
    // Fetch actual dropouts for this grade level in the database (semester aware)
    $q_drp = $pdo->prepare("
        SELECT COALESCE(SUM(d.dropouts_count), 0) 
        FROM dropouts_data d
        JOIN grade_levels gl ON gl.id = d.grade_level_id
        WHERE d.grade_level_id = ? AND d.school_year = ?
          AND (
            (gl.level_type = 'Senior High' AND d.semester IN ('1st Sem', '2nd Sem'))
            OR (gl.level_type != 'Senior High' AND (d.semester = 'Full Year' OR d.semester IS NULL))
          )
    ");
    $q_drp->execute([$gl_id, $sel_sy]);
    $total_drops = (int)$q_drp->fetchColumn();

    // Fetch actual repeaters for this grade level in the database (semester aware)
    $q_rep = $pdo->prepare("
        SELECT COALESCE(SUM(r.repeaters_count), 0) 
        FROM repeaters_data r
        JOIN grade_levels gl ON gl.id = r.grade_level_id
        WHERE r.grade_level_id = ? AND r.school_year = ?
          AND (
            (gl.level_type = 'Senior High' AND r.semester IN ('1st Sem', '2nd Sem'))
            OR (gl.level_type != 'Senior High' AND (r.semester = 'Full Year' OR r.semester IS NULL))
          )
    ");
    $q_rep->execute([$gl_id, $sel_sy]);
    $total_reps = (int)$q_rep->fetchColumn();
    
    if ($total_enroll_1st === 0 && $total_enroll_2nd === 0) continue;
    
    $effective_drops = $total_drops > 0 ? $total_drops : max(0, $total_enroll_1st - $total_enroll_2nd);
    $rate = $total_enroll_1st > 0 ? round(($effective_drops / $total_enroll_1st) * 100, 2) : 0;
    
    $shs_heatmap[] = [
        'grade_name' => $gl_name,
        'strand_code' => 'SHS',
        'strand_name' => 'Senior High School',
        'enroll' => $total_enroll_1st,
        'drops' => $effective_drops,
        'reps' => $total_reps,
        'rate' => $rate
    ];
}
// --- End Smart Dashboard Enhancements ---

include 'includes/header.php';
?>
<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
  <div class="section-header mb-0">
    <h1 class="section-title"><i class="bi bi-lightbulb-fill me-2 text-primary-nhs"></i>Management Insights & Recommendations</h1>
    <p class="section-sub">AI-generated analytics for S.Y. <?= htmlspecialchars($sel_sy) ?> — <?= count($insights) ?> insight(s) generated</p>
  </div>
  <button class="btn-primary-nhs" onclick="exportToPDF('insightExport','NHS_Insights_<?= $sel_sy ?>.pdf')">
    <i class="bi bi-file-earmark-pdf"></i> Export PDF
  </button>
</div>

<!-- Summary KPIs -->
<div class="row g-3 mb-4" id="kpiRow">

  <!-- JHS Enrollment -->
  <div class="col-6 col-md-4 col-xl-2">
    <div class="kpi-card" style="border-left:4px solid var(--primary);background:linear-gradient(135deg,#e8ecf8 0%,#fff 60%)">
      <div class="d-flex align-items-center justify-content-between mb-2">
        <span style="font-size:.68rem;font-weight:800;letter-spacing:.6px;color:var(--primary);background:#dce2f5;padding:2px 9px;border-radius:20px">JHS</span>
        <i class="bi bi-mortarboard-fill" style="color:var(--primary);font-size:1.1rem"></i>
      </div>
      <div class="kpi-value" style="font-size:1.5rem;color:var(--primary)"><?= number_format($jhs_enroll_kpi) ?></div>
      <div class="kpi-label">Junior High Enrollees</div>
    </div>
  </div>

  <!-- SHS Enrollment -->
  <div class="col-6 col-md-4 col-xl-2">
    <div class="kpi-card" style="border-left:4px solid var(--accent-dark);background:linear-gradient(135deg,#fdf5dc 0%,#fff 60%)">
      <div class="d-flex align-items-center justify-content-between mb-2">
        <span style="font-size:.68rem;font-weight:800;letter-spacing:.6px;color:var(--accent-dark);background:#fbeecb;padding:2px 9px;border-radius:20px">SHS</span>
        <i class="bi bi-person-workspace" style="color:var(--accent-dark);font-size:1.1rem"></i>
      </div>
      <div class="kpi-value" style="font-size:1.5rem;color:var(--accent-dark)"><?= number_format($shs_enroll_kpi) ?></div>
      <div class="kpi-label">Senior High Enrollees <span style="font-size:.65rem;opacity:.7">(1st Sem)</span></div>
    </div>
  </div>

  <?php
    $other_kpis = [
      ['label'=>'Dropout Rate','value'=>$dropout_rate.'%','icon'=>'bi-person-dash-fill','color'=>$dropout_rate>10?'red':($dropout_rate>5?'yellow':'green')],
      ['label'=>'Repeater Rate','value'=>$repeater_rate.'%','icon'=>'bi-arrow-repeat','color'=>$repeater_rate>8?'red':($repeater_rate>3?'yellow':'green')],
      ['label'=>'Seat Sufficiency','value'=>$seat_ratio.'%','icon'=>'bi-person-workspace','color'=>$seat_ratio>=100?'green':($seat_ratio>=90?'yellow':'red')],
      ['label'=>'Area / Student','value'=>$area_per_student.' sqm','icon'=>'bi-grid-3x3','color'=>$area_per_student>=1.4?'green':($area_per_student>=1.0?'yellow':'red')],
      ['label'=>'Forecast Growth','value'=>($forecast_growth>=0?'+':'').$forecast_growth.'%','icon'=>'bi-graph-up-arrow','color'=>$forecast_growth>0?'green':($forecast_growth==0?'yellow':'red')],
    ];
    foreach($other_kpis as $kpi):
  ?>
  <div class="col-6 col-md-4 col-xl-2">
    <div class="kpi-card kpi-info">
      <div class="kpi-icon <?= $kpi['color'] ?> mb-2"><i class="bi <?= $kpi['icon'] ?>"></i></div>
      <div class="kpi-value" style="font-size:1.3rem"><?= $kpi['value'] ?></div>
      <div class="kpi-label"><?= $kpi['label'] ?></div>
    </div>
  </div>
  <?php endforeach; ?>

</div>

<!-- Immediate Action Alert Banner -->
<?php
  $critical_insights = array_filter($insights, fn($i) => in_array($i['type'], ['alert-type','facility']));
  $critical_count = count($critical_insights);
?>
<?php if($critical_count > 0): ?>
<div class="immediate-action-banner" id="immediateBanner" role="alert">
  <div class="immediate-action-inner">
    <div class="immediate-action-left">
      <div class="immediate-action-pulse"><span class="pulse-ring"></span><i class="bi bi-exclamation-triangle-fill"></i></div>
      <div>
        <div class="immediate-action-title">⚡ Immediate Action Required</div>
        <div class="immediate-action-sub">
          <?= $critical_count ?> critical issue<?= $critical_count > 1 ? 's require' : ' requires' ?> your urgent attention for S.Y. <?= htmlspecialchars($sel_sy) ?>:
          <ul class="immediate-action-list mt-1 mb-0">
            <?php foreach($critical_insights as $ci): ?>
              <li><?= htmlspecialchars($ci['title']) ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
    </div>
    <button class="immediate-action-close" onclick="document.getElementById('immediateBanner').style.display='none'" aria-label="Dismiss">
      <i class="bi bi-x-lg"></i>
    </button>
  </div>
</div>
<?php endif; ?>

<!-- Insights -->
<style>
/* Smart Dashboard Enhancement Styles */
.ews-container {
    margin-bottom: 2.5rem;
}
.ews-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 1rem;
}
.ews-card {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 1.15rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.02);
    transition: all 0.22s cubic-bezier(0.4, 0, 0.2, 1);
    cursor: pointer;
    position: relative;
    overflow: hidden;
}
.ews-card::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 4px;
    height: 100%;
}
.ews-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.04);
}

/* Risk Levels */
.ews-low {
    background: linear-gradient(135deg, rgba(22, 163, 74, 0.03) 0%, #fff 100%);
    border-color: rgba(22, 163, 74, 0.15);
}
.ews-low::after {
    background-color: #16a34a;
}
.ews-med {
    background: linear-gradient(135deg, rgba(217, 119, 6, 0.03) 0%, #fff 100%);
    border-color: rgba(217, 119, 6, 0.15);
}
.ews-med::after {
    background-color: #d97706;
}
.ews-high {
    background: linear-gradient(135deg, rgba(220, 38, 38, 0.03) 0%, #fff 100%);
    border-color: rgba(220, 38, 38, 0.15);
    animation: pulsing-border 2s infinite ease-in-out;
}
.ews-high::after {
    background-color: #dc2626;
    animation: pulsing-glow-high 2s infinite ease-in-out;
}

@keyframes pulsing-border {
    0% { border-color: rgba(220, 38, 38, 0.15); }
    50% { border-color: rgba(220, 38, 38, 0.45); box-shadow: 0 0 10px rgba(220, 38, 38, 0.08); }
    100% { border-color: rgba(220, 38, 38, 0.15); }
}

@keyframes pulsing-glow-high {
    0% { opacity: 0.7; }
    50% { opacity: 1; }
    100% { opacity: 0.7; }
}

.ews-badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 20px;
    font-size: 0.65rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 0.5rem;
}
.badge-low {
    background-color: rgba(22, 163, 74, 0.1);
    color: #16a34a;
}
.badge-med {
    background-color: rgba(217, 119, 6, 0.1);
    color: #d97706;
}
.badge-high {
    background-color: rgba(220, 38, 38, 0.1);
    color: #dc2626;
}

.ews-grade {
    font-weight: 700;
    color: var(--text-dark);
    font-size: 0.95rem;
    margin-bottom: 0.15rem;
}
.ews-strand {
    font-size: 0.7rem;
    color: var(--text-muted);
    margin-bottom: 0.5rem;
    font-weight: 500;
}
.ews-metrics {
    display: flex;
    justify-content: space-between;
    font-size: 0.75rem;
    color: #4b5563;
    border-top: 1px dashed #e2e8f0;
    padding-top: 0.5rem;
    margin-top: 0.5rem;
}
.ews-rate {
    font-size: 1.15rem;
    font-weight: 800;
    letter-spacing: -0.5px;
    display: flex;
    align-items: baseline;
}
.ews-rate span {
    font-size: 0.7rem;
    font-weight: 500;
    color: var(--text-muted);
    margin-left: 1px;
}

/* AI Predictor Slider */
.slider-container {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 2rem;
}
.slider-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}
.slider-title {
    font-weight: 700;
    color: var(--text-dark);
    font-size: 0.95rem;
}
.slider-value {
    background: var(--primary);
    color: #fff;
    font-weight: 700;
    padding: 3px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    box-shadow: 0 4px 6px -1px rgba(15, 76, 129, 0.15);
}
.custom-slider {
    -webkit-appearance: none;
    width: 100%;
    height: 6px;
    border-radius: 5px;
    background: #cbd5e1;
    outline: none;
    margin: 1rem 0;
    transition: all 0.2s;
}
.custom-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    appearance: none;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: var(--primary);
    border: 3px solid #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
    cursor: pointer;
    transition: all 0.15s;
}
.custom-slider::-webkit-slider-thumb:hover {
    transform: scale(1.15);
    box-shadow: 0 0 12px rgba(15, 76, 129, 0.35);
}
.slider-labels {
    display: flex;
    justify-content: space-between;
    font-size: 0.72rem;
    color: var(--text-muted);
    font-weight: 600;
}

/* Modals styling */
.custom-modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.45);
    backdrop-filter: blur(4px);
    z-index: 1050;
    display: none;
    overflow-y: auto;
}
.custom-modal-dialog {
    max-width: 550px;
    margin: 3.5rem auto;
    background: #fff;
    border-radius: 16px;
    border: 1px solid #cbd5e1;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    animation: slide-down 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    overflow: hidden;
}
@keyframes slide-down {
    0% { transform: translateY(-30px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
}
.custom-modal-header {
    background: linear-gradient(135deg, #0F4C81 0%, #1e40af 100%);
    color: #fff;
    padding: 1.25rem 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.custom-modal-body {
    padding: 1.5rem;
}
.custom-modal-footer {
    padding: 1rem 1.5rem;
    border-top: 1px solid #e2e8f0;
    display: flex;
    justify-content: flex-end;
    background: #f8fafc;
}
.custom-modal-close {
    background: none;
    border: none;
    color: rgba(255, 255, 255, 0.85);
    font-size: 1.35rem;
    cursor: pointer;
    transition: color 0.15s;
    line-height: 1;
}
.custom-modal-close:hover {
    color: #fff;
}

/* Timeline/Action Steps style */
.timeline-step {
    border-left: 2px solid #e2e8f0;
    padding-left: 1.25rem;
    position: relative;
}
.timeline-step::before {
    content: '';
    position: absolute;
    top: 2px;
    left: -6px;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background-color: var(--primary);
    border: 2px solid #fff;
    box-shadow: 0 0 0 2px rgba(15, 76, 129, 0.15);
}
.timeline-step:last-child {
    border-left-color: transparent;
}

@media print {
    .custom-slider, .slider-header, .ews-card:hover {
        display: none !important;
    }
}

/* --- Dark Mode Overrides for Insights Cards & Panels --- */
[data-theme="dark"] .chart-card {
    background: #0f172a !important;
    border-color: #1e293b !important;
}

[data-theme="dark"] .kpi-card {
    background: #1e293b !important;
    color: #f8fafc !important;
    border-color: #334155 !important;
}

[data-theme="dark"] #projEnrolleesCard {
    background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%) !important;
}

[data-theme="dark"] #projClassroomsCard,
[data-theme="dark"] #projSeatsCard,
[data-theme="dark"] #projTeachersCard {
    background: linear-gradient(135deg, rgba(22, 163, 74, 0.1) 0%, #1e293b 100%) !important;
    color: #f8fafc !important;
    border-left-color: #16a34a !important;
}

[data-theme="dark"] #projClassroomsCard.deficit,
[data-theme="dark"] #projSeatsCard.deficit,
[data-theme="dark"] #projTeachersCard.deficit {
    background: linear-gradient(135deg, rgba(220, 38, 38, 0.1) 0%, #1e293b 100%) !important;
    color: #f8fafc !important;
    border-left-color: #dc2626 !important;
}

[data-theme="dark"] .col-md-6 .rounded-3 {
    color: #f8fafc !important;
}

[data-theme="dark"] .col-md-6 .rounded-3 .text-dark {
    color: #38bdf8 !important;
}

[data-theme="dark"] .col-md-6 .rounded-3 .text-muted {
    color: #cbd5e1 !important;
}

[data-theme="dark"] .col-md-6 .rounded-3[style*="background:#f0f7ff"],
[data-theme="dark"] .col-md-6 .rounded-3[style*="background: rgb(240, 247, 255)"] {
    background: rgba(15, 76, 129, 0.15) !important;
    border-color: #0F4C81 !important;
}

[data-theme="dark"] .col-md-6 .rounded-3[style*="background:#f0fff4"],
[data-theme="dark"] .col-md-6 .rounded-3[style*="background: rgb(240, 255, 244)"] {
    background: rgba(22, 163, 74, 0.15) !important;
    border-color: #16a34a !important;
}

[data-theme="dark"] .col-md-6 .rounded-3[style*="background:#fffbf0"],
[data-theme="dark"] .col-md-6 .rounded-3[style*="background: rgb(255, 251, 240)"] {
    background: rgba(217, 119, 6, 0.15) !important;
    border-color: #d97706 !important;
}

[data-theme="dark"] .col-md-6 .rounded-3[style*="background:#f8f0ff"],
[data-theme="dark"] .col-md-6 .rounded-3[style*="background: rgb(248, 240, 255)"] {
    background: rgba(124, 58, 237, 0.15) !important;
    border-color: #7c3aed !important;
}

[data-theme="dark"] .ews-card {
    background: #1e293b !important;
    border-color: #334155 !important;
}

[data-theme="dark"] .ews-card .ews-grade {
    color: #f8fafc !important;
}

[data-theme="dark"] .ews-card.ews-low {
    background: linear-gradient(135deg, rgba(22, 163, 74, 0.1) 0%, #1e293b 100%) !important;
    border-color: rgba(22, 163, 74, 0.3) !important;
}

[data-theme="dark"] .ews-card.ews-med {
    background: linear-gradient(135deg, rgba(217, 119, 6, 0.1) 0%, #1e293b 100%) !important;
    border-color: rgba(217, 119, 6, 0.3) !important;
}

[data-theme="dark"] .ews-card.ews-high {
    background: linear-gradient(135deg, rgba(220, 38, 38, 0.1) 0%, #1e293b 100%) !important;
    border-color: rgba(220, 38, 38, 0.3) !important;
}

[data-theme="dark"] .slider-container {
    background: #0f172a !important;
    border-color: #1e293b !important;
}

[data-theme="dark"] .slider-title {
    color: #cbd5e1 !important;
}

[data-theme="dark"] .slider-labels span {
    color: #64748b !important;
}
</style>

<div id="insightExport">
  <!-- 1. Early Warning System (EWS) Heatmap Section -->
  <div class="chart-card mb-4" style="background:#fff;">
    <div class="chart-card-title text-danger"><i class="bi bi-shield-fill-exclamation me-2"></i>🚨 Early Warning System (EWS) — At-Risk Students Heatmap</div>
    <div class="chart-card-sub mb-3">Color-coded student retention risk levels dynamically calculated based on dropouts rate. Click on a card to see custom intervention plan.</div>
    
    <div class="ews-grid mb-2">
      <!-- JHS Cards -->
      <?php foreach($jhs_heatmap as $card):
        $risk = $card['rate'] > 5 ? 'high' : ($card['rate'] >= 2 ? 'med' : 'low');
        $risk_label = $risk === 'high' ? '🔴 High Risk' : ($risk === 'med' ? '🟡 Med Risk' : '🟢 Low Risk');
      ?>
      <div class="ews-card ews-<?= $risk ?>" onclick="openEwsModal('<?= htmlspecialchars($card['grade_name']) ?>', '', <?= $card['enroll'] ?>, <?= $card['drops'] ?>, <?= $card['reps'] ?>, <?= $card['rate'] ?>)">
        <div class="ews-badge badge-<?= $risk ?>"><?= $risk_label ?></div>
        <div class="ews-grade"><?= htmlspecialchars($card['grade_name']) ?></div>
        <div class="ews-strand">Junior High School</div>
        <div class="ews-metrics">
          <span>Enrollment: <strong><?= number_format($card['enroll']) ?></strong></span>
          <span>Dropouts: <strong><?= number_format($card['drops']) ?></strong></span>
        </div>
        <div class="ews-rate mt-2 text-<?= $risk === 'high' ? 'danger' : ($risk === 'med' ? 'warning' : 'success') ?>">
          <?= number_format($card['rate'], 1) ?>% <span>dropout rate</span>
        </div>
      </div>
      <?php endforeach; ?>

      <!-- SHS Strand Cards -->
      <?php foreach($shs_heatmap as $card):
        $risk = $card['rate'] > 5 ? 'high' : ($card['rate'] >= 2 ? 'med' : 'low');
        $risk_label = $risk === 'high' ? '🔴 High Risk' : ($risk === 'med' ? '🟡 Med Risk' : '🟢 Low Risk');
      ?>
      <div class="ews-card ews-<?= $risk ?>" onclick="openEwsModal('<?= htmlspecialchars($card['grade_name']) ?>', '<?= htmlspecialchars($card['strand_code']) ?>', <?= $card['enroll'] ?>, <?= $card['drops'] ?>, <?= $card['reps'] ?>, <?= $card['rate'] ?>)">
        <div class="ews-badge badge-<?= $risk ?>"><?= $risk_label ?></div>
        <div class="ews-grade"><?= htmlspecialchars($card['grade_name']) ?></div>
        <div class="ews-strand">Senior High School</div>
        <div class="ews-metrics">
          <span>Enroll (1st Sem): <strong><?= number_format($card['enroll']) ?></strong></span>
          <span>Dropouts: <strong><?= number_format($card['drops']) ?></strong></span>
        </div>
        <div class="ews-rate mt-2 text-<?= $risk === 'high' ? 'danger' : ($risk === 'med' ? 'warning' : 'success') ?>">
          <?= number_format($card['rate'], 1) ?>% <span>dropout rate</span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- 2. AI What-If Scenario Analysis & Resource Planner Section -->
  <div class="chart-card mb-4" style="background:#fff;">
    <div class="chart-card-title text-primary"><i class="bi bi-cpu-fill me-2"></i>🔮 AI What-If Analysis & Resource Simulation Planner</div>
    <div class="chart-card-sub mb-3">Interactive planner. Adjust the multiple parameters below or choose a preset scenario to dynamically calculate functional classroom capacity, student seats, and teacher plantilla staffing shortages in real-time.</div>
    
    <!-- Quick Scenario Presets -->
    <div class="d-flex flex-wrap gap-2 mb-3 align-items-center">
      <span class="small fw-700 text-muted me-2" style="font-size: 0.78rem;"><i class="bi bi-lightning-charge-fill text-warning"></i> Scenario Presets:</span>
      <button type="button" class="btn btn-sm btn-outline-primary px-3 fw-600 rounded-pill" style="font-size: 0.72rem;" onclick="applyPreset('default')">Default DepEd Standards</button>
      <button type="button" class="btn btn-sm btn-outline-success px-3 fw-600 rounded-pill" style="font-size: 0.72rem;" onclick="applyPreset('quality')">Quality Education (Smaller Classes)</button>
      <button type="button" class="btn btn-sm btn-outline-danger px-3 fw-600 rounded-pill" style="font-size: 0.72rem;" onclick="applyPreset('congested')">Congested Enrollment (Crisis Plan)</button>
    </div>

    <div class="slider-container py-3">
      <div class="row g-3">
        <!-- Slider 1: Growth Rate -->
        <div class="col-lg-4">
          <div class="slider-header mb-1">
            <span class="slider-title text-muted small uppercase fw-700" style="font-size: 0.75rem;"><i class="bi bi-graph-up-arrow text-primary"></i> Enrollment Growth:</span>
            <span class="slider-value bg-primary px-2 py-0.5 rounded-pill text-white small fw-700" id="sliderValLabel" style="font-size: 0.72rem;">+0.0%</span>
          </div>
          <input type="range" class="custom-slider my-2" id="growthRateSlider" min="-20" max="20" step="0.5" value="<?= $forecast_growth ?>" oninput="runWhatIf()">
          <div class="slider-labels d-flex justify-content-between text-muted" style="font-size: 10px;">
            <span>-20.0% (Decline)</span>
            <span>0.0%</span>
            <span>+20.0% (Growth)</span>
          </div>
        </div>

        <!-- Slider 2: Target Class Size -->
        <div class="col-lg-4">
          <div class="slider-header mb-1">
            <span class="slider-title text-muted small uppercase fw-700" style="font-size: 0.75rem;"><i class="bi bi-door-open-fill text-success"></i> Class Size Target:</span>
            <span class="slider-value bg-success px-2 py-0.5 rounded-pill text-white small fw-700" id="classSizeValLabel" style="font-size: 0.72rem;">40 std/room</span>
          </div>
          <input type="range" class="custom-slider my-2" id="classSizeSlider" min="25" max="55" step="1" value="40" oninput="runWhatIf()">
          <div class="slider-labels d-flex justify-content-between text-muted" style="font-size: 10px;">
            <span>25 (Quality)</span>
            <span>40 (DepEd Std)</span>
            <span>55 (Congested)</span>
          </div>
        </div>

        <!-- Slider 3: Teacher-to-Student Ratio -->
        <div class="col-lg-4">
          <div class="slider-header mb-1">
            <span class="slider-title text-muted small uppercase fw-700" style="font-size: 0.75rem;"><i class="bi bi-person-badge-fill text-warning"></i> Teacher Ratio:</span>
            <span class="slider-value bg-warning px-2 py-0.5 rounded-pill text-dark small fw-700" id="teacherRatioValLabel" style="font-size: 0.72rem;">35 std/teacher</span>
          </div>
          <input type="range" class="custom-slider my-2" id="teacherRatioSlider" min="20" max="50" step="1" value="35" oninput="runWhatIf()">
          <div class="slider-labels d-flex justify-content-between text-muted" style="font-size: 10px;">
            <span>20 (Focused)</span>
            <span>35 (DepEd Std)</span>
            <span>50 (Deficit)</span>
          </div>
        </div>
      </div>
    </div>
    
    <div class="row g-3">
      <!-- Projected Enrollees Card -->
      <div class="col-12 col-md-6 col-xl-3">
        <div class="kpi-card" id="projEnrolleesCard" style="border-left:4px solid var(--primary); transition: all 0.25s;">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <span style="font-size:.68rem; font-weight:800; color:var(--primary); background:rgba(107,155,232,0.15); padding:2px 9px; border-radius:20px;">PROJECTION</span>
            <i class="bi bi-people-fill text-primary" style="font-size:1.1rem;"></i>
          </div>
          <div class="kpi-value" id="projEnrolleesVal" style="font-size:1.5rem;">0</div>
          <div class="kpi-label">Projected Enrollees</div>
          <div class="small mt-2 text-muted" style="font-size: 11px;">Current: <strong><?= number_format($total_enroll) ?></strong> students</div>
        </div>
      </div>
      
      <!-- Functional Classrooms Card -->
      <div class="col-12 col-md-6 col-xl-3">
        <div class="kpi-card" id="projClassroomsCard" style="border-left:4px solid var(--success); transition: all 0.25s;">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <span style="font-size:.68rem; font-weight:800; color:var(--success); background:rgba(125,217,163,0.15); padding:2px 9px; border-radius:20px;">CLASSROOMS</span>
            <i class="bi bi-building text-success" style="font-size:1.1rem;"></i>
          </div>
          <div class="kpi-value" id="projClassroomsVal" style="font-size:1.5rem;">0</div>
          <div class="kpi-label">Classrooms Needed</div>
          <div class="small mt-2" id="projClassroomsGap" style="font-size:11px;">Loading...</div>
        </div>
      </div>
      
      <!-- Seats Sufficiency Card -->
      <div class="col-12 col-md-6 col-xl-3">
        <div class="kpi-card" id="projSeatsCard" style="border-left:4px solid var(--success); transition: all 0.25s;">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <span style="font-size:.68rem; font-weight:800; color:var(--success); background:rgba(125,217,163,0.15); padding:2px 9px; border-radius:20px;">SEATS</span>
            <i class="bi bi-person-workspace text-success" style="font-size:1.1rem;"></i>
          </div>
          <div class="kpi-value" id="projSeatsVal" style="font-size:1.5rem;">0</div>
          <div class="kpi-label">Seats Needed</div>
          <div class="small mt-2" id="projSeatsGap" style="font-size:11px;">Loading...</div>
        </div>
      </div>
      
      <!-- Teachers Sufficiency Card -->
      <div class="col-12 col-md-6 col-xl-3">
        <div class="kpi-card" id="projTeachersCard" style="border-left:4px solid var(--success); transition: all 0.25s;">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <span style="font-size:.68rem; font-weight:800; color:var(--success); background:rgba(125,217,163,0.15); padding:2px 9px; border-radius:20px;">TEACHERS</span>
            <i class="bi bi-person-workspace text-success" style="font-size:1.1rem;"></i>
          </div>
          <div class="kpi-value" id="projTeachersVal" style="font-size:1.5rem;">0</div>
          <div class="kpi-label">Teachers Needed</div>
          <div class="small mt-2" id="projTeachersGap" style="font-size:11px;">Loading...</div>
        </div>
      </div>
    </div>
    
    <div class="mt-3 p-3 rounded-3 border" style="background: var(--bg); border-color: var(--border); border-left:4px solid var(--primary);">
      <div class="d-flex gap-2 align-items-start">
        <i class="bi bi-cpu-fill text-primary mt-1" style="font-size:1.1rem;"></i>
        <div>
          <div class="fw-700 small" style="color: var(--text);">Resource Planning Recommendation:</div>
          <div class="small mt-1" id="projSummaryText" style="line-height: 1.5; color: var(--text-muted);">Simulating data...</div>
        </div>
      </div>
    </div>
  </div>

  <?php foreach($insights as $ins):
    $is_critical = in_array($ins['type'], ['alert-type','facility']);
  ?>
  <div class="insight-card <?= $ins['type'] ?>">
    <div class="d-flex align-items-start gap-3">
      <div class="insight-icon"><?= $ins['icon'] ?></div>
      <div class="flex-grow-1">
        <div class="d-flex align-items-center gap-2 mb-1 flex-wrap">
          <span class="insight-title"><?= htmlspecialchars($ins['title']) ?></span>
          <span class="kpi-badge badge-neutral" style="font-size:.68rem"><?= htmlspecialchars($ins['label']) ?></span>
          <?php if($is_critical): ?>
          <span class="immediate-action-badge"><i class="bi bi-lightning-charge-fill me-1"></i>IMMEDIATE ACTION</span>
          <?php endif; ?>
        </div>
        <div class="insight-body"><?= htmlspecialchars($ins['body']) ?></div>
      </div>
    </div>
  </div>
  <?php endforeach; ?>

  <!-- Prescriptive Recommendations Panel -->
  <?php
    // Gather dynamic variables for action plan
    $high_drop_grades = [];
    $high_rep_grades = [];
    $perfect_grades = [];
    foreach($grade_stats as $gs){
        $e = (int)$gs['enroll'];
        $d_pct = $e > 0 ? ($gs['drops'] / $e * 100) : 0;
        $r_pct = $e > 0 ? ($gs['reps'] / $e * 100) : 0;
        if($d_pct > 10) {
            $high_drop_grades[] = htmlspecialchars($gs['grade_name']) . " (" . round($d_pct, 1) . "% rate)";
        }
        if($r_pct > 8) {
            $high_rep_grades[] = htmlspecialchars($gs['grade_name']) . " (" . round($r_pct, 1) . "% rate)";
        }
        if($e > 0 && $gs['drops'] == 0 && $gs['reps'] == 0) {
            $perfect_grades[] = htmlspecialchars($gs['grade_name']);
        }
    }

    // Understaffed learning areas
    $understaffed_areas = [];
    $understaffed_q = $pdo->prepare("SELECT learning_area, teacher_count FROM teachers_per_area WHERE teacher_count <= 1 AND school_year=?");
    $understaffed_q->execute([$sel_sy]);
    foreach($understaffed_q->fetchAll() as $u){
        $area_name = htmlspecialchars($u['learning_area']);
        if ($area_name === 'Araling Panlipunan') $area_name = 'Social Studies (Araling Panlipunan)';
        if ($area_name === 'ESP/Values') $area_name = 'Values Education (EsP)';
        $understaffed_areas[] = $area_name . " (" . $u['teacher_count'] . " staff)";
    }

    // Academic Interventions
    $academic_bullets = [];
    if (!empty($high_rep_grades)) {
        $academic_bullets[] = "Implement targeted remedial classes and subject counseling specifically for <strong>" . implode(', ', $high_rep_grades) . "</strong> due to high non-promotion rates.";
        $academic_bullets[] = "Launch a Peer-Tutoring program and student study circles to improve subject mastery in high-risk levels.";
    } else {
        $academic_bullets[] = "Maintain current academic coaching systems and continue active tracking of student milestones.";
    }
    if (!empty($perfect_grades)) {
        $academic_bullets[] = "Document and replicate best practices from <strong>" . implode(', ', $perfect_grades) . "</strong> to other grade levels to maintain 100% promotion.";
    }
    $academic_bullets[] = "Conduct quarterly academic performance reviews per learning area to detect early learning gaps.";
    $academic_bullets[] = "Strengthen early warning systems for students at risk of non-promotion.";

    // Retention Programs
    $retention_bullets = [];
    if (!empty($high_drop_grades)) {
        $retention_bullets[] = "Mobilize the Parent-Teacher Association (PTA) to conduct urgent home visitations for at-risk students in <strong>" . implode(', ', $high_drop_grades) . "</strong>.";
        $retention_bullets[] = "Coordinate with local social workers (DSWD) to provide counseling and basic financial assistance/supplies specifically targeting students in <strong>" . implode(', ', $high_drop_grades) . "</strong>.";
    } else {
        $retention_bullets[] = "Establish a Student Care and Peer Support Group to continue maintaining Natividad HS's low dropout rate.";
    }
    $retention_bullets[] = "Implement flexible learning options (modular/blended) for students with chronic absenteeism due to family or health situations.";
    $retention_bullets[] = "Launch a school-feeding or local livelihood linkage program to combat hunger and economic challenges of learners.";

    // Facilities Planning
    $facilities_bullets = [];
    if ($seat_ratio < 100) {
        $shortage = $total_enroll - $total_seats;
        $facilities_bullets[] = "Submit an urgent request to the DepEd Division Office / Special Education Fund (SEF) for the procurement of <strong>" . number_format($shortage) . " additional student seats</strong>.";
    } else {
        $facilities_bullets[] = "Establish a regular seat inventory and repair schedule to maintain the current 100% seat sufficiency.";
    }
    if ($area_per_student < 1.4 && $area_per_student > 0) {
        $facilities_bullets[] = "Draft and submit infrastructure development proposals for additional academic buildings to meet the DepEd standard of 1.4 sqm/student (currently at <strong>" . $area_per_student . " sqm/student</strong>).";
    } else {
        $facilities_bullets[] = "Optimize layout planning for active learning spaces and science labs.";
    }
    $non_func = (int)$cls['total'] - (int)$cls['func'];
    if ($non_func > 0) {
        $facilities_bullets[] = "Rehabilitate and repair the <strong>" . $non_func . " non-functional classroom(s)</strong> to bring them back to service.";
    }
    $facilities_bullets[] = "Explore double-shifting schedules if classroom space becomes extremely constrained during peak enrollment periods.";

    // Human Resource Development
    $jhs_enroll = 0;
    foreach($grade_stats as $r) {
        if($r['level_type'] === 'Junior High') {
            $jhs_enroll += (int)$r['enroll'];
        }
    }
    $shs_enroll = $total_enroll - $jhs_enroll;

    $jhs_teachers_q = $pdo->prepare("SELECT COALESCE(SUM(teacher_count),0) FROM teachers_per_grade WHERE school_year=?");
    $jhs_teachers_q->execute([$sel_sy]);
    $jhs_teachers = (int)$jhs_teachers_q->fetchColumn();

    $shs_teachers_q = $pdo->prepare("SELECT COALESCE(SUM(teacher_count),0) FROM teachers_per_area WHERE level_type='Senior High' AND school_year=?");
    $shs_teachers_q->execute([$sel_sy]);
    $shs_teachers = (int)$shs_teachers_q->fetchColumn();

    $hr_bullets = [];
    if (!empty($understaffed_areas)) {
        $hr_bullets[] = "Prioritize requesting additional plantilla items from DepEd Division for understaffed learning areas: <strong>" . implode(', ', $understaffed_areas) . "</strong>.";
    } else {
        $hr_bullets[] = "Continue balancing teaching loads across all departments and maintain existing plantilla roster.";
    }
    $jhs_ratio_val = $jhs_teachers > 0 ? round($jhs_enroll / $jhs_teachers, 1) : 0;
    if ($jhs_ratio_val > 35) {
        $hr_bullets[] = "Deploy auxiliary/volunteer teachers or implement team-teaching strategies to ease the JHS teacher-student ratio of <strong>1:" . $jhs_ratio_val . "</strong>.";
    }
    $shs_ratio_val = $shs_teachers > 0 ? round($shs_enroll / $shs_teachers, 1) : 0;
    if ($shs_ratio_val > 35) {
        $hr_bullets[] = "Explore hiring specialized part-time practitioners to support the high SHS teacher-student ratio of <strong>1:" . $shs_ratio_val . "</strong>.";
    }
    $hr_bullets[] = "Conduct focused In-Service Training (INSET) for the workforce to expand multi-grade and co-teaching competencies.";
  ?>
  <div class="chart-card mt-4">
    <div class="chart-card-title"><i class="bi bi-clipboard2-check me-2 text-primary-nhs"></i>Prescriptive Action Plan</div>
    <div class="chart-card-sub">Data-driven recommendations dynamically tailored for school year <strong><?= htmlspecialchars($sel_sy) ?></strong></div>
    <div class="row g-3 mt-1">
      <div class="col-md-6">
        <div class="p-3 rounded-3 h-100" style="background:#f0f7ff;border-left:3px solid #0F4C81">
          <div class="fw-600 mb-2 text-dark"><i class="bi bi-1-circle-fill text-primary-nhs me-2"></i>Academic Interventions</div>
          <ul class="mb-0 small text-muted ps-3">
            <?php foreach($academic_bullets as $bullet): ?>
              <li class="mb-1"><?= $bullet ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="p-3 rounded-3 h-100" style="background:#f0fff4;border-left:3px solid #16a34a">
          <div class="fw-600 mb-2 text-dark"><i class="bi bi-2-circle-fill text-success me-2"></i>Retention Programs</div>
          <ul class="mb-0 small text-muted ps-3">
            <?php foreach($retention_bullets as $bullet): ?>
              <li class="mb-1"><?= $bullet ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="p-3 rounded-3 h-100" style="background:#fffbf0;border-left:3px solid #d97706">
          <div class="fw-600 mb-2 text-dark"><i class="bi bi-3-circle-fill text-warning me-2"></i>Facilities Planning</div>
          <ul class="mb-0 small text-muted ps-3">
            <?php foreach($facilities_bullets as $bullet): ?>
              <li class="mb-1"><?= $bullet ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="p-3 rounded-3 h-100" style="background:#f8f0ff;border-left:3px solid #7c3aed">
          <div class="fw-600 mb-2 text-dark"><i class="bi bi-4-circle-fill text-purple me-2" style="color:#7c3aed"></i>Human Resource Development</div>
          <ul class="mb-0 small text-muted ps-3">
            <?php foreach($hr_bullets as $bullet): ?>
              <li class="mb-1"><?= $bullet ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- EWS Intervention Modal -->
<div class="custom-modal-overlay" id="ewsModal" onclick="if(event.target === this) closeEwsModal()">
    <div class="custom-modal-dialog">
        <div class="custom-modal-header">
            <h5 class="fw-bold mb-0" style="font-size: 1.05rem;"><i class="bi bi-shield-fill-exclamation me-2"></i>EWS Profile & Intervention Plan</h5>
            <button type="button" class="custom-modal-close" onclick="closeEwsModal()">&times;</button>
        </div>
        <div class="custom-modal-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h4 class="fw-700 text-dark mb-0" id="ewsModalGrade">Grade Level</h4>
                    <p class="text-muted small mb-0" id="ewsModalStrand" style="font-weight: 500;">Strand Name</p>
                </div>
                <div class="ews-badge" id="ewsModalRiskBadge" style="font-size: 0.72rem; padding: 4px 12px; font-weight: 700;">RISK LEVEL</div>
            </div>
            
            <div class="row g-2 text-center mb-4">
                <div class="col-4">
                    <div class="p-2 border rounded bg-light">
                        <div class="fw-700 text-dark" id="ewsModalEnroll" style="font-size: 1.15rem;">0</div>
                        <div class="text-muted" style="font-size: 10px;">Enrollees</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="p-2 border rounded bg-light">
                        <div class="fw-700 text-danger" id="ewsModalDrops" style="font-size: 1.15rem;">0</div>
                        <div class="text-muted" style="font-size: 10px;">Dropouts</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="p-2 border rounded bg-light">
                        <div class="fw-700 text-warning" id="ewsModalReps" style="font-size: 1.15rem;">0</div>
                        <div class="text-muted" style="font-size: 10px;">Repeaters</div>
                    </div>
                </div>
            </div>
            
            <div id="ewsModalPlan">
                <!-- Custom Action steps injected here -->
            </div>
            
            <div class="mt-4 pt-3 border-top">
                <label class="form-label fw-600 text-dark small"><i class="bi bi-journal-text me-1 text-primary"></i>Log the Performed Intervention (Optional):</label>
                <textarea class="form-control form-control-sm mb-2" id="interventionLogText" rows="2" placeholder="Example: Conducted Home Visitation today. Parent agreed to send learning modules weekly."></textarea>
                <button type="button" class="btn btn-primary btn-sm px-3 fw-600" onclick="alert('Intervention logged successfully! (Demo mode)')">
                    <i class="bi bi-save me-1"></i> Save Action Log
                </button>
            </div>
        </div>
        <div class="custom-modal-footer">
            <button type="button" class="btn btn-secondary btn-sm px-4 fw-600" onclick="closeEwsModal()">Close</button>
        </div>
    </div>
</div>

<script>
// Projections constant variables from PHP
const CURRENT_ENROLL = <?= $total_enroll ?>;
const FUNCTIONAL_CLASSROOMS = <?= (int)$cls['func'] ?>;
const TOTAL_SEATS = <?= $total_seats ?>;
const TOTAL_TEACHERS = <?= $total_teachers ?>;
const HISTORICAL_CAGR = <?= $forecast_growth ?>;

// Early Warning System Modal Trigger
function openEwsModal(grade, strand, enroll, drops, reps, rate) {
    document.getElementById('ewsModalGrade').innerText = grade;
    document.getElementById('ewsModalStrand').innerText = (strand && strand !== 'SHS') ? 'Strand: ' + strand : (strand === 'SHS' ? 'Senior High School' : 'Junior High School Summary');
    document.getElementById('ewsModalEnroll').innerText = enroll.toLocaleString();
    document.getElementById('ewsModalDrops').innerText = drops.toLocaleString();
    document.getElementById('ewsModalReps').innerText = reps.toLocaleString();
    
    // Calculate rate again or display passed
    let computedRate = enroll > 0 ? (drops / enroll * 100) : 0;
    
    // Risk level determine
    let riskBadge = document.getElementById('ewsModalRiskBadge');
    let riskColor = '#16a34a';
    let riskText = '🟢 LOW RISK (SAFE)';
    let planHtml = '';
    
    if (computedRate > 5) {
        riskColor = '#dc2626';
        riskText = '🔴 HIGH RISK (CRITICAL)';
        // Tailored plan for high risk
        if (!strand) { // JHS
            planHtml = `
                <div class="mb-3">
                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-shield-exclamation text-danger me-2"></i>Critical Early Intervention Steps (JHS):</h6>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 1: Home Visitation (PTA Home Visitation)</div>
                        <div class="text-muted small">Coordinate immediately with the Parent-Teacher Association (PTA) and Class Adviser to visit the student's home. Investigate the underlying cause of frequent absences.</div>
                    </div>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 2: Guidance Counselor Referral</div>
                        <div class="text-muted small">Refer the student to the School Guidance Counselor for counseling and psychological assessment to address personal or family issues.</div>
                    </div>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 3: Modular Learning or Flexible Learning Shift</div>
                        <div class="text-muted small">If the cause is financial difficulty, distance, or health issues, enroll the student in an Alternative Delivery Mode (ADM) such as modular or blended learning to continue schooling from home.</div>
                    </div>
                </div>
            `;
        } else if (strand === 'SHS') { // SHS Combined
            planHtml = `
                <div class="mb-3">
                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-shield-exclamation text-danger me-2"></i>Critical Early Intervention Steps (Senior High School):</h6>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 1: Home Visitation and Parental Dialogue</div>
                        <div class="text-muted small">Coordinate with Class Advisers and parents to conduct a home visit. Understand the causes of absenteeism or academic struggles, and formulate a learning retention agreement.</div>
                    </div>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 2: Career Guidance and Academic Counselling</div>
                        <div class="text-muted small">Offer career guidance and specialized tutorials for specialized/applied subjects across tracks and strands to restore student motivation to graduate.</div>
                    </div>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 3: Flexible Learning Mode Shift</div>
                        <div class="text-muted small">Initiate Alternative Delivery Mode (modular/blended learning) for students who need to work or have personal and family constraints attending in-person school.</div>
                    </div>
                </div>
            `;
        } else if (strand.includes('TVL')) { // SHS TVL
            planHtml = `
                <div class="mb-3">
                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-shield-exclamation text-danger me-2"></i>Critical Early Intervention Steps (SHS TVL):</h6>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 1: Connecting with Industry Partners or Livelihood</div>
                        <div class="text-muted small">Engage local industry partners (for FBS/Cookery/Bartending/Animation) to motivate the student. Emphasize the importance and value of the NC II Certificate for career employment.</div>
                    </div>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 2: Adjusting Skills Assessment Schedule</div>
                        <div class="text-muted small">Provide flexibility in laboratory schedules or hands-on exercises for the student so they do not feel overwhelmed by backlogs.</div>
                    </div>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 3: Flexible Learning Mode Shift</div>
                        <div class="text-muted small">Offer self-paced modular hands-on projects or home-based laboratory alternatives for students who are working while studying.</div>
                    </div>
                </div>
            `;
        } else { // SHS Academic (STEM/ABM/HUMSS/GAS)
            planHtml = `
                <div class="mb-3">
                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-shield-exclamation text-danger me-2"></i>Critical Early Intervention Steps (SHS Academic):</h6>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 1: Peer Coaching and Remedial Circles</div>
                        <div class="text-muted small">Assign high-performing classmates for peer tutoring. Conduct remediation classes in subjects where students commonly struggle, such as General Mathematics or Specialized Subjects.</div>
                    </div>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 2: Immediate Coordination with Parents/Guardians</div>
                        <div class="text-muted small">Convene parents/guardians to draft a "Learning Agreement" between the school, parent, and student for regular progress monitoring.</div>
                    </div>
                    <div class="timeline-step mb-3">
                        <div class="fw-600 text-dark small">Step 3: DepEd FLO or Blended Class Arrangement</div>
                        <div class="text-muted small">Grant extensions for submitting written works and performance tasks, and transition to a blended/modular learning schedule if necessary.</div>
                    </div>
                </div>
            `;
        }
    } else if (computedRate >= 2) {
        riskColor = '#d97706';
        riskText = '🟡 MEDIUM RISK (MONITOR)';
        planHtml = `
            <div class="mb-3">
                <h6 class="fw-bold text-dark mb-2"><i class="bi bi-exclamation-circle text-warning me-2"></i>Suggested Actions for Active Monitoring:</h6>
                <div class="timeline-step mb-3">
                    <div class="fw-600 text-dark small">Step 1: Analysis of the Causes of Absenteeism</div>
                    <div class="text-muted small">Have the class adviser conduct a one-on-one session with the student to identify early indicators of potential dropout.</div>
                </div>
                <div class="timeline-step mb-3">
                    <div class="fw-600 text-dark small">Step 2: Sending an Early Alert Letter</div>
                    <div class="text-muted small">Send a formal notice to parents informing them of the student's attendance status and academic standing before issues escalate.</div>
                </div>
                <div class="timeline-step mb-3">
                    <div class="fw-600 text-dark small">Step 3: Provision of Academic Counselling</div>
                    <div class="text-muted small">Encourage the student to join after-school remedial classes or study circles.</div>
                </div>
            </div>
        `;
    } else {
        riskColor = '#16a34a';
        riskText = '🟢 LOW RISK (SAFE)';
        planHtml = `
            <div class="mb-3">
                <h6 class="fw-bold text-dark mb-2"><i class="bi bi-check-circle text-success me-2"></i>Maintaining Excellent Performance:</h6>
                <div class="timeline-step mb-3">
                    <div class="fw-600 text-dark small">Step 1: Recognition and Appreciation (Positive Reinforcement)</div>
                    <div class="text-muted small">Continue giving praise and recognition to the student to maintain high learning motivation.</div>
                </div>
                <div class="timeline-step mb-3">
                    <div class="fw-600 text-dark small">Step 2: Maintaining Open Communication</div>
                    <div class="text-muted small">Maintain monthly teacher-parent check-ins through homeroom PTA meetings.</div>
                </div>
            </div>
        `;
    }
    
    riskBadge.style.backgroundColor = riskColor + '20'; // 12% opacity
    riskBadge.style.color = riskColor;
    riskBadge.innerText = riskText;
    document.getElementById('ewsModalPlan').innerHTML = planHtml;
    
    // Reset interventions log placeholder
    document.getElementById('interventionLogText').value = '';
    document.getElementById('ewsModal').style.display = 'block';
}

function closeEwsModal() {
    document.getElementById('ewsModal').style.display = 'none';
}

// AI What-If Scenario Analysis Logic
function runWhatIf() {
    const growthRate = parseFloat(document.getElementById('growthRateSlider').value);
    const targetClassSize = parseInt(document.getElementById('classSizeSlider').value);
    const targetTeacherRatio = parseInt(document.getElementById('teacherRatioSlider').value);
    
    // 1. Update interactive labels
    document.getElementById('sliderValLabel').innerText = (growthRate >= 0 ? '+' : '') + growthRate.toFixed(1) + '%';
    document.getElementById('classSizeValLabel').innerText = targetClassSize + ' std/room';
    document.getElementById('teacherRatioValLabel').innerText = targetTeacherRatio + ' std/teacher';
    
    // 2. Projected Enrollees
    let projectedEnroll = Math.round(CURRENT_ENROLL * (1 + growthRate / 100));
    document.getElementById('projEnrolleesVal').innerText = projectedEnroll.toLocaleString();
    
    // 3. Classroom Calculation (Dynamic ratio based on targetClassSize)
    let roomsNeeded = Math.ceil(projectedEnroll / targetClassSize);
    let roomsGap = FUNCTIONAL_CLASSROOMS - roomsNeeded;
    let roomsCard = document.getElementById('projClassroomsCard');
    let roomsGapVal = document.getElementById('projClassroomsGap');
    
    if (roomsGap < 0) {
        roomsCard.style.borderLeftColor = '#dc2626';
        roomsCard.style.background = 'linear-gradient(135deg, #fef2f2 0%, #fff 60%)';
        roomsCard.classList.add('deficit');
        roomsGapVal.innerHTML = `<span class="text-danger fw-600"><i class="bi bi-exclamation-triangle-fill"></i> Shortage of ${Math.abs(roomsGap)} classroom(s)</span>`;
    } else {
        roomsCard.style.borderLeftColor = '#16a34a';
        roomsCard.style.background = 'linear-gradient(135deg, #f0fdf4 0%, #fff 60%)';
        roomsCard.classList.remove('deficit');
        roomsGapVal.innerHTML = `<span class="text-success fw-600"><i class="bi bi-check-circle-fill"></i> Adequate classrooms (+${roomsGap})</span>`;
    }
    document.getElementById('projClassroomsVal').innerText = roomsNeeded.toLocaleString();
    
    // 4. Seats Calculation (Static seat inventory vs projected enrollees)
    let seatsGap = TOTAL_SEATS - projectedEnroll;
    let seatsCard = document.getElementById('projSeatsCard');
    let seatsGapVal = document.getElementById('projSeatsGap');
    
    if (seatsGap < 0) {
        seatsCard.style.borderLeftColor = '#dc2626';
        seatsCard.style.background = 'linear-gradient(135deg, #fef2f2 0%, #fff 60%)';
        seatsCard.classList.add('deficit');
        seatsGapVal.innerHTML = `<span class="text-danger fw-600"><i class="bi bi-exclamation-triangle-fill"></i> Shortage of ${Math.abs(seatsGap)} seat(s)</span>`;
    } else {
        seatsCard.style.borderLeftColor = '#16a34a';
        seatsCard.style.background = 'linear-gradient(135deg, #f0fdf4 0%, #fff 60%)';
        seatsCard.classList.remove('deficit');
        seatsGapVal.innerHTML = `<span class="text-success fw-600"><i class="bi bi-check-circle-fill"></i> Adequate seats (+${seatsGap})</span>`;
    }
    document.getElementById('projSeatsVal').innerText = TOTAL_SEATS.toLocaleString();
    
    // 5. Teachers Calculation (Dynamic ratio based on targetTeacherRatio)
    let teachersNeeded = Math.ceil(projectedEnroll / targetTeacherRatio);
    let teachersGap = TOTAL_TEACHERS - teachersNeeded;
    let teachersCard = document.getElementById('projTeachersCard');
    let teachersGapVal = document.getElementById('projTeachersGap');
    
    if (teachersGap < 0) {
        teachersCard.style.borderLeftColor = '#dc2626';
        teachersCard.style.background = 'linear-gradient(135deg, #fef2f2 0%, #fff 60%)';
        teachersCard.classList.add('deficit');
        teachersGapVal.innerHTML = `<span class="text-danger fw-600"><i class="bi bi-exclamation-triangle-fill"></i> Shortage of ${Math.abs(teachersGap)} teacher(s)</span>`;
    } else {
        teachersCard.style.borderLeftColor = '#16a34a';
        teachersCard.style.background = 'linear-gradient(135deg, #f0fdf4 0%, #fff 60%)';
        teachersCard.classList.remove('deficit');
        teachersGapVal.innerHTML = `<span class="text-success fw-600"><i class="bi bi-check-circle-fill"></i> Adequate teachers (+${teachersGap})</span>`;
    }
    document.getElementById('projTeachersVal').innerText = teachersNeeded.toLocaleString();
    
    // 6. Real-time recommendations summary
    let summaryText = '';
    
    // Scenario descriptor
    if (growthRate === HISTORICAL_CAGR && targetClassSize === 40 && targetTeacherRatio === 35) {
        summaryText += `<strong>Standard Projection (${(growthRate >= 0 ? '+' : '') + growthRate.toFixed(1)}%):</strong> Based on the last 3 years and standard DepEd guidelines, this is our default forecast. `;
    } else {
        summaryText += `<strong>What-If Scenario Simulation:</strong> You are using custom parameters (Growth: ${(growthRate >= 0 ? '+' : '') + growthRate.toFixed(1)}%, Class Size: ${targetClassSize}, Teacher Ratio: 1:${targetTeacherRatio}). `;
    }
    
    if (roomsGap < 0 || seatsGap < 0 || teachersGap < 0) {
        let needs = [];
        if (roomsGap < 0) needs.push(`${Math.abs(roomsGap)} new classroom(s)`);
        if (seatsGap < 0) needs.push(`${Math.abs(seatsGap)} additional seat(s)`);
        if (teachersGap < 0) needs.push(`${Math.abs(teachersGap)} new teacher plantilla item(s)`);
        summaryText += `In this scenario, the school will experience the following shortages: <strong>${needs.join(', ')}</strong>. It is recommended to prepare a request letter for the DepEd Division Office before the start of the school year to maintain the quality of education.`;
    } else {
        summaryText += `The current capacity of the school is sufficient to accommodate the expected number of students. Immediate additional facilities are not required, but regular maintenance of seats is still suggested to sustain quality.`;
    }
    
    document.getElementById('projSummaryText').innerHTML = summaryText;
}

// Preset Scenario Applier
function applyPreset(scenario) {
    const growthSlider = document.getElementById('growthRateSlider');
    const classSizeSlider = document.getElementById('classSizeSlider');
    const teacherRatioSlider = document.getElementById('teacherRatioSlider');
    
    if (scenario === 'default') {
        growthSlider.value = HISTORICAL_CAGR;
        classSizeSlider.value = 40;
        teacherRatioSlider.value = 35;
    } else if (scenario === 'quality') {
        growthSlider.value = 0; // zero growth target focus
        classSizeSlider.value = 30; // smaller classes
        teacherRatioSlider.value = 30; // focus teaching
    } else if (scenario === 'congested') {
        growthSlider.value = 15; // aggressive high growth
        classSizeSlider.value = 45; // large classes
        teacherRatioSlider.value = 40; // understaffed
    }
    
    runWhatIf();
}

// Initialize on DOM Load
document.addEventListener('DOMContentLoaded', function() {
    runWhatIf();
});
</script>

<?php if(isset($_GET['autoexport']) && $_GET['autoexport'] == 1): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        exportToPDF('insightExport','NHS_Summary_Report_<?= htmlspecialchars($sel_sy) ?>.pdf');
    }, 800);
});
</script>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
