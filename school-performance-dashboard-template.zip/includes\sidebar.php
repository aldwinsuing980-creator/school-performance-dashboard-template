<?php
// includes/sidebar.php
$current_page = basename($_SERVER['PHP_SELF'], '.php');
$nav = [
  ['dashboard',      'bi-speedometer2',       'Dashboard',          'Overview & KPIs'],
  ['calendar',       'bi-calendar3',          'School Calendar',    'Academic Schedules'],
  ['data_entry',     'bi-pencil-square',      'Data Entry',         'Enter Existing Data'],
  ['enrollment',     'bi-person-lines-fill',  'Enrollment',         'BOSY Data & Trends'],
  ['facilities',     'bi-building',           'Facilities',         'Classrooms & Seats'],
  ['human_resources','bi-people-fill',        'Human Resources',    'Teachers & Staffing'],
  ['insights',       'bi-lightbulb-fill',     'Insights',           'AI Recommendations'],
  ['cohort_survival', 'bi-graph-up-arrow',     'Student Success',    'Cohort Retention'],
  ['approvals',      'bi-person-check-fill',  'User Approvals',     'Approve Pending Accounts'],
  ['announcements',  'bi-megaphone',          'Announcements',      'School Board & Events'],
  ['activity_logs',  'bi-clock-history',      'Activity Logs',      'Audit Trail'],
  ['settings',       'bi-gear-fill',           'System Settings',    'Configure Name & Logo'],
];
$admin_only = ['activity_logs', 'approvals', 'data_entry', 'settings'];
$encoder_visible = ['data_entry','enrollment','facilities','human_resources'];
?>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <img src="<?= htmlspecialchars(APP_LOGO) ?>" onerror="this.src='https://ui-avatars.com/api/?name=Branding&background=fff&color=0F4C81&size=40'"
         alt="Logo" width="40" height="40" style="border-radius:50%; object-fit: cover;">
    <div class="brand-text">
      <span class="brand-name"><?= htmlspecialchars(APP_NAME) ?></span>
      <span class="brand-sub">Analytics Dashboard</span>
    </div>
  </div>
  <div class="sidebar-divider"></div>
  <ul class="sidebar-nav">
    <?php 
    $role = $_SESSION['user_role'] ?? 'Student';
    foreach($nav as [$page, $icon, $label, $sub]): 
      // Admin sees everything
      if ($role !== 'Admin') {
          if ($role === 'Faculty') {
              // Faculty allowed pages
              $faculty_allowed = ['dashboard', 'calendar', 'enrollment', 'facilities', 'human_resources', 'insights', 'cohort_survival', 'announcements'];
              if (!in_array($page, $faculty_allowed, true)) {
                  continue;
              }
          } else {
              // Student or others see only Dashboard and Announcements
              $student_allowed = ['dashboard', 'calendar', 'announcements'];
              if (!in_array($page, $student_allowed, true)) {
                  continue;
              }
          }
      }
      if(defined('FEATURE_DATA_ENTRY') && !FEATURE_DATA_ENTRY && in_array($page, ['data_entry', 'enrollment'])): continue; endif; 
    ?>
      <li>
        <a href="<?=$page?>.php" class="sidebar-link <?=$current_page===$page?'active':''?>">
          <i class="bi <?=$icon?> sidebar-icon"></i>
          <span class="sidebar-label">
            <span class="label-main"><?=$label?></span>
            <span class="label-sub"><?=$sub?></span>
          </span>
        </a>
      </li>
    <?php endforeach; ?>
  </ul>
  <div class="sidebar-footer">
    <div class="sidebar-divider"></div>
    <a href="logout.php" class="sidebar-link text-danger-soft">
      <i class="bi bi-box-arrow-right sidebar-icon"></i>
      <span class="sidebar-label"><span class="label-main">Logout</span></span>
    </a>
  </div>
</aside>
