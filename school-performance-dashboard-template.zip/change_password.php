<?php
// change_password.php
require_once __DIR__ . '/config/session.php';
require_login();

$page_title = 'Change Password';
$breadcrumb = 'Security';
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password     = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = 'Mangyaring punan ang lahat ng mga patlang (Please fill in all fields).';
    } elseif ($new_password !== $confirm_password) {
        $error = 'Hindi tugma ang Bagong Password at Confirm Password (Passwords do not match).';
    } elseif (strlen($new_password) < 6) {
        $error = 'Ang bagong password ay dapat may hindi bababa sa 6 na karakter (Password must be at least 6 characters).';
    } else {
        // Fetch current user from database
        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ? LIMIT 1");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();

        if ($user && password_verify($current_password, $user['password'])) {
            // Hash and update
            $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $update_stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            if ($update_stmt->execute([$new_hash, $_SESSION['user_id']])) {
                log_activity($pdo, $_SESSION['user_id'], "User changed their password.", 'Security');
                $success = 'Matagumpay na nabago ang iyong password! (Password updated successfully!)';
            } else {
                $error = 'Nagkaroon ng problema sa pag-update. Subukang muli.';
            }
        } else {
            $error = 'Mali ang kasalukuyang password (Incorrect current password).';
        }
    }
}

include 'includes/header.php';
?>

<style>
.security-card {
    background: rgba(255, 255, 255, 0.55);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.4);
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(27, 42, 107, 0.05);
    max-width: 500px;
    margin: 2rem auto;
}
[data-theme="dark"] .security-card {
    background: rgba(37, 42, 68, 0.45);
    border: 1px solid rgba(255, 255, 255, 0.06);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.22);
}
.form-control-pass {
    border: 1.5px solid #e2e8f0;
    border-radius: 12px;
    padding: 0.75rem 1rem;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    background-color: var(--bg);
    color: var(--text);
}
.form-control-pass:focus {
    border-color: var(--primary);
    background-color: var(--surface);
    box-shadow: 0 0 0 3px rgba(27, 42, 107, 0.1);
}
</style>

<div class="container py-4">
    <div class="security-card p-4">
        <div class="text-center mb-4">
            <div style="font-size: 3rem;" class="mb-2">🔑</div>
            <h3 class="fw-800 text-primary-nhs">Change Password</h3>
            <p class="text-muted small">Update your account credentials to keep your portal secure.</p>
        </div>

        <form method="POST" action="change_password.php">
            <!-- Current Password -->
            <div class="mb-3">
                <label class="form-label fw-600 small text-muted">Kasalukuyang Password (Current Password)</label>
                <input type="password" name="current_password" class="form-control-pass w-100" required placeholder="••••••••">
            </div>

            <!-- New Password -->
            <div class="mb-3">
                <label class="form-label fw-600 small text-muted">Bagong Password (New Password)</label>
                <input type="password" name="new_password" class="form-control-pass w-100" required placeholder="Minimum 6 characters">
            </div>

            <!-- Confirm Password -->
            <div class="mb-4">
                <label class="form-label fw-600 small text-muted">Kumpirmahin ang Bagong Password (Confirm New Password)</label>
                <input type="password" name="confirm_password" class="form-control-pass w-100" required placeholder="••••••••">
            </div>

            <button type="submit" class="btn-primary-nhs w-100 py-2.5 fw-600 text-white" style="border-radius: 12px;">
                <i class="bi bi-shield-lock-fill me-1"></i> Update Password
            </button>
        </form>
    </div>
</div>

<script>
<?php if ($error): ?>
Swal.fire({
    icon: 'error',
    title: 'Password Update Failed',
    text: <?= json_encode($error) ?>,
    confirmButtonColor: '#1B2A6B',
    borderRadius: '12px'
});
<?php endif; ?>

<?php if ($success): ?>
Swal.fire({
    icon: 'success',
    title: 'Success!',
    text: <?= json_encode($success) ?>,
    confirmButtonColor: '#10b981',
    borderRadius: '12px'
}).then(() => {
    window.location.href = 'dashboard.php';
});
<?php endif; ?>
</script>

<?php include 'includes/footer.php'; ?>
