<?php
require_once __DIR__ . '/config/session.php';
require_login();

// Restrict strictly to Admin and Faculty roles
if (!has_role('Admin', 'Faculty')) {
    $page_title = 'Access Denied';
    $breadcrumb = 'Access Denied';
    include 'includes/header.php';
    echo '<div class="d-flex align-items-center justify-content-center" style="min-height:50vh;">
      <div class="text-center">
        <div style="font-size:4rem;margin-bottom:1rem;">🔒</div>
        <h2 class="fw-700 text-dark mb-2">Access Denied</h2>
        <p class="text-muted mb-3">You do not have permission to view this page. This area is reserved for staff members.</p>
        <a href="dashboard.php" class="btn-primary-nhs"><i class="bi bi-arrow-left me-1"></i> Back to Dashboard</a>
      </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

$page_title = 'Facilities & Capacity';
$breadcrumb = 'Facilities';

// Fetch classrooms
$classrooms = $pdo->query("SELECT * FROM classrooms ORDER BY is_functional DESC, room_code")->fetchAll();

// Stats
$total_cls = count($classrooms);
$func_cls  = count(array_filter($classrooms, fn($r) => $r['is_functional']));
$total_area = array_sum(array_column($classrooms, 'total_area'));

// Fetch seats by grade
$sy_rows = $pdo->query("SELECT DISTINCT school_year FROM seats_data ORDER BY school_year DESC")->fetchAll();
$sy_list  = array_column($sy_rows, 'school_year');
$sel_sy   = $_GET['sy'] ?? ($sy_list[0] ?? '2025-2026');

$allowed_level_types = [];
if (has_kinder()) $allowed_level_types[] = 'Kindergarten';
if (has_elementary()) $allowed_level_types[] = 'Elementary';
if (has_jhs()) $allowed_level_types[] = 'Junior High';
if (has_shs()) $allowed_level_types[] = 'Senior High';
if (empty($allowed_level_types)) $allowed_level_types = ['Junior High', 'Senior High'];
$level_type_clause = "gl.level_type IN ('" . implode("','", $allowed_level_types) . "')";

$seats_q = $pdo->prepare("
  SELECT sd.*, gl.grade_name, gl.level_type, st.strand_code
  FROM seats_data sd
  JOIN grade_levels gl ON gl.id=sd.grade_level_id
  LEFT JOIN strands st ON st.id=sd.strand_id
  WHERE sd.school_year=? AND $level_type_clause
  ORDER BY gl.id
");
$seats_q->execute([$sel_sy]);
$seats = $seats_q->fetchAll();

$grades  = $pdo->query("SELECT * FROM grade_levels WHERE level_type IN ('" . implode("','", $allowed_level_types) . "') ORDER BY id")->fetchAll();
$strands = $pdo->query("SELECT * FROM strands ORDER BY strand_name")->fetchAll();

include 'includes/header.php';
?>
<!-- Header -->
<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
  <div class="section-header mb-0">
    <h1 class="section-title"><i class="bi bi-building me-2 text-primary-nhs"></i>Facilities & Capacity</h1>
    <p class="section-sub">Classroom inventory and seat sufficiency management</p>
  </div>
</div>

<!-- Stats Row -->
<div class="row g-3 mb-4">
  <div class="col-sm-4">
    <div class="kpi-card kpi-info">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon navy"><i class="bi bi-building-fill"></i></div>
        <div>
          <div class="kpi-label">Total Classrooms</div>
          <div class="kpi-value"><?= $total_cls ?></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="kpi-card <?= $func_cls==$total_cls?'kpi-good':'kpi-warn' ?>">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon green"><i class="bi bi-check-circle-fill"></i></div>
        <div>
          <div class="kpi-label">Functional Rooms</div>
          <div class="kpi-value"><?= $func_cls ?> <small class="fs-6 text-muted">/ <?= $total_cls ?></small></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-sm-4">
    <div class="kpi-card kpi-info">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon teal"><i class="bi bi-grid-3x3"></i></div>
        <div>
          <div class="kpi-label">Total Functional Area</div>
          <div class="kpi-value"><?= number_format($total_area,0) ?> <small class="fs-6">sqm</small></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Tabs -->
<ul class="nav nav-pills mb-4" id="facilityTabs">
  <li class="nav-item">
    <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#classroomTab">
      <i class="bi bi-building me-1"></i> Classrooms
    </button>
  </li>
  <li class="nav-item">
    <button class="nav-link" data-bs-toggle="pill" data-bs-target="#seatsTab">
      <i class="bi bi-chair me-1"></i> Seats
    </button>
  </li>
</ul>

<div class="tab-content">
  <!-- Classrooms Tab -->
  <div class="tab-pane fade show active" id="classroomTab">
    <div class="data-card">
      <div class="data-card-header">
        <span class="data-card-title">Classroom Inventory</span>
        <?php if(has_role('Admin')): ?>
        <button class="btn-primary-nhs" data-bs-toggle="modal" data-bs-target="#classroomModal" onclick="resetClassroomForm()">
          <i class="bi bi-plus-circle"></i> Add Classroom
        </button>
        <?php endif; ?>
      </div>
      <div class="table-responsive">
        <table class="nhs-table">
          <thead>
            <tr><th>#</th><th>Room Code</th><th>Length (m)</th><th>Width (m)</th>
            <th>Total Area (sqm)</th><th>Status</th><th>Notes</th>
            <?php if(has_role('Admin')): ?><th>Actions</th><?php endif; ?></tr>
          </thead>
          <tbody>
            <?php foreach($classrooms as $i=>$r): ?>
            <tr>
              <td class="text-muted"><?= $i+1 ?></td>
              <td class="fw-600"><?= htmlspecialchars($r['room_code']) ?></td>
              <td><?= $r['length_m'] ?></td>
              <td><?= $r['width_m'] ?></td>
              <td><?= number_format($r['total_area'],2) ?></td>
              <td>
                <?php if($r['is_functional']): ?>
                <span class="kpi-badge badge-good">✅ Functional</span>
                <?php else: ?>
                <span class="kpi-badge badge-danger">❌ Non-Functional</span>
                <?php endif; ?>
              </td>
              <td class="text-muted small"><?= htmlspecialchars($r['notes']??'') ?></td>
              <?php if(has_role('Admin')): ?>
              <td>
                <button class="btn btn-sm btn-outline-primary me-1" onclick='editClassroom(<?= json_encode($r) ?>)'>
                  <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteRecord(<?= $r['id'] ?>,'classrooms','Classroom')">
                  <i class="bi bi-trash"></i>
                </button>
              </td>
              <?php endif; ?>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Seats Tab -->
  <div class="tab-pane fade" id="seatsTab">
    <div class="data-card">
      <div class="data-card-header">
        <span class="data-card-title">Seats by Grade Level — S.Y. <?= htmlspecialchars($sel_sy) ?></span>
        <?php if(has_role('Admin')): ?>
        <button class="btn-primary-nhs" data-bs-toggle="modal" data-bs-target="#seatsModal" onclick="resetSeatsForm()">
          <i class="bi bi-plus-circle"></i> Add Seats
        </button>
        <?php endif; ?>
      </div>
      <div class="table-responsive">
        <table class="nhs-table">
          <thead>
            <tr><th>#</th><th>Grade Level</th><th>Type</th>
            <th>Available Seats</th><th>School Year</th>
            <?php if(has_role('Admin')): ?><th>Actions</th><?php endif; ?></tr>
          </thead>
          <tbody>
            <?php foreach($seats as $i=>$r): ?>
            <tr>
              <td class="text-muted"><?= $i+1 ?></td>
              <td class="fw-600"><?= htmlspecialchars($r['grade_name']) ?></td>
              <td><span class="kpi-badge badge-info"><?= $r['level_type'] ?></span></td>
              <td class="fw-600"><?= number_format($r['available_seats']) ?></td>
              <td><?= htmlspecialchars($r['school_year']) ?></td>
              <?php if(has_role('Admin')): ?>
              <td>
                <button class="btn btn-sm btn-outline-primary me-1" onclick='editSeats(<?= json_encode($r) ?>)'>
                  <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteRecord(<?= $r['id'] ?>,'seats_data','Seats')">
                  <i class="bi bi-trash"></i>
                </button>
              </td>
              <?php endif; ?>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Classroom Modal -->
<?php if(has_role('Admin')): ?>
<div class="modal fade" id="classroomModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="clsModalTitle"><i class="bi bi-building me-2"></i>Add Classroom</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form onsubmit="submitClassroom(event)">
        <div class="modal-body">
          <input type="hidden" id="clsId" name="id">
          <input type="hidden" name="action" id="clsAction" value="add">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Room Code *</label>
              <input type="text" name="room_code" id="clsCode" class="form-control" placeholder="e.g. Room 101" required>
            </div>
            <div class="col-6">
              <label class="form-label">Length (m) *</label>
              <input type="number" name="length_m" id="clsLen" class="form-control" step="0.01" min="1" required>
            </div>
            <div class="col-6">
              <label class="form-label">Width (m) *</label>
              <input type="number" name="width_m" id="clsWid" class="form-control" step="0.01" min="1" required>
            </div>
            <div class="col-12">
              <label class="form-label">Status</label>
              <select name="is_functional" id="clsFunc" class="form-select">
                <option value="1">✅ Functional</option>
                <option value="0">❌ Non-Functional</option>
              </select>
            </div>
            <div class="col-12">
              <label class="form-label">Notes</label>
              <textarea name="notes" id="clsNotes" class="form-control" rows="2"></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn-primary-nhs"><i class="bi bi-save me-1"></i>Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Seats Modal -->
<div class="modal fade" id="seatsModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="bi bi-chair me-2"></i>Manage Seats</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form onsubmit="submitSeats(event)">
        <div class="modal-body">
          <input type="hidden" id="seatsId" name="id">
          <input type="hidden" name="action" id="seatsAction" value="add">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Grade Level *</label>
              <select name="grade_level_id" id="seatsGrade" class="form-select" required>
                <?php foreach($grades as $g): 
                  $lvl_short = 'JHS';
                  if ($g['level_type'] === 'Senior High') $lvl_short = 'SHS';
                  elseif ($g['level_type'] === 'Kindergarten') $lvl_short = 'Kinder';
                  elseif ($g['level_type'] === 'Elementary') $lvl_short = 'Elem';
                ?>
                <option value="<?=$g['id']?>"><?= htmlspecialchars($g['grade_name']) ?> (<?= $lvl_short ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <?php if(has_shs()): ?>
            <div class="col-12">
              <label class="form-label">Strand <span class="text-muted small">(SHS only)</span></label>
              <select name="strand_id" id="seatsStrand" class="form-select">
                <option value="">— None —</option>
                <?php foreach($strands as $st): ?>
                <option value="<?=$st['id']?>"><?= htmlspecialchars($st['strand_code']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <?php else: ?>
            <input type="hidden" name="strand_id" id="seatsStrand" value="">
            <?php endif; ?>
            <div class="col-6">
              <label class="form-label">Available Seats *</label>
              <input type="number" name="available_seats" id="seatsCount" class="form-control" min="0" required>
            </div>
            <div class="col-6">
              <label class="form-label">School Year *</label>
              <select name="school_year" class="form-select">
                <?php foreach($sy_list as $sy): ?>
                <option value="<?=$sy?>" <?=$sy===$sel_sy?'selected':''?>><?=$sy?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn-primary-nhs"><i class="bi bi-save me-1"></i>Save</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
function resetClassroomForm(){
  document.getElementById('clsModalTitle').innerHTML='<i class="bi bi-building me-2"></i>Add Classroom';
  document.getElementById('clsAction').value='add';
  document.getElementById('clsId').value='';
  ['clsCode','clsLen','clsWid','clsNotes'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('clsFunc').value='1';
}
function editClassroom(r){
  document.getElementById('clsModalTitle').innerHTML='<i class="bi bi-pencil me-2"></i>Edit Classroom';
  document.getElementById('clsAction').value='edit';
  document.getElementById('clsId').value=r.id;
  document.getElementById('clsCode').value=r.room_code;
  document.getElementById('clsLen').value=r.length_m;
  document.getElementById('clsWid').value=r.width_m;
  document.getElementById('clsFunc').value=r.is_functional;
  document.getElementById('clsNotes').value=r.notes||'';
  new bootstrap.Modal(document.getElementById('classroomModal')).show();
}
async function submitClassroom(e){
  e.preventDefault();
  const fd=new FormData(e.target), data=Object.fromEntries(fd);
  showSpinner();
  const r=await fetch('ajax/facility_crud.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  const res=await r.json(); hideSpinner();
  if(res.success){toastSuccess(res.message);bootstrap.Modal.getInstance(document.querySelector('.modal.show'))?.hide();setTimeout(()=>location.reload(),700);}
  else toastError(res.message);
}
function resetSeatsForm(){
  document.getElementById('seatsAction').value='add';
  document.getElementById('seatsId').value='';
  document.getElementById('seatsCount').value='';
}
function editSeats(r){
  document.getElementById('seatsAction').value='edit';
  document.getElementById('seatsId').value=r.id;
  document.getElementById('seatsGrade').value=r.grade_level_id;
  document.getElementById('seatsStrand').value=r.strand_id||'';
  document.getElementById('seatsCount').value=r.available_seats;
  new bootstrap.Modal(document.getElementById('seatsModal')).show();
}
async function submitSeats(e){
  e.preventDefault();
  const fd=new FormData(e.target), data=Object.fromEntries(fd);
  data.type='seats';
  showSpinner();
  const r=await fetch('ajax/facility_crud.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  const res=await r.json(); hideSpinner();
  if(res.success){toastSuccess(res.message);bootstrap.Modal.getInstance(document.querySelector('.modal.show'))?.hide();setTimeout(()=>location.reload(),700);}
  else toastError(res.message);
}
function deleteRecord(id, table, label){
  confirmAction(`Delete this ${label} record? This affects historical data.`).then(r=>{
    if(!r.isConfirmed) return;
    showSpinner();
    fetch('ajax/delete_record.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,table})})
      .then(r=>r.json()).then(res=>{hideSpinner();if(res.success){toastSuccess(res.message);setTimeout(()=>location.reload(),700);}else toastError(res.message);});
  });
}
</script>
<?php include 'includes/footer.php'; ?>
