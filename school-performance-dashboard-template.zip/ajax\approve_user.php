<?php
// ajax/approve_user.php
require_once __DIR__ . '/../config/session.php';
require_login();

// Restrict strictly to Admin role
if (!has_role('Admin')) {
    json_response(['success' => false, 'message' => 'Access denied. Only Administrators can approve accounts.'], 403);
}

$data = json_decode(file_get_contents('php://input'), true);
$id   = (int)($data['id'] ?? 0);

if (!$id) {
    json_response(['success' => false, 'message' => 'Invalid user ID.'], 400);
}

try {
    // 1. Get user details to log the name/username
    $stmt = $pdo->prepare("SELECT username, full_name FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        json_response(['success' => false, 'message' => 'User not found.'], 404);
    }

    // 2. Perform status transition to Approved
    $upd = $pdo->prepare("UPDATE users SET status = 'Approved' WHERE id = ?");
    $upd->execute([$id]);
    
    log_activity($pdo, current_user_id(), "Approved user '{$user['username']}' ({$user['full_name']})", 'Users');
    json_response(['success' => true, 'message' => 'User account approved successfully.']);
} catch (PDOException $e) {
    json_response(['success' => false, 'message' => 'Database error: ' . $e->getMessage()], 500);
}
?>
