<?php
// ajax/setup_crud.php — Handles the first-time setup wizard form submission
require_once __DIR__ . '/../config/db_connect.php';

// If already set up, deny access
if (APP_SETUP_COMPLETE) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Setup has already been completed.']);
    exit;
}

header('Content-Type: application/json');

// Helper: convert hex color to "R, G, B" string
function hexToRgbSetup(string $hex): string {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = hexdec(substr($hex,0,2));
    $g = hexdec(substr($hex,2,2));
    $b = hexdec(substr($hex,4,2));
    return "$r, $g, $b";
}

// Helper: upsert a setting
function upsertSetup(PDO $pdo, string $key, string $value): void {
    $stmt = $pdo->prepare("
        INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)
        ON DUPLICATE KEY UPDATE setting_value = ?
    ");
    $stmt->execute([$key, $value, $value]);
}

try {
    // Validate required fields
    $school_name    = trim($_POST['school_name']     ?? '');
    $admin_username = trim($_POST['admin_username']  ?? '');
    $admin_fullname = trim($_POST['admin_fullname']  ?? '');
    $admin_password = $_POST['admin_password']        ?? '';

    if (empty($school_name))    { echo json_encode(['success'=>false,'message'=>'School name is required.']); exit; }
    if (empty($admin_username)) { echo json_encode(['success'=>false,'message'=>'Admin username is required.']); exit; }
    if (empty($admin_fullname)) { echo json_encode(['success'=>false,'message'=>'Admin full name is required.']); exit; }
    if (strlen($admin_password) < 6) { echo json_encode(['success'=>false,'message'=>'Password must be at least 6 characters.']); exit; }

    // Save school settings
    upsertSetup($pdo, 'school_name',     $school_name);
    upsertSetup($pdo, 'school_tagline',  trim($_POST['school_tagline']  ?? ''));
    upsertSetup($pdo, 'school_division', trim($_POST['school_division'] ?? ''));
    upsertSetup($pdo, 'school_id',       trim($_POST['school_id']       ?? ''));
    upsertSetup($pdo, 'school_address',  trim($_POST['school_address']  ?? ''));
    upsertSetup($pdo, 'school_contact',  trim($_POST['school_contact']  ?? ''));
    upsertSetup($pdo, 'offered_levels',  trim($_POST['offered_levels']  ?? 'jhs,shs'));

    // Save colors
    $primary_color = trim($_POST['primary_color'] ?? '#1B2A6B');
    if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $primary_color)) $primary_color = '#1B2A6B';
    $secondary_color = trim($_POST['secondary_color'] ?? '#C9A227');
    if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $secondary_color)) $secondary_color = '#C9A227';

    upsertSetup($pdo, 'primary_color',     $primary_color);
    upsertSetup($pdo, 'primary_color_rgb', hexToRgbSetup($primary_color));
    upsertSetup($pdo, 'secondary_color',   $secondary_color);

    // Handle logo upload (optional)
    if (isset($_FILES['school_logo']) && $_FILES['school_logo']['error'] === UPLOAD_ERR_OK) {
        $file      = $_FILES['school_logo'];
        $file_tmp  = $file['tmp_name'];
        $file_size = $file['size'];
        $file_ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $finfo     = finfo_open(FILEINFO_MIME_TYPE);
        $mime      = finfo_file($finfo, $file_tmp);
        finfo_close($finfo);

        if (in_array($file_ext, ['png','jpg','jpeg']) && in_array($mime, ['image/png','image/jpeg']) && $file_size <= 2*1024*1024) {
            $upload_dir = __DIR__ . '/../uploads';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $new_name = 'logo_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . '/' . $new_name)) {
                upsertSetup($pdo, 'school_logo', 'uploads/' . $new_name);
            }
        }
    }

    // Update admin account
    $admin_email = trim($_POST['admin_email'] ?? 'admin@school.edu.ph');
    $hashed_pass = password_hash($admin_password, PASSWORD_BCRYPT);

    // Check if admin user already exists (update) or create new
    $check = $pdo->prepare("SELECT id FROM users WHERE role = 'Admin' LIMIT 1");
    $check->execute();
    $existing_admin = $check->fetch();

    if ($existing_admin) {
        $stmt = $pdo->prepare("
            UPDATE users SET username=?, full_name=?, email=?, password=?, status='Approved' WHERE id=?
        ");
        $stmt->execute([$admin_username, $admin_fullname, $admin_email, $hashed_pass, $existing_admin['id']]);
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO users (username, password, email, full_name, role, status)
            VALUES (?, ?, ?, ?, 'Admin', 'Approved')
        ");
        $stmt->execute([$admin_username, $hashed_pass, $admin_email, $admin_fullname]);
    }

    // Mark setup as complete!
    upsertSetup($pdo, 'setup_complete', '1');

    echo json_encode(['success' => true, 'message' => 'Setup completed successfully!']);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Setup failed: ' . $e->getMessage()]);
}
?>
