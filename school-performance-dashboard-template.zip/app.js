/**
 * Natividad Academy - School Profile & Cohort Survival Dashboard
 * Core Application Logic & Interactive Chart Management
 */

// --- 1. LONGITUDINAL & COHORT DATASTRUCTURES (Mocked for easy PHP/MySQL connection) ---
const schoolMockData = {
    // Cohorts tracking student progress from JHS (Grade 7) to SHS (Grade 12 Graduation)
    studentCohorts: {
        class_2026: {
            name: "Class of 2026",
            start_year: 2020,
            base_size: 520,
            retention: {
                all:          [100, 96.5, 93.8, 91.2, 89.2, 87.5], // G7, G8, G9, G10, G11, G12
                low_income:   [100, 92.4, 88.1, 84.8, 80.2, 78.4],
                ell:          [100, 90.5, 85.2, 81.0, 77.5, 75.2],
                sped:         [100, 93.5, 89.8, 86.2, 82.5, 81.1]
            }
        },
        class_2025: {
            name: "Class of 2025",
            start_year: 2019,
            base_size: 480,
            retention: {
                all:          [100, 95.8, 92.5, 90.0, 88.5, 86.8],
                low_income:   [100, 91.8, 87.2, 83.5, 79.8, 77.2],
                ell:          [100, 89.2, 84.1, 80.5, 76.2, 74.5],
                sped:         [100, 92.1, 88.5, 85.0, 81.2, 79.5]
            }
        },
        class_2024: {
            name: "Class of 2024",
            start_year: 2018,
            base_size: 450,
            retention: {
                all:          [100, 94.2, 91.5, 88.4, 86.2, 84.1],
                low_income:   [100, 89.5, 85.1, 81.2, 77.8, 75.0],
                ell:          [100, 87.6, 82.0, 78.1, 74.0, 71.8],
                sped:         [100, 90.5, 86.2, 82.4, 79.0, 77.2]
            }
        }
    },
    // Historical Cohort Matrix Heatmap Data (G7 base to subsequent years)
    historicalMatrix: [
        { cohort: "Class of 2021", size: 410, rates: [100, 93.2, 89.5, 85.4, 82.1, 80.5] },
        { cohort: "Class of 2022", size: 430, rates: [100, 93.8, 90.2, 86.8, 83.9, 81.8] },
        { cohort: "Class of 2023", size: 440, rates: [100, 94.1, 91.0, 87.5, 84.8, 83.2] },
        { cohort: "Class of 2024", size: 450, rates: [100, 94.2, 91.5, 88.4, 86.2, 84.1] },
        { cohort: "Class of 2025", size: 480, rates: [100, 95.8, 92.5, 90.0, 88.5, 86.8] },
        { cohort: "Class of 2026", size: 520, rates: [100, 96.5, 93.8, 91.2, 89.2, 87.5] }
    ],
    // Teacher retention cohorts tracked over a 5-year tenure span
    teacherCohorts: {
        years: ["Year 1 Hired", "Year 2", "Year 3", "Year 4", "Year 5"],
        datasets: [
            { label: "2021 Hires (n=18)", data: [100, 94.4, 88.9, 83.3, 83.3], borderColor: "#3b82f6" },
            { label: "2022 Hires (n=20)", data: [100, 95.0, 90.0, 85.0, 80.0], borderColor: "#10b981" },
            { label: "2023 Hires (n=15)", data: [100, 86.7, 80.0, 73.3, 73.3], borderColor: "#fbbf24" }
        ]
    },
    // Enrollment progression history
    enrollmentHistory: {
        years: ["2021-22", "2022-23", "2023-24", "2024-25", "2025-26"],
        jhs: [1420, 1445, 1490, 1515, 1540],
        shs: [1110, 1140, 1180, 1220, 1305]
    },
    // Grade levels size distributions
    gradeLevels: ["Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"],
    gradeCounts: [520, 502, 488, 480, 440, 415]
};

let schoolDashboardData = schoolMockData; // Standard variable used in UI charts, defaults to offline mockup

// --- 2. GLOBAL CHART AND THEME CONFIGURATIONS ---
let activeCharts = {};

/**
 * Get visual styling parameters based on current light/dark theme variables.
 */
function getThemeStyles() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    return {
        textColor: isDark ? '#94a3b8' : '#475569',
        gridColor: isDark ? '#1e293b' : '#e2e8f0',
        tooltipBg: isDark ? '#0f172a' : '#ffffff',
        tooltipBorder: isDark ? '#1e293b' : '#cbd5e1',
        tooltipColor: isDark ? '#f8fafc' : '#0f172a'
    };
}

/**
 * Configure standard styling defaults for Chart.js
 */
function setChartDefaults() {
    const styles = getThemeStyles();
    Chart.defaults.color = styles.textColor;
    Chart.defaults.borderColor = styles.gridColor;
    Chart.defaults.font.family = "'Outfit', sans-serif";
    Chart.defaults.plugins.tooltip.backgroundColor = styles.tooltipBg;
    Chart.defaults.plugins.tooltip.titleColor = styles.tooltipColor;
    Chart.defaults.plugins.tooltip.bodyColor = styles.textColor;
    Chart.defaults.plugins.tooltip.borderColor = styles.tooltipBorder;
    Chart.defaults.plugins.tooltip.borderWidth = 1;
}

// --- 3. DYNAMIC PAGES NAVIGATION (SPA ROUTER) ---
document.addEventListener("DOMContentLoaded", () => {
    // 1. Fetch live cohort database coordinates from our REST PHP controller
    fetch('get_cohort_data.php')
        .then(response => {
            if (!response.ok) {
                throw new Error("HTTP error, status = " + response.status);
            }
            return response.json();
        })
        .then(data => {
            if (data && !data.error) {
                console.log("[DB SUCCESS] Dashboard connected and data loaded from local MySQL database successfully.");
                schoolDashboardData = data;
            } else {
                console.warn("[DB FAIL] Database script returned error response, running dashboard in offline mock mode.", data ? data.error : "");
            }
        })
        .catch(err => {
            console.log("[DB FAIL] Could not reach get_cohort_data.php endpoint. Running dashboard in offline mock mode.", err);
        })
        .finally(() => {
            // 2. Initialize sidebar routes, theme controllers, and draw default overview metrics
            initializeRouter();
            initializeThemeToggle();
            initializeMobileNav();
            setChartDefaults();
            renderPage("overview");
        });
});

function initializeRouter() {
    const menuItems = document.querySelectorAll(".sidebar-menu-item");
    
    menuItems.forEach(item => {
        item.addEventListener("click", (e) => {
            e.preventDefault();
            const pageId = item.getAttribute("data-page");
            
            // Update Active Class in Menu
            menuItems.forEach(mi => mi.classList.remove("active"));
            item.classList.add("active");
            
            // Close mobile menu if open
            const sidebar = document.getElementById("sidebar");
            sidebar.classList.remove("open");
            
            // Navigate and update URL hash
            location.hash = pageId;
            renderPage(pageId);
        });
    });
    
    // Handle URL hash changes
    window.addEventListener("hashchange", () => {
        const hash = location.hash.replace("#", "") || "overview";
        const matchedItem = document.querySelector(`.sidebar-menu-item[data-page="${hash}"]`);
        if (matchedItem) {
            menuItems.forEach(mi => mi.classList.remove("active"));
            matchedItem.classList.add("active");
            renderPage(hash);
        }
    });

    // Initial load hash navigation
    const initialHash = location.hash.replace("#", "");
    if (initialHash) {
        const matchedItem = document.querySelector(`.sidebar-menu-item[data-page="${initialHash}"]`);
        if (matchedItem) {
            menuItems.forEach(mi => mi.classList.remove("active"));
            matchedItem.classList.add("active");
        }
    }
}

function initializeMobileNav() {
    const burgerBtn = document.getElementById("menu-toggle");
    const sidebar = document.getElementById("sidebar");
    
    burgerBtn.addEventListener("click", () => {
        sidebar.classList.toggle("open");
    });
}

function renderPage(pageId) {
    // Hide all pages, show selected
    document.querySelectorAll(".dashboard-page").forEach(page => page.classList.remove("active"));
    
    const targetPage = document.getElementById(`${pageId}-page`);
    if (targetPage) {
        targetPage.classList.add("active");
    }
    
    // Update Header Metadata
    const pageTitle = document.getElementById("page-title");
    const pageDesc = document.getElementById("page-description");
    
    // Destroy all charts when changing pages to prevent ghost renders
    Object.keys(activeCharts).forEach(chartKey => {
        if (activeCharts[chartKey]) {
            activeCharts[chartKey].destroy();
            activeCharts[chartKey] = null;
        }
    });
    
    // Reset configurations
    setChartDefaults();

    switch(pageId) {
        case "overview":
            pageTitle.innerText = "School Profile Overview";
            pageDesc.innerText = "General performance KPIs, current enrollment, and student success distributions.";
            renderOverviewCharts();
            break;
            
        case "cohort":
            pageTitle.innerText = "Student Persistence & Cohort Survival";
            pageDesc.innerText = "Longitudinal student pathways tracking persistence rates from junior to senior high school.";
            setupCohortPageHandlers();
            renderCohortPageData();
            break;
            
        case "demographics":
            pageTitle.innerText = "Demographics & Academic Equity";
            pageDesc.innerText = "Analyzing enrollment distribution and student success indexes across support subgroups.";
            renderDemographicCharts();
            break;
            
        case "teachers":
            pageTitle.innerText = "Faculty Profiles & Teacher Retention";
            pageDesc.innerText = "Longitudinal survival rates of faculty members and retention highlights.";
            renderTeacherCharts();
            break;
    }
}

// --- 4. THEME TOGGLE CONTROLLER ---
function initializeThemeToggle() {
    const toggle = document.getElementById("theme-toggle");
    const themeLabel = document.getElementById("theme-text");
    
    // Load saved preference
    const savedTheme = localStorage.getItem("theme") || "dark";
    document.documentElement.setAttribute("data-theme", savedTheme);
    toggle.checked = (savedTheme === "dark");
    themeLabel.innerText = savedTheme === "dark" ? "Dark Mode" : "Light Mode";
    
    toggle.addEventListener("change", () => {
        const targetTheme = toggle.checked ? "dark" : "light";
        document.documentElement.setAttribute("data-theme", targetTheme);
        themeLabel.innerText = toggle.checked ? "Dark Mode" : "Light Mode";
        localStorage.setItem("theme", targetTheme);
        
        // Re-render currently active page charts to match new theme
        const activeItem = document.querySelector(".sidebar-menu-item.active");
        if (activeItem) {
            renderPage(activeItem.getAttribute("data-page"));
        }
    });
}

// --- 5. PAGE-SPECIFIC CHART RENDERING ENGINES ---

/**
 * Page 1: School Profile Overview Charts
 */
function renderOverviewCharts() {
    // A. Enrollment History Stacked Chart
    const ctxHistory = document.getElementById("overviewEnrollmentChart").getContext("2d");
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    
    const gradBlue = ctxHistory.createLinearGradient(0, 0, 0, 300);
    gradBlue.addColorStop(0, "rgba(59, 130, 246, 0.4)");
    gradBlue.addColorStop(1, "rgba(59, 130, 246, 0.0)");
    
    const gradEmerald = ctxHistory.createLinearGradient(0, 0, 0, 300);
    gradEmerald.addColorStop(0, "rgba(16, 185, 129, 0.4)");
    gradEmerald.addColorStop(1, "rgba(16, 185, 129, 0.0)");

    activeCharts.overviewEnrollment = new Chart(ctxHistory, {
        type: 'line',
        data: {
            labels: schoolDashboardData.enrollmentHistory.years,
            datasets: [
                {
                    label: "Junior High School (JHS)",
                    data: schoolDashboardData.enrollmentHistory.jhs,
                    borderColor: "#3b82f6",
                    backgroundColor: gradBlue,
                    fill: true,
                    tension: 0.35,
                    borderWidth: 3,
                    pointBackgroundColor: "#3b82f6"
                },
                {
                    label: "Senior High School (SHS)",
                    data: schoolDashboardData.enrollmentHistory.shs,
                    borderColor: "#10b981",
                    backgroundColor: gradEmerald,
                    fill: true,
                    tension: 0.35,
                    borderWidth: 3,
                    pointBackgroundColor: "#10b981"
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            },
            scales: {
                y: {
                    stacked: false,
                    grid: { color: getThemeStyles().gridColor },
                    ticks: { color: getThemeStyles().textColor }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: getThemeStyles().textColor }
                }
            }
        }
    });

    // B. Grade-level Breakdowns Horizontal Bar Chart
    const ctxGrades = document.getElementById("overviewGradesChart").getContext("2d");
    activeCharts.overviewGrades = new Chart(ctxGrades, {
        type: 'bar',
        data: {
            labels: schoolDashboardData.gradeLevels,
            datasets: [{
                label: "Enrolled Students",
                data: schoolDashboardData.gradeCounts,
                backgroundColor: [
                    'rgba(59, 130, 246, 0.85)',
                    'rgba(59, 130, 246, 0.85)',
                    'rgba(59, 130, 246, 0.85)',
                    'rgba(59, 130, 246, 0.85)',
                    'rgba(16, 185, 129, 0.85)',
                    'rgba(16, 185, 129, 0.85)'
                ],
                borderRadius: 8,
                maxBarThickness: 32
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    grid: { color: getThemeStyles().gridColor },
                    ticks: { color: getThemeStyles().textColor }
                },
                y: {
                    grid: { display: false },
                    ticks: { color: getThemeStyles().textColor }
                }
            }
        }
    });
}

/**
 * Page 2: Student Cohort Persistence (Survival) Handlers & Render
 */
function setupCohortPageHandlers() {
    const cohortSelect = document.getElementById("cohort-select");
    const subgroupSelect = document.getElementById("subgroup-select");
    
    // Remove old listeners to avoid multiple events firing
    const newCohortSelect = cohortSelect.cloneNode(true);
    cohortSelect.parentNode.replaceChild(newCohortSelect, cohortSelect);
    
    const newSubgroupSelect = subgroupSelect.cloneNode(true);
    subgroupSelect.parentNode.replaceChild(newSubgroupSelect, subgroupSelect);

    newCohortSelect.addEventListener("change", () => renderCohortPageData());
    newSubgroupSelect.addEventListener("change", () => renderCohortPageData());
}

function renderCohortPageData() {
    const cohortKey = document.getElementById("cohort-select").value;
    const subgroupKey = document.getElementById("subgroup-select").value;
    
    const cohort = schoolDashboardData.studentCohorts[cohortKey];
    const rates = cohort.retention[subgroupKey];
    const labels = ["Grade 7 (Entry)", "Grade 8", "Grade 9", "Grade 10", "Grade 11 (SHS)", "Grade 12 (Grad)"];
    
    // A. Update Cohort Performance Cards
    const baseSize = cohort.base_size;
    let factor = 1;
    // Simple mock size adjusts based on subgroup ratios
    if (subgroupKey === 'low_income') factor = 0.15;
    else if (subgroupKey === 'ell') factor = 0.05;
    else if (subgroupKey === 'sped') factor = 0.03;
    
    const currentBaseSize = Math.round(baseSize * factor);
    const jhsPersistenceRate = rates[3]; // Grade 10
    const gradRate = rates[5]; // Grade 12
    const attritionRate = (100 - gradRate).toFixed(1);
    const dropoutsCount = Math.round(currentBaseSize * (attritionRate / 100));

    document.getElementById("cohort-size-val").innerText = currentBaseSize.toLocaleString();
    document.getElementById("cohort-jhs-persistence-val").innerText = jhsPersistenceRate.toFixed(1) + "%";
    document.getElementById("cohort-grad-val").innerText = gradRate.toFixed(1) + "%";
    document.getElementById("cohort-attrition-val").innerText = attritionRate + "%";
    document.getElementById("cohort-attrition-val").nextElementSibling.innerText = `${dropoutsCount} Students dropped off pathway`;

    // B. Draw Step-Line Cohort Survival Curves (Chart.js)
    const ctxCohort = document.getElementById("cohortSurvivalChart").getContext("2d");
    if (activeCharts.cohortCurve) {
        activeCharts.cohortCurve.destroy();
    }
    
    // Create soft gradients
    const gradLine = ctxCohort.createLinearGradient(0, 0, 0, 350);
    gradLine.addColorStop(0, "rgba(59, 130, 246, 0.25)");
    gradLine.addColorStop(1, "rgba(59, 130, 246, 0.0)");

    activeCharts.cohortCurve = new Chart(ctxCohort, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: `${cohort.name} Survival Curve (${subgroupKey.toUpperCase()})`,
                data: rates,
                borderColor: "#3b82f6",
                backgroundColor: gradLine,
                fill: true,
                stepped: true, // Kaplan-Meier curves are stepped charts
                borderWidth: 4,
                pointRadius: 6,
                pointHoverRadius: 9,
                pointBackgroundColor: "#ffffff",
                pointBorderWidth: 3,
                pointBorderColor: "#3b82f6"
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: true, position: 'top' },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const index = context.dataIndex;
                            const rate = context.raw;
                            const activeCount = Math.round(currentBaseSize * (rate / 100));
                            return ` Retention: ${rate}% (${activeCount} / ${currentBaseSize} Students)`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    min: 60,
                    max: 100,
                    grid: { color: getThemeStyles().gridColor },
                    ticks: {
                        color: getThemeStyles().textColor,
                        callback: value => value + "%"
                    }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: getThemeStyles().textColor }
                }
            }
        }
    });

    // C. Draw the Historical Matrix Heatmap Grid
    renderCohortHeatmapTable();
}

function renderCohortHeatmapTable() {
    const tableBody = document.getElementById("cohort-heatmap-body");
    tableBody.innerHTML = ""; // Clear existing
    
    schoolDashboardData.historicalMatrix.forEach(row => {
        const tr = document.createElement("tr");
        
        // Name
        const tdName = document.createElement("td");
        tdName.style.fontWeight = "600";
        tdName.innerText = row.cohort;
        tr.appendChild(tdName);
        
        // Base Size
        const tdSize = document.createElement("td");
        tdSize.innerText = row.size;
        tr.appendChild(tdSize);
        
        // Retention rates cells
        row.rates.forEach((rate, index) => {
            const tdCell = document.createElement("td");
            tdCell.className = "cohort-cell " + getHeatmapCellClass(rate);
            tdCell.innerText = rate.toFixed(1) + "%";
            
            // Click handler to show descriptive school popups
            tdCell.addEventListener("click", () => {
                const gradeLabel = ["Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"][index];
                const activeCount = Math.round(row.size * (rate / 100));
                const droppedCount = row.size - activeCount;
                
                alert(`[${row.cohort} - ${gradeLabel} Persistence]\n\n• Survival Rate: ${rate}%\n• Retained Students: ${activeCount} out of ${row.size}\n• Attrition Count: ${droppedCount} dropped/transferred out.`);
            });
            
            tr.appendChild(tdCell);
        });
        
        tableBody.appendChild(tr);
    });
}

function getHeatmapCellClass(rate) {
    if (rate === 100) return "cell-100";
    if (rate >= 95) return "cell-90";
    if (rate >= 90) return "cell-80";
    if (rate >= 85) return "cell-70";
    if (rate >= 80) return "cell-60";
    if (rate >= 75) return "cell-50";
    return "cell-low";
}

/**
 * Page 3: Demographics & Equity Charts
 */
function renderDemographicCharts() {
    // A. Pie Chart (Distribution)
    const ctxPie = document.getElementById("demographicsPieChart").getContext("2d");
    activeCharts.demographicsPie = new Chart(ctxPie, {
        type: 'doughnut',
        data: {
            labels: ["General Education", "Low-Income Support", "Special Ed (SPED)", "English Learners (ELL)"],
            datasets: [{
                data: [78.9, 14.4, 2.7, 3.9],
                backgroundColor: [
                    '#3b82f6', // Navy Blue
                    '#10b981', // Emerald
                    '#fbbf24', // Yellow Gold
                    '#f43f5e'  // Coral Red
                ],
                borderWidth: 2,
                borderColor: getThemeStyles().tooltipBg
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });

    // B. Bar Chart (Subgroup Retention Comparison)
    const ctxBar = document.getElementById("demographicsBarChart").getContext("2d");
    activeCharts.demographicsBar = new Chart(ctxBar, {
        type: 'bar',
        data: {
            labels: ["JHS-to-SHS transition", "Overall Graduation Rate", "Average Attendance"],
            datasets: [
                {
                    label: "General Ed",
                    data: [94.2, 89.8, 96.1],
                    backgroundColor: 'rgba(59, 130, 246, 0.85)',
                    borderRadius: 6
                },
                {
                    label: "Low-Income",
                    data: [86.5, 78.4, 91.8],
                    backgroundColor: 'rgba(16, 185, 129, 0.85)',
                    borderRadius: 6
                },
                {
                    label: "SPED",
                    data: [88.4, 81.1, 93.2],
                    backgroundColor: 'rgba(251, 191, 36, 0.85)',
                    borderRadius: 6
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            },
            scales: {
                y: {
                    grid: { color: getThemeStyles().gridColor },
                    ticks: { color: getThemeStyles().textColor }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: getThemeStyles().textColor }
                }
            }
        }
    });
}

/**
 * Page 4: Faculty Profile & Teacher Retention Charts
 */
function renderTeacherCharts() {
    const ctxTeacher = document.getElementById("teacherSurvivalChart").getContext("2d");
    
    const formattedDatasets = schoolDashboardData.teacherCohorts.datasets.map(dataset => {
        return {
            ...dataset,
            borderWidth: 3,
            stepped: true, // Step survival charts represent attrition beautifully
            fill: false,
            pointRadius: 5
        };
    });

    activeCharts.teacherCurve = new Chart(ctxTeacher, {
        type: 'line',
        data: {
            labels: schoolDashboardData.teacherCohorts.years,
            datasets: formattedDatasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            },
            scales: {
                y: {
                    min: 60,
                    max: 100,
                    grid: { color: getThemeStyles().gridColor },
                    ticks: {
                        color: getThemeStyles().textColor,
                        callback: value => value + "%"
                    }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: getThemeStyles().textColor }
                }
            }
        }
    });
}
