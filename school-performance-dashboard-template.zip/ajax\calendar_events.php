<?php
// ajax/calendar_events.php
require_once __DIR__ . '/../config/session.php';
require_login();

header('Content-Type: application/json; charset=utf-8');

try {
    $today = date('Y-m-d');
    
    // Admins and Faculty can see all active/inactive scheduled announcements
    // Students can only see active ones within their validity dates
    $role = $_SESSION['user_role'] ?? 'Student';
    
    if ($role === 'Admin' || $role === 'Faculty') {
        $stmt = $pdo->query("SELECT * FROM announcements WHERE start_date IS NOT NULL ORDER BY created_at DESC");
        $announcements = $stmt->fetchAll();
    } else {
        $stmt = $pdo->query("
            SELECT * FROM announcements 
            WHERE is_active = 1 
              AND start_date IS NOT NULL
            ORDER BY created_at DESC
        ");
        $announcements = $stmt->fetchAll();
    }

    $events = [];
    foreach ($announcements as $ann) {
        $start = $ann['start_date'];
        $end = !empty($ann['end_date']) ? $ann['end_date'] : $ann['start_date'];
        
        // FullCalendar expects 'end' to be exclusive for allDay events,
        // so to make it span correctly visually, we increment the end date by 1 day.
        $fc_end = $end;
        if (!empty($ann['end_date'])) {
            $date = new DateTime($ann['end_date']);
            $date->modify('+1 day');
            $fc_end = $date->format('Y-m-d');
        } else {
            // For single-day events, increment start date by 1 day for proper exclusive formatting
            $date = new DateTime($ann['start_date']);
            $date->modify('+1 day');
            $fc_end = $date->format('Y-m-d');
        }

        // Color coding by category
        $color = '#1b2a6b'; // Navy (General)
        if ($ann['category'] === 'suspension') {
            $color = '#dc2626'; // Red (Suspension)
        } elseif ($ann['category'] === 'event') {
            $color = '#c9a227'; // Gold (Event)
        }

        $events[] = [
            'id'              => $ann['id'],
            'title'           => $ann['title'],
            'start'           => $start,
            'end'             => $fc_end,
            'allDay'          => true,
            'backgroundColor' => $color,
            'borderColor'     => $color,
            'textColor'       => '#ffffff',
            'extendedProps'   => [
                'category'    => $ann['category'],
                'content'     => $ann['content'],
                'start_raw'   => date('M d, Y', strtotime($start)),
                'end_raw'     => !empty($ann['end_date']) ? date('M d, Y', strtotime($ann['end_date'])) : date('M d, Y', strtotime($start)),
                'is_active'   => (int)$ann['is_active']
            ]
        ];
    }

    echo json_encode($events);
    exit;

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch calendar events: ' . $e->getMessage()]);
    exit;
}
?>
