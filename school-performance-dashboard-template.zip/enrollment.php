<?php
require_once __DIR__ . '/config/session.php';
require_login();

// Restrict strictly to Admin and Faculty roles
if (!has_role('Admin', 'Faculty')) {
    $page_title = 'Access Denied';
    $breadcrumb = 'Access Denied';
    include 'includes/header.php';
    echo '<div class="d-flex align-items-center justify-content-center" style="min-height:50vh;">
      <div class="text-center">
        <div style="font-size:4rem;margin-bottom:1rem;">🔒</div>
        <h2 class="fw-700 text-dark mb-2">Access Denied</h2>
        <p class="text-muted mb-3">You do not have permission to view this page. This area is reserved for staff members.</p>
        <a href="dashboard.php" class="btn-primary-nhs"><i class="bi bi-arrow-left me-1"></i> Back to Dashboard</a>
      </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

if (defined('FEATURE_DATA_ENTRY') && !FEATURE_DATA_ENTRY) {
    http_response_code(403);
    die('Data entry feature is currently disabled.');
}

$page_title = 'Enrollment Management';
$breadcrumb = 'Enrollment';

$sy_rows = $pdo->query("SELECT DISTINCT school_year FROM enrollment_data ORDER BY school_year DESC")->fetchAll();
$sy_list = array_column($sy_rows, 'school_year');
$selected_sy = $_GET['sy'] ?? ($sy_list[0] ?? '2025-2026');

// Fetch grade levels
$allowed_level_types = [];
if (has_kinder()) $allowed_level_types[] = 'Kindergarten';
if (has_elementary()) $allowed_level_types[] = 'Elementary';
if (has_jhs()) $allowed_level_types[] = 'Junior High';
if (has_shs()) $allowed_level_types[] = 'Senior High';
if (empty($allowed_level_types)) $allowed_level_types = ['Junior High', 'Senior High'];

$level_type_clause = "gl.level_type IN ('" . implode("','", $allowed_level_types) . "')";

$grades = $pdo->query("SELECT * FROM grade_levels WHERE level_type IN ('" . implode("','", $allowed_level_types) . "') ORDER BY id")->fetchAll();
$strands = $pdo->query("SELECT * FROM strands ORDER BY strand_name")->fetchAll();

// Main enrollment table
$q = $pdo->prepare("
  SELECT e.id, e.grade_level_id, e.strand_id,
         gl.grade_name, gl.level_type, s.strand_code, e.semester,
         e.bosy_enrollment, e.school_year,
         COALESCE(r.repeaters_count, 0) AS repeaters,
         COALESCE(d.dropouts_count,  0) AS dropouts
  FROM enrollment_data e
  JOIN grade_levels gl ON gl.id = e.grade_level_id
  LEFT JOIN strands s   ON s.id  = e.strand_id
  LEFT JOIN repeaters_data r
         ON r.grade_level_id = e.grade_level_id
        AND (r.strand_id IS NULL OR r.strand_id = e.strand_id)
        AND r.school_year = e.school_year
        AND (
              (e.semester = 'Full Year' AND (r.semester IS NULL OR r.semester = 'Full Year'))
           OR (e.semester != 'Full Year' AND r.semester = e.semester)
             )
  LEFT JOIN dropouts_data d
         ON d.grade_level_id = e.grade_level_id
        AND (d.strand_id IS NULL OR d.strand_id = e.strand_id)
        AND d.school_year = e.school_year
        AND (
              (e.semester = 'Full Year' AND (d.semester IS NULL OR d.semester = 'Full Year'))
           OR (e.semester != 'Full Year' AND d.semester = e.semester)
             )
  WHERE e.school_year = ? AND $level_type_clause
  ORDER BY gl.id, e.strand_id, e.semester
");
$q->execute([$selected_sy]);
$records = $q->fetchAll();

// --- Year-to-Year Comparison Calculations ---
$active_tab = $_GET['tab'] ?? 'records';

$comp_base = $_GET['comp_base'] ?? ($sy_list[1] ?? ($sy_list[0] ?? '2024-2025'));
$comp_target = $_GET['comp_target'] ?? ($selected_sy ?? ($sy_list[0] ?? '2025-2026'));

// Helper function to fetch aggregated totals for a specific school year
if (!function_exists('getSyTotals')) {
    function getSyTotals($pdo, $sy) {
        // Total enrollment (counting JHS, and SHS 1st Sem only to avoid double-counting enrollees)
        $q = $pdo->prepare("
          SELECT COALESCE(SUM(
            CASE
              WHEN gl.level_type='Senior High' THEN (CASE WHEN e.semester='1st Sem' THEN e.bosy_enrollment ELSE 0 END)
              ELSE e.bosy_enrollment
            END
          ),0) AS total_enr
          FROM enrollment_data e
          JOIN grade_levels gl ON gl.id = e.grade_level_id
          WHERE e.school_year = ? AND gl.level_type IN ('" . implode("','", $allowed_level_types) . "')
        ");
        $q->execute([$sy]);
        $enr = (int)$q->fetchColumn();

        // Total repeaters
        $q = $pdo->prepare("
          SELECT COALESCE(SUM(r.repeaters_count),0) 
          FROM repeaters_data r
          JOIN grade_levels gl ON gl.id = r.grade_level_id
          WHERE r.school_year = ? AND gl.level_type IN ('" . implode("','", $allowed_level_types) . "')
        ");
        $q->execute([$sy]);
        $rep = (int)$q->fetchColumn();

        // Total dropouts
        $q = $pdo->prepare("
          SELECT COALESCE(SUM(d.dropouts_count),0) 
          FROM dropouts_data d
          JOIN grade_levels gl ON gl.id = d.grade_level_id
          WHERE d.school_year = ? AND gl.level_type IN ('" . implode("','", $allowed_level_types) . "')
        ");
        $q->execute([$sy]);
        $drp = (int)$q->fetchColumn();

        return [
            'enrollment' => $enr,
            'repeaters' => $rep,
            'dropouts' => $drp
        ];
    }
}

// Helper function to fetch grade-level metrics for a specific school year
if (!function_exists('getGradeMetrics')) {
    function getGradeMetrics($pdo, $sy) {
        $q = $pdo->prepare("
          SELECT gl.id, gl.grade_name, gl.level_type,
            COALESCE(SUM(
              CASE
                WHEN gl.level_type='Senior High' THEN (CASE WHEN e.semester='1st Sem' THEN e.bosy_enrollment ELSE 0 END)
                ELSE e.bosy_enrollment
              END
            ),0) AS enrollment,
            (
              SELECT COALESCE(SUM(r.repeaters_count),0)
              FROM repeaters_data r
              WHERE r.grade_level_id = gl.id AND r.school_year = ?
            ) AS repeaters,
            (
              SELECT COALESCE(SUM(d.dropouts_count),0)
              FROM dropouts_data d
              WHERE d.grade_level_id = gl.id AND d.school_year = ?
            ) AS dropouts
          FROM grade_levels gl
          LEFT JOIN enrollment_data e ON e.grade_level_id = gl.id AND e.school_year = ?
          WHERE gl.level_type IN ('" . implode("','", $allowed_level_types) . "')
          GROUP BY gl.id
          ORDER BY gl.id
        ");
        $q->execute([$sy, $sy, $sy]);
        return $q->fetchAll(PDO::FETCH_UNIQUE);
    }
}

$base_totals = getSyTotals($pdo, $comp_base);
$target_totals = getSyTotals($pdo, $comp_target);

$base_grade_metrics = getGradeMetrics($pdo, $comp_base);
$target_grade_metrics = getGradeMetrics($pdo, $comp_target);

// Calculations for Variance KPIs
$enr_diff = $target_totals['enrollment'] - $base_totals['enrollment'];
$enr_pct = $base_totals['enrollment'] > 0 ? round(($enr_diff / $base_totals['enrollment']) * 100, 1) : 0;

$rep_diff = $target_totals['repeaters'] - $base_totals['repeaters'];
$rep_pct = $base_totals['repeaters'] > 0 ? round(($rep_diff / $base_totals['repeaters']) * 100, 1) : 0;

$drp_diff = $target_totals['dropouts'] - $base_totals['dropouts'];
$drp_pct = $base_totals['dropouts'] > 0 ? round(($drp_diff / $base_totals['dropouts']) * 100, 1) : 0;

// --- 5-Year Historical Longitudinal Trend Data Preparation ---
$trend_sy_list = array_slice($sy_list, 0, 5);
$trend_sy_list = array_reverse($trend_sy_list);

$trend_rep_data = [];
$trend_drp_data = [];

foreach ($trend_sy_list as $yr) {
    // Sum repeaters for this year (semester aware to avoid duplicate Full Year rows in SHS)
    $q_rep = $pdo->prepare("
        SELECT COALESCE(SUM(r.repeaters_count), 0) 
        FROM repeaters_data r
        JOIN grade_levels gl ON gl.id = r.grade_level_id
        WHERE r.school_year = ? AND gl.level_type IN ('" . implode("','", $allowed_level_types) . "')
          AND (
            (gl.level_type = 'Senior High' AND r.semester IN ('1st Sem', '2nd Sem'))
            OR (gl.level_type != 'Senior High' AND (r.semester = 'Full Year' OR r.semester IS NULL))
          )
    ");
    $q_rep->execute([$yr]);
    $trend_rep_data[] = (int)$q_rep->fetchColumn();

    // Sum dropouts for this year (semester aware to avoid duplicate Full Year rows in SHS)
    $q_drp = $pdo->prepare("
        SELECT COALESCE(SUM(d.dropouts_count), 0) 
        FROM dropouts_data d
        JOIN grade_levels gl ON gl.id = d.grade_level_id
        WHERE d.school_year = ? AND gl.level_type IN ('" . implode("','", $allowed_level_types) . "')
          AND (
            (gl.level_type = 'Senior High' AND d.semester IN ('1st Sem', '2nd Sem'))
            OR (gl.level_type != 'Senior High' AND (d.semester = 'Full Year' OR d.semester IS NULL))
          )
    ");
    $q_drp->execute([$yr]);
    $trend_drp_data[] = (int)$q_drp->fetchColumn();
}

// --- 5-Year Grade-Level Trend Data ---
$grade_trends_data = [];
foreach ($grades as $g) {
    $g_id = $g['id'];
    $grade_trends_data[$g_id] = [
        'grade_name' => $g['grade_name'],
        'level_type' => $g['level_type'],
        'years' => [],
        'enrollment' => [],
        'dropouts' => [],
        'repeaters' => []
    ];
    
    foreach ($trend_sy_list as $yr) {
        $grade_trends_data[$g_id]['years'][] = $yr;
        
        // Sum enrollment for this grade and year (SHS 1st Sem only to avoid double counting)
        $q_enr = $pdo->prepare("
            SELECT COALESCE(SUM(
                CASE 
                    WHEN gl.level_type = 'Senior High' THEN (CASE WHEN e.semester = '1st Sem' THEN e.bosy_enrollment ELSE 0 END)
                    ELSE e.bosy_enrollment
                END
            ), 0)
            FROM enrollment_data e
            JOIN grade_levels gl ON gl.id = e.grade_level_id
            WHERE e.grade_level_id = ? AND e.school_year = ?
        ");
        $q_enr->execute([$g_id, $yr]);
        $grade_trends_data[$g_id]['enrollment'][] = (int)$q_enr->fetchColumn();
        
        // Sum dropouts (semester aware to avoid duplicate Full Year rows in SHS)
        $q_drp = $pdo->prepare("
            SELECT COALESCE(SUM(d.dropouts_count), 0) 
            FROM dropouts_data d
            JOIN grade_levels gl ON gl.id = d.grade_level_id
            WHERE d.grade_level_id = ? AND d.school_year = ?
              AND (
                (gl.level_type = 'Senior High' AND d.semester IN ('1st Sem', '2nd Sem'))
                OR (gl.level_type != 'Senior High' AND (d.semester = 'Full Year' OR d.semester IS NULL))
              )
        ");
        $q_drp->execute([$g_id, $yr]);
        $grade_trends_data[$g_id]['dropouts'][] = (int)$q_drp->fetchColumn();
        
        // Sum repeaters (semester aware to avoid duplicate Full Year rows in SHS)
        $q_rep = $pdo->prepare("
            SELECT COALESCE(SUM(r.repeaters_count), 0) 
            FROM repeaters_data r
            JOIN grade_levels gl ON gl.id = r.grade_level_id
            WHERE r.grade_level_id = ? AND r.school_year = ?
              AND (
                (gl.level_type = 'Senior High' AND r.semester IN ('1st Sem', '2nd Sem'))
                OR (gl.level_type != 'Senior High' AND (r.semester = 'Full Year' OR r.semester IS NULL))
              )
        ");
        $q_rep->execute([$g_id, $yr]);
        $grade_trends_data[$g_id]['repeaters'][] = (int)$q_rep->fetchColumn();
    }
}

$records_active = ($active_tab === 'records') ? 'active' : '';
$records_show = ($active_tab === 'records') ? 'show active' : '';
$comparison_active = ($active_tab === 'comparison') ? 'active' : '';
$comparison_show = ($active_tab === 'comparison') ? 'show active' : '';
$trends_active = ($active_tab === 'trends') ? 'active' : '';
$trends_show = ($active_tab === 'trends') ? 'show active' : '';

include 'includes/header.php';
?>
<style>
/* --- Color Palette Tokens --- */
:root {
  --glow-blue: 27, 42, 107;
  --glow-gold: 201, 162, 39;
  --glow-red: 139, 26, 26;
  --text-rgb: 26, 26, 46;
}
[data-theme="dark"] {
  --glow-blue: 107, 155, 232;
  --glow-gold: 240, 202, 118;
  --glow-red: 245, 160, 160;
  --text-rgb: 220, 226, 244;
}

/* --- Premium Tab Switcher --- */
.enrollment-nav-pills-wrap {
  margin-bottom: 1.5rem;
}
.enrollment-nav-pills {
  background: var(--surface);
  border: 1px solid var(--border);
  padding: 6px;
  border-radius: 14px;
  display: inline-flex;
  gap: 4px;
  box-shadow: var(--shadow);
}
.enrollment-nav-pills .nav-link {
  color: var(--text-muted);
  font-weight: 500;
  font-size: .85rem;
  border-radius: 10px;
  padding: 8px 22px;
  border: none !important;
  background: transparent;
  transition: var(--transition);
}
.enrollment-nav-pills .nav-link:hover {
  color: var(--accent);
  background: var(--bg);
}
.enrollment-nav-pills .nav-link.active {
  background: var(--primary) !important;
  color: #ffffff !important;
  font-weight: 600;
  box-shadow: 0 4px 12px rgba(27, 42, 107, 0.18);
}
[data-theme="dark"] .enrollment-nav-pills .nav-link.active {
  background: var(--accent) !important;
  color: var(--primary-dark) !important;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
}

/* --- Glassmorphic Filters & Panels --- */
.glass-panel-aesthetic {
  background: rgba(255, 255, 255, 0.55);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.4);
  border-radius: var(--radius);
  box-shadow: 0 8px 32px rgba(27, 42, 107, 0.05);
  transition: var(--transition);
}
[data-theme="dark"] .glass-panel-aesthetic {
  background: rgba(37, 42, 68, 0.45);
  border: 1px solid rgba(255, 255, 255, 0.06);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.22);
}

/* --- High-End Mesh KPI Cards --- */
.comp-card-aesthetic {
  position: relative;
  background: linear-gradient(135deg, var(--surface) 0%, rgba(var(--card-glow-rgb), 0.02) 100%);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 24px;
  box-shadow: var(--shadow);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%;
}
.comp-card-aesthetic.c-blue {
  --card-glow: rgb(var(--glow-blue));
  --card-glow-rgb: var(--glow-blue);
}
.comp-card-aesthetic.c-gold {
  --card-glow: rgb(var(--glow-gold));
  --card-glow-rgb: var(--glow-gold);
}
.comp-card-aesthetic.c-red {
  --card-glow: rgb(var(--glow-red));
  --card-glow-rgb: var(--glow-red);
}

.comp-card-aesthetic::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 4px;
  background: var(--card-glow);
  opacity: 0.85;
}
.comp-card-aesthetic:hover {
  transform: translateY(-5px);
  box-shadow: var(--shadow-md), 0 10px 24px rgba(var(--card-glow-rgb), 0.08);
  border-color: rgba(var(--card-glow-rgb), 0.3);
}

/* Watermark floating icon in card background */
.comp-bg-icon {
  position: absolute;
  right: -10px;
  bottom: -15px;
  font-size: 5.8rem;
  opacity: 0.04;
  color: var(--text);
  transform: rotate(-15deg);
  transition: transform 0.4s ease, opacity 0.4s ease;
  pointer-events: none;
}
.comp-card-aesthetic:hover .comp-bg-icon {
  transform: scale(1.12) rotate(-8deg);
  opacity: 0.07;
}

.comp-val-aesthetic {
  font-size: 2rem;
  font-weight: 800;
  background: linear-gradient(135deg, var(--text) 30%, rgba(var(--text-rgb), 0.8) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  letter-spacing: -1px;
}
.comp-base-lbl-aesthetic {
  font-size: 0.85rem;
  color: var(--text-muted);
  font-weight: 500;
}
.comp-arrow-divider {
  font-size: 0.9rem;
  color: var(--text-muted);
  margin: 0 4px;
}

/* Glowing Neon Pills */
.badge-aesthetic {
  font-size: 0.72rem;
  font-weight: 600;
  padding: 4px 12px;
  border-radius: 99px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
  transition: transform 0.2s ease;
}
.badge-aesthetic:hover {
  transform: scale(1.05);
}
.badge-aesthetic.good {
  background: rgba(22, 163, 74, 0.08) !important;
  color: #16a34a !important;
  border: 1px solid rgba(22, 163, 74, 0.2) !important;
}
.badge-aesthetic.bad {
  background: rgba(220, 38, 38, 0.08) !important;
  color: #dc2626 !important;
  border: 1px solid rgba(220, 38, 38, 0.2) !important;
}
.badge-aesthetic.neutral {
  background: var(--bg) !important;
  color: var(--text-muted) !important;
  border: 1px solid var(--border) !important;
}

[data-theme="dark"] .badge-aesthetic.good {
  background: rgba(125, 217, 163, 0.12) !important;
  color: #7DD9A3 !important;
  border: 1px solid rgba(125, 217, 163, 0.25) !important;
}
[data-theme="dark"] .badge-aesthetic.bad {
  background: rgba(245, 160, 160, 0.12) !important;
  color: #F5A0A0 !important;
  border: 1px solid rgba(245, 160, 160, 0.25) !important;
}

/* --- Premium Tonal Table Grid --- */
.comp-table-aesthetic {
  border-collapse: separate;
  border-spacing: 0;
  width: 100%;
}
.comp-table-aesthetic th {
  background: linear-gradient(135deg, rgba(27, 42, 107, 0.05) 0%, rgba(27, 42, 107, 0.01) 100%) !important;
  color: var(--primary);
  font-weight: 600;
  text-transform: uppercase;
  font-size: 0.72rem;
  letter-spacing: 0.5px;
  padding: 15px 18px;
  border-bottom: 2px solid var(--border) !important;
}
[data-theme="dark"] .comp-table-aesthetic th {
  background: linear-gradient(135deg, rgba(255, 255, 255, 0.03) 0%, rgba(255, 255, 255, 0.01) 100%) !important;
  color: var(--accent) !important;
  border-bottom-color: var(--border) !important;
}
.comp-table-aesthetic td {
  padding: 15px 18px;
  border-bottom: 1px solid rgba(107, 155, 232, 0.08);
  font-size: 0.85rem;
  vertical-align: middle;
  transition: background 0.2s ease;
}
.comp-table-aesthetic tr:hover td {
  background: rgba(27, 42, 107, 0.02);
}
[data-theme="dark"] .comp-table-aesthetic tr:hover td {
  background: rgba(255, 255, 255, 0.025);
}

.grade-indicator-pill {
  width: 4px;
  height: 18px;
  border-radius: 99px;
  display: inline-block;
  vertical-align: middle;
  margin-right: 8px;
}
.grade-indicator-pill.jhs { background: var(--primary); }
.grade-indicator-pill.shs { background: var(--accent); }
.grade-indicator-pill.kinder { background: #EC4899; }
.grade-indicator-pill.elem { background: #10B981; }
</style>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-3">
  <div class="section-header mb-0">
    <h1 class="section-title"><i class="bi bi-person-lines-fill me-2 text-primary-nhs"></i>Enrollment Management</h1>
    <p class="section-sub">BOSY Enrollment, Repeaters & Dropouts — S.Y. <?= htmlspecialchars($selected_sy) ?></p>
  </div>
  <div class="d-flex gap-2">
    <?php if(has_role('Admin','Encoder')): ?>
    <button class="btn-primary-nhs" data-bs-toggle="modal" data-bs-target="#enrollModal">
      <i class="bi bi-plus-circle"></i> Add Record
    </button>
    <?php endif; ?>
    <?php if(has_role('Admin')): ?>
    <button class="btn btn-outline-danger d-inline-flex align-items-center gap-2 px-3 fw-600" style="border-radius: 12px; font-size: 0.85rem;" onclick="confirmDeleteSchoolYear('<?= htmlspecialchars($selected_sy) ?>')">
      <i class="bi bi-trash3-fill"></i> Delete School Year
    </button>
    <?php endif; ?>
  </div>
</div>

<!-- Tabs Switcher Pills -->
<div class="enrollment-nav-pills-wrap">
  <ul class="nav enrollment-nav-pills" id="enrollmentTabs" role="tablist">
    <li class="nav-item" role="presentation">
      <button class="nav-link <?= $records_active ?>" id="records-tab" data-bs-toggle="pill" data-bs-target="#records-pane" type="button" role="tab" aria-controls="records-pane" aria-selected="<?= $active_tab === 'records' ? 'true' : 'false' ?>">
        <i class="bi bi-table me-2"></i>Enrollment Records
      </button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link <?= $comparison_active ?>" id="comparison-tab" data-bs-toggle="pill" data-bs-target="#comparison-pane" type="button" role="tab" aria-controls="comparison-pane" aria-selected="<?= $active_tab === 'comparison' ? 'true' : 'false' ?>">
        <i class="bi bi-arrow-left-right me-2"></i>Year-to-Year Comparison
      </button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link <?= $trends_active ?>" id="trends-tab" data-bs-toggle="pill" data-bs-target="#trends-pane" type="button" role="tab" aria-controls="trends-pane" aria-selected="<?= $active_tab === 'trends' ? 'true' : 'false' ?>">
        <i class="bi bi-graph-up me-2"></i>Grade-Level Trends
      </button>
    </li>
  </ul>
</div>

<div class="tab-content" id="enrollmentTabContent">
  
  <!-- TAB PANE 1: Enrollment Records (Original CRUD Records) -->
  <div class="tab-pane fade <?= $records_show ?>" id="records-pane" role="tabpanel" aria-labelledby="records-tab">
    <div class="data-card">
      <div class="data-card-header">
        <span class="data-card-title">Enrollment Records</span>
        <div class="d-flex gap-2">
          <input type="text" id="searchInput" class="form-control form-control-sm" placeholder="Search..." style="width:200px">
        </div>
      </div>
      <div class="table-responsive">
        <table class="nhs-table" id="enrollTable">
          <thead>
            <tr>
              <th>#</th><th>Grade Level</th><th>Type</th><th>Strand</th>
              <th>Semester</th><th>Enrollment</th><th>Repeaters</th>
              <th>Dropouts</th><th>Rep.Rate</th><th>Drop.Rate</th>
              <?php if(has_role('Admin','Encoder')): ?><th>Actions</th><?php endif; ?>
            </tr>
          </thead>
          <tbody>
            <?php foreach($records as $i => $row):
              $enr = (int)$row['bosy_enrollment'];
              $rep = (int)$row['repeaters'];
              $drp = (int)$row['dropouts'];
              $rr  = $enr > 0 ? round($rep/$enr*100,1) : 0;
              $dr  = $enr > 0 ? round($drp/$enr*100,1) : 0;
              $status_cls = ($dr == 0 && $rr == 0) ? 'badge-good' : ($dr > 10 ? 'badge-danger' : 'badge-warn');
            ?>
            <tr>
              <td class="text-muted"><?= $i+1 ?></td>
              <td class="fw-600"><?= htmlspecialchars($row['grade_name']) ?></td>
              <td><span class="kpi-badge badge-info"><?= $row['level_type'] ?></span></td>
              <td><?= htmlspecialchars($row['strand_code'] ?? '—') ?></td>
              <td><?= htmlspecialchars($row['semester']) ?></td>
              <td class="fw-600"><?= number_format($enr) ?></td>
              <td><?= number_format($rep) ?></td>
              <td><?= number_format($drp) ?></td>
              <td><span class="kpi-badge <?= $rr>8?'badge-danger':($rr>3?'badge-warn':'badge-good') ?>"><?= $rr ?>%</span></td>
              <td><span class="kpi-badge <?= $status_cls ?>"><?= $dr ?>%</span></td>
              <?php if(has_role('Admin','Encoder')): ?>
              <td>
                <button class="btn btn-sm btn-outline-primary me-1" onclick="editEnroll(<?= htmlspecialchars(json_encode($row)) ?>)">
                  <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteRecord(<?= $row['id'] ?>,'enrollment_data','Enrollment')">
                  <i class="bi bi-trash"></i>
                </button>
              </td>
              <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            <?php if(empty($records)): ?>
            <tr><td colspan="11" class="text-center text-muted py-4">No records found for S.Y. <?= htmlspecialchars($selected_sy) ?></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- TAB PANE 2: Year-to-Year Comparison (Premium Aesthetic Dashboard in English) -->
  <div class="tab-pane fade <?= $comparison_show ?>" id="comparison-pane" role="tabpanel" aria-labelledby="comparison-tab">
    
    <!-- Year Selector Form - Glassmorphic Aesthetic Panel -->
    <div class="glass-panel-aesthetic p-4 mb-4">
      <form method="GET" action="enrollment.php" class="row g-3 align-items-center">
        <input type="hidden" name="tab" value="comparison">
        <input type="hidden" name="sy" value="<?= htmlspecialchars($selected_sy) ?>">
        <div class="col-md-5">
          <label class="form-label small fw-600 text-muted d-flex align-items-center gap-2">
            <i class="bi bi-calendar-event text-primary"></i> Baseline School Year
          </label>
          <select name="comp_base" class="form-select border-0 shadow-sm px-3" style="height: 44px; border-radius: 10px;" onchange="this.form.submit()">
            <?php foreach($sy_list as $sy): ?>
            <option value="<?=$sy?>" <?=$sy===$comp_base?'selected':''?>><?=$sy?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-2 text-center pt-4 d-none d-md-block">
          <div class="bg-body-secondary d-inline-flex align-items-center justify-content-center" style="width: 42px; height: 42px; border-radius: 50%;">
            <i class="bi bi-arrow-left-right text-muted"></i>
          </div>
        </div>
        <div class="col-md-5">
          <label class="form-label small fw-600 text-muted d-flex align-items-center gap-2">
            <i class="bi bi-calendar-check text-primary"></i> Comparison School Year
          </label>
          <select name="comp_target" class="form-select border-0 shadow-sm px-3" style="height: 44px; border-radius: 10px;" onchange="this.form.submit()">
            <?php foreach($sy_list as $sy): ?>
            <option value="<?=$sy?>" <?=$sy===$comp_target?'selected':''?>><?=$sy?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </form>
    </div>

    <!-- Executive Comparison KPI Grid -->
    <div class="row g-3 mb-4">
      
      <!-- KPI 1: Enrollees (Aesthetic Glow Card) -->
      <div class="col-md-4">
        <div class="comp-card-aesthetic c-blue">
          <i class="bi bi-people-fill comp-bg-icon"></i>
          <div>
            <span class="comp-lbl d-flex align-items-center gap-2">
              <i class="bi bi-person-badge text-primary-nhs"></i> Total Enrollees
            </span>
            <div class="comp-val-group">
              <span class="comp-base-lbl-aesthetic">
                S.Y. <?= htmlspecialchars($comp_base) ?>: <span class="text-decoration-line-through"><?= number_format($base_totals['enrollment']) ?></span>
              </span>
              <span class="comp-arrow-divider">→</span>
              <span class="comp-val-aesthetic"><?= number_format($target_totals['enrollment']) ?></span>
            </div>
          </div>
          <div class="mt-3 d-flex align-items-center justify-content-between flex-wrap gap-2 pt-2 border-top border-light border-opacity-10">
            <p class="comp-sub-lbl mb-0 max-w-70">
              <?php if($enr_diff > 0): ?>
              Increased by <strong><?= number_format(abs($enr_diff)) ?></strong> enrollees.
              <?php elseif($enr_diff < 0): ?>
              Decreased by <strong><?= number_format(abs($enr_diff)) ?></strong> enrollees.
              <?php else: ?>
              No change in student population.
              <?php endif; ?>
            </p>
            <?php if($enr_diff > 0): ?>
            <span class="badge-aesthetic good"><i class="bi bi-arrow-up-right-circle-fill"></i> +<?= $enr_pct ?>%</span>
            <?php elseif($enr_diff < 0): ?>
            <span class="badge-aesthetic bad"><i class="bi bi-arrow-down-left-circle-fill"></i> <?= $enr_pct ?>%</span>
            <?php else: ?>
            <span class="badge-aesthetic neutral">No change</span>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- KPI 2: Repeaters (Aesthetic Glow Card) -->
      <div class="col-md-4">
        <div class="comp-card-aesthetic c-gold">
          <i class="bi bi-arrow-counterclockwise comp-bg-icon"></i>
          <div>
            <span class="comp-lbl d-flex align-items-center gap-2">
              <i class="bi bi-arrow-repeat text-warning"></i> Total Repeaters
            </span>
            <div class="comp-val-group">
              <span class="comp-base-lbl-aesthetic">
                S.Y. <?= htmlspecialchars($comp_base) ?>: <span class="text-decoration-line-through"><?= number_format($base_totals['repeaters']) ?></span>
              </span>
              <span class="comp-arrow-divider">→</span>
              <span class="comp-val-aesthetic"><?= number_format($target_totals['repeaters']) ?></span>
            </div>
          </div>
          <div class="mt-3 d-flex align-items-center justify-content-between flex-wrap gap-2 pt-2 border-top border-light border-opacity-10">
            <p class="comp-sub-lbl mb-0 max-w-70">
              <?php if($rep_diff < 0): ?>
              Excellent! Decreased by <strong><?= number_format(abs($rep_diff)) ?></strong> repeaters.
              <?php elseif($rep_diff > 0): ?>
              Requires focus. Increased by <strong><?= number_format(abs($rep_diff)) ?></strong> repeaters.
              <?php else: ?>
              No change in repeater count.
              <?php endif; ?>
            </p>
            <?php if($rep_diff < 0): ?>
            <span class="badge-aesthetic good"><i class="bi bi-arrow-down-left-circle-fill"></i> <?= $rep_pct ?>%</span>
            <?php elseif($rep_diff > 0): ?>
            <span class="badge-aesthetic bad"><i class="bi bi-arrow-up-right-circle-fill"></i> +<?= $rep_pct ?>%</span>
            <?php else: ?>
            <span class="badge-aesthetic neutral">No change</span>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- KPI 3: Dropouts (Aesthetic Glow Card) -->
      <div class="col-md-4">
        <div class="comp-card-aesthetic c-red">
          <i class="bi bi-person-x-fill comp-bg-icon"></i>
          <div>
            <span class="comp-lbl d-flex align-items-center gap-2">
              <i class="bi bi-x-circle text-danger"></i> Total Dropouts
            </span>
            <div class="comp-val-group">
              <span class="comp-base-lbl-aesthetic">
                S.Y. <?= htmlspecialchars($comp_base) ?>: <span class="text-decoration-line-through"><?= number_format($base_totals['dropouts']) ?></span>
              </span>
              <span class="comp-arrow-divider">→</span>
              <span class="comp-val-aesthetic"><?= number_format($target_totals['dropouts']) ?></span>
            </div>
          </div>
          <div class="mt-3 d-flex align-items-center justify-content-between flex-wrap gap-2 pt-2 border-top border-light border-opacity-10">
            <p class="comp-sub-lbl mb-0 max-w-70">
              <?php if($drp_diff < 0): ?>
              Great success! Decreased by <strong><?= number_format(abs($drp_diff)) ?></strong> dropouts.
              <?php elseif($drp_diff > 0): ?>
              Requires attention. Increased by <strong><?= number_format(abs($drp_diff)) ?></strong> dropouts.
              <?php else: ?>
              No change in dropout count.
              <?php endif; ?>
            </p>
            <?php if($drp_diff < 0): ?>
            <span class="badge-aesthetic good"><i class="bi bi-arrow-down-left-circle-fill"></i> <?= $drp_pct ?>%</span>
            <?php elseif($drp_diff > 0): ?>
            <span class="badge-aesthetic bad"><i class="bi bi-arrow-up-right-circle-fill"></i> +<?= $drp_pct ?>%</span>
            <?php else: ?>
            <span class="badge-aesthetic neutral">No change</span>
            <?php endif; ?>
          </div>
        </div>
      </div>

    </div>

    <!-- Graphical Comparison Canvas & Grade Level Delta Table Grid -->
    <div class="row g-4 mb-4">
      
      <!-- Left: Chart.js Bar Chart -->
      <div class="col-lg-6">
        <div class="glass-panel-aesthetic p-4" style="height: 500px; min-height: 500px;">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="chart-card-title mb-0"><i class="bi bi-bar-chart-line me-2 text-primary-nhs"></i>Comparative Data Analysis</div>
            <span class="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill px-2 py-1 small fw-500" style="font-size: 0.68rem;">Visual Trend Analysis</span>
          </div>
          <p class="chart-card-sub">Visual comparison: S.Y. <?= htmlspecialchars($comp_base) ?> vs. S.Y. <?= htmlspecialchars($comp_target) ?></p>
          <div class="chart-wrapper" style="height: 390px;">
            <canvas id="syComparisonChart"></canvas>
          </div>
        </div>
      </div>

      <!-- Right: Detailed Grade Delta Analysis Grid -->
      <div class="col-lg-6">
        <div class="glass-panel-aesthetic" style="height: 500px; min-height: 500px; display: flex; flex-direction: column; overflow: hidden;">
          <div class="data-card-header bg-transparent border-0 px-4 pt-4 pb-2">
            <span class="data-card-title mb-0"><i class="bi bi-grid-3x3-gap me-2 text-primary-nhs"></i>Grade-Level Variance Analysis</span>
          </div>
          <div class="table-responsive" style="flex: 1; overflow-y: auto; padding: 0 12px 12px 12px;">
            <table class="comp-table-aesthetic">
              <thead>
                <tr>
                  <th>Grade Level</th>
                  <th class="text-center">Enrollees Diff</th>
                  <th class="text-center">Repeaters Diff</th>
                  <th class="text-center">Dropouts Diff</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach($grades as $g):
                  $g_id = $g['id'];
                  
                  $b_enr = (int)($base_grade_metrics[$g_id]['enrollment'] ?? 0);
                  $t_enr = (int)($target_grade_metrics[$g_id]['enrollment'] ?? 0);
                  $enr_delta = $t_enr - $b_enr;

                  $b_rep = (int)($base_grade_metrics[$g_id]['repeaters'] ?? 0);
                  $t_rep = (int)($target_grade_metrics[$g_id]['repeaters'] ?? 0);
                  $rep_delta = $t_rep - $b_rep;

                  $b_drp = (int)($base_grade_metrics[$g_id]['dropouts'] ?? 0);
                  $t_drp = (int)($target_grade_metrics[$g_id]['dropouts'] ?? 0);
                  $drp_delta = $t_drp - $b_drp;

                  $lvl_class = 'jhs';
                  $lvl_short = 'JHS';
                  if ($g['level_type'] === 'Senior High') { $lvl_class = 'shs'; $lvl_short = 'SHS'; }
                  elseif ($g['level_type'] === 'Kindergarten') { $lvl_class = 'kinder'; $lvl_short = 'Kinder'; }
                  elseif ($g['level_type'] === 'Elementary') { $lvl_class = 'elem'; $lvl_short = 'Elem'; }
                ?>
                <tr>
                  <td class="fw-600">
                    <span class="grade-indicator-pill <?= $lvl_class ?>" title="<?= $g['level_type'] ?>"></span>
                    <?= htmlspecialchars($g['grade_name']) ?> 
                    <span class="text-muted small fw-normal">(<?= $lvl_short ?>)</span>
                  </td>
                  
                  <!-- Enrollees Delta -->
                  <td class="text-center">
                    <?php if($enr_delta > 0): ?>
                    <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-caret-up-fill me-1"></i>+<?= $enr_delta ?></span>
                    <?php elseif($enr_delta < 0): ?>
                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1"><i class="bi bi-caret-down-fill me-1"></i><?= $enr_delta ?></span>
                    <?php else: ?>
                    <span class="badge bg-body-secondary text-muted px-2 py-1">0</span>
                    <?php endif; ?>
                  </td>

                  <!-- Repeaters Delta -->
                  <td class="text-center">
                    <?php if($rep_delta < 0): ?>
                    <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-caret-down-fill me-1"></i><?= $rep_delta ?></span>
                    <?php elseif($rep_delta > 0): ?>
                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1"><i class="bi bi-caret-up-fill me-1"></i>+<?= $rep_delta ?></span>
                    <?php else: ?>
                    <span class="badge bg-body-secondary text-muted px-2 py-1">0</span>
                    <?php endif; ?>
                  </td>

                  <!-- Dropouts Delta -->
                  <td class="text-center">
                    <?php if($drp_delta < 0): ?>
                    <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-caret-down-fill me-1"></i><?= $drp_delta ?></span>
                    <?php elseif($drp_delta > 0): ?>
                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1"><i class="bi bi-caret-up-fill me-1"></i>+<?= $drp_delta ?></span>
                    <?php else: ?>
                    <span class="badge bg-body-secondary text-muted px-2 py-1">0</span>
                    <?php endif; ?>
                  </td>

                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div>

    <!-- 5-Year Dropout & Repeater Longitudinal Trend Analysis -->
    <div class="row g-4 mb-4">
      <div class="col-12">
        <div class="glass-panel-aesthetic p-4" style="height: 450px; min-height: 450px;">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="chart-card-title mb-0">
              <i class="bi bi-graph-up me-2 text-primary-nhs"></i>5-Year Longitudinal Retention & Failure Trends
            </div>
            <span class="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill px-2 py-1 small fw-500" style="font-size: 0.68rem;">5-Year Trends</span>
          </div>
          <p class="chart-card-sub">Longitudinal comparison of Repeaters and Dropouts from S.Y. <?= htmlspecialchars($trend_sy_list[0] ?? '') ?> to S.Y. <?= htmlspecialchars(end($trend_sy_list) ?: '') ?></p>
          <div class="chart-wrapper" style="height: 340px;">
            <canvas id="longitudinalTrendChart"></canvas>
          </div>
        </div>
      </div>
    </div>

  </div>

  <!-- TAB PANE 3: Grade-Level Trends Analysis -->
  <div class="tab-pane fade <?= $trends_show ?>" id="trends-pane" role="tabpanel" aria-labelledby="trends-tab">
    
    <!-- Grade & School Year Selector - Glassmorphic Aesthetic Panel -->
    <div class="glass-panel-aesthetic p-4 mb-4">
      <div class="row align-items-center g-3">
        <div class="col-md-6">
          <h4 class="mb-1 text-primary fw-700 d-flex align-items-center gap-2">
            <i class="bi bi-graph-up-arrow"></i> Grade-Level Longitudinal Trends
          </h4>
          <p class="text-muted small mb-0">Select a grade level and school year below to analyze historical enrollees, dropouts, and repeaters instantly.</p>
        </div>
        <div class="col-md-3">
          <label class="form-label small fw-600 text-muted d-flex align-items-center gap-2 mb-1">
            <i class="bi bi-mortarboard text-primary"></i> Select Grade Level
          </label>
          <select id="trendGradeSelect" class="form-select border-0 shadow-sm px-3" style="height: 44px; border-radius: 10px;" onchange="updateTrendsDashboard()">
            <?php foreach($grades as $g): 
              $lvl_short = 'JHS';
              if ($g['level_type'] === 'Senior High') $lvl_short = 'SHS';
              elseif ($g['level_type'] === 'Kindergarten') $lvl_short = 'Kinder';
              elseif ($g['level_type'] === 'Elementary') $lvl_short = 'Elem';
            ?>
            <option value="<?=$g['id']?>"><?= htmlspecialchars($g['grade_name']) ?> (<?= $lvl_short ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label small fw-600 text-muted d-flex align-items-center gap-2 mb-1">
            <i class="bi bi-calendar-event text-primary"></i> Select School Year
          </label>
          <select id="trendSySelect" class="form-select border-0 shadow-sm px-3" style="height: 44px; border-radius: 10px;" onchange="updateTrendsDashboard()">
            <?php foreach(array_reverse($trend_sy_list) as $sy_item): ?>
            <option value="<?=$sy_item?>" <?=$sy_item===$selected_sy?'selected':''?>><?=$sy_item?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
    </div>

    <!-- Trend KPI Cards -->
    <div class="row g-3 mb-4">
      <!-- Enrollment KPI -->
      <div class="col-md-4">
        <div class="comp-card-aesthetic c-blue" style="border-radius: 16px;">
          <i class="bi bi-people-fill comp-bg-icon"></i>
          <div>
            <span class="comp-lbl d-flex align-items-center gap-2 small fw-600 text-muted">
              <i class="bi bi-person-badge text-primary-nhs"></i> Grade Enrollees
            </span>
            <div class="comp-val-group mt-2">
              <span class="comp-val-aesthetic" id="trendKpiEnroll">0</span>
              <span class="text-muted small ms-2">BOSY enrollees</span>
            </div>
          </div>
          <div class="mt-3 d-flex align-items-center justify-content-between flex-wrap gap-2 pt-2 border-top border-light border-opacity-10">
            <p class="comp-sub-lbl mb-0 max-w-70" id="trendEnrollSub">Loading...</p>
            <span class="badge-aesthetic" id="trendEnrollBadge">Loading...</span>
          </div>
        </div>
      </div>

      <!-- Dropouts KPI -->
      <div class="col-md-4">
        <div class="comp-card-aesthetic c-red" style="border-radius: 16px;">
          <i class="bi bi-person-x-fill comp-bg-icon"></i>
          <div>
            <span class="comp-lbl d-flex align-items-center gap-2 small fw-600 text-muted">
              <i class="bi bi-x-circle text-danger"></i> Grade Dropouts
            </span>
            <div class="comp-val-group mt-2">
              <span class="comp-val-aesthetic text-danger" id="trendKpiDropouts">0</span>
              <span class="text-muted small ms-2">students</span>
            </div>
          </div>
          <div class="mt-3 d-flex align-items-center justify-content-between flex-wrap gap-2 pt-2 border-top border-light border-opacity-10">
            <p class="comp-sub-lbl mb-0 max-w-70" id="trendDropoutsSub">Loading...</p>
            <span class="badge-aesthetic" id="trendDropoutsBadge">Loading...</span>
          </div>
        </div>
      </div>

      <!-- Repeaters KPI -->
      <div class="col-md-4">
        <div class="comp-card-aesthetic c-gold" style="border-radius: 16px;">
          <i class="bi bi-arrow-counterclockwise comp-bg-icon"></i>
          <div>
            <span class="comp-lbl d-flex align-items-center gap-2 small fw-600 text-muted">
              <i class="bi bi-arrow-repeat text-warning"></i> Grade Repeaters
            </span>
            <div class="comp-val-group mt-2">
              <span class="comp-val-aesthetic text-warning" id="trendKpiRepeaters">0</span>
              <span class="text-muted small ms-2">students</span>
            </div>
          </div>
          <div class="mt-3 d-flex align-items-center justify-content-between flex-wrap gap-2 pt-2 border-top border-light border-opacity-10">
            <p class="comp-sub-lbl mb-0 max-w-70" id="trendRepeatersSub">Loading...</p>
            <span class="badge-aesthetic" id="trendRepeatersBadge">Loading...</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Charts Row -->
    <div class="row g-4 mb-4">
      <!-- Left Chart: BOSY Enrollment -->
      <div class="col-lg-7">
        <div class="glass-panel-aesthetic p-4" style="height: 450px; min-height: 450px;">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="chart-card-title mb-0"><i class="bi bi-graph-up me-2 text-primary-nhs"></i>Enrollment (BOSY) 5-Year Trend</div>
            <span class="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill px-2 py-1 small fw-500" style="font-size: 0.68rem;">Enrollment Trend</span>
          </div>
          <div class="chart-wrapper mt-3" style="height: 350px;">
            <canvas id="gradeEnrollChart"></canvas>
          </div>
        </div>
      </div>

      <!-- Right Chart: Dropouts & Repeaters -->
      <div class="col-lg-5">
        <div class="glass-panel-aesthetic p-4" style="height: 450px; min-height: 450px;">
          <div class="d-flex align-items-center justify-content-between mb-2">
            <div class="chart-card-title mb-0"><i class="bi bi-exclamation-triangle me-2 text-warning"></i>Dropouts & Repeaters 5-Year Trend</div>
            <span class="badge bg-warning-subtle text-warning border border-warning-subtle rounded-pill px-2 py-1 small fw-500" style="font-size: 0.68rem;">Failure Trends</span>
          </div>
          <div class="chart-wrapper mt-3" style="height: 350px;">
            <canvas id="gradeFailureChart"></canvas>
          </div>
        </div>
      </div>
    </div>

    <!-- Trends Detailed Data Grid Table -->
    <div class="row g-4 mb-4">
      <div class="col-12">
        <div class="glass-panel-aesthetic">
          <div class="data-card-header bg-transparent border-0 px-4 pt-4 pb-2">
            <span class="data-card-title mb-0"><i class="bi bi-table me-2 text-primary-nhs"></i>Historical Year-over-Year Data Grid</span>
          </div>
          <div class="table-responsive p-3">
            <table class="comp-table-aesthetic">
              <thead>
                <tr>
                  <th>School Year</th>
                  <th>BOSY Enrollment</th>
                  <th>Enrollment YoY</th>
                  <th>Dropouts Count</th>
                  <th>Dropout Rate (%)</th>
                  <th>Repeaters Count</th>
                  <th>Repeater Rate (%)</th>
                </tr>
              </thead>
              <tbody id="trendsTableBody">
                <!-- Injected dynamically by JS -->
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

  </div>

</div>

<!-- ADD/EDIT RECORD MODAL (Original CRUD component preserved exactly) -->
<?php if(has_role('Admin','Encoder')): ?>
<div class="modal fade" id="enrollModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="enrollModalTitle"><i class="bi bi-plus-circle me-2"></i>Add Enrollment Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form id="enrollForm" onsubmit="submitEnroll(event)">
        <div class="modal-body">
          <input type="hidden" id="enrollId" name="id">
          <input type="hidden" name="action" id="enrollAction" value="add">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Grade Level *</label>
              <select name="grade_level_id" id="fGrade" class="form-select" required onchange="toggleStrand()">
                <?php foreach($grades as $g): 
                  $lvl_short = 'JHS';
                  if ($g['level_type'] === 'Senior High') $lvl_short = 'SHS';
                  elseif ($g['level_type'] === 'Kindergarten') $lvl_short = 'Kinder';
                  elseif ($g['level_type'] === 'Elementary') $lvl_short = 'Elem';
                ?>
                <option value="<?=$g['id']?>" data-type="<?=$g['level_type']?>"><?= htmlspecialchars($g['grade_name']) ?> (<?= $lvl_short ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6" id="strandRow">
              <label class="form-label">Strand <span class="text-muted">(SHS only)</span></label>
              <select name="strand_id" id="fStrand" class="form-select">
                <option value="">— None / JHS —</option>
                <?php foreach($strands as $st): ?>
                <option value="<?=$st['id']?>"><?= htmlspecialchars($st['strand_code'].' — '.$st['strand_name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Semester *</label>
              <select name="semester" id="fSemester" class="form-select">
                <option value="Full Year">Full Year (Basic Ed)</option>
                <option value="1st Sem">1st Semester</option>
                <option value="2nd Sem">2nd Semester</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">BOSY Enrollment *</label>
              <input type="number" name="bosy_enrollment" id="fEnroll" class="form-control" min="0" required>
            </div>
            <div class="col-md-4">
              <label class="form-label">School Year *</label>
              <select name="school_year" id="fSY" class="form-select" required>
                <?php foreach($sy_list as $sy): ?>
                <option value="<?=$sy?>" <?=$sy===$selected_sy?'selected':''?>><?=$sy?></option>
                <?php endforeach; ?>
                <option value="new">+ Add New S.Y.</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Repeaters</label>
              <input type="number" name="repeaters_count" id="fRep" class="form-control" min="0" value="0">
            </div>
            <div class="col-md-6">
              <label class="form-label">Dropouts</label>
              <input type="number" name="dropouts_count" id="fDrop" class="form-control" min="0" value="0">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn-primary-nhs"><i class="bi bi-save me-1"></i>Save Record</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
// Search function filter event
document.getElementById('searchInput').addEventListener('input', function(){
  const q = this.value.toLowerCase();
  document.querySelectorAll('#enrollTable tbody tr').forEach(tr => {
    tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
});

function toggleStrand(){
  const sel = document.getElementById('fGrade');
  if(!sel) return;
  const type = sel.options[sel.selectedIndex]?.dataset.type;
  const sRow = document.getElementById('strandRow');
  const semSel = document.getElementById('fSemester');
  if(type === 'Senior High'){
    sRow.style.display='';
    semSel.value='1st Sem';
  } else {
    sRow.style.display='none';
    document.getElementById('fStrand').value='';
    semSel.value='Full Year';
  }
}
toggleStrand();

function editEnroll(row){
  document.getElementById('enrollModalTitle').innerHTML='<i class="bi bi-pencil me-2"></i>Edit Enrollment Record';
  document.getElementById('enrollAction').value='edit';
  document.getElementById('enrollId').value=row.id;
  document.getElementById('fGrade').value=row.grade_level_id;
  document.getElementById('fStrand').value=row.strand_id||'';
  document.getElementById('fSemester').value=row.semester;
  document.getElementById('fEnroll').value=row.bosy_enrollment;
  document.getElementById('fSY').value=row.school_year;
  document.getElementById('fRep').value=row.repeaters;
  document.getElementById('fDrop').value=row.dropouts;
  toggleStrand();
  new bootstrap.Modal(document.getElementById('enrollModal')).show();
}

async function submitEnroll(e){
  e.preventDefault();
  const fd=new FormData(e.target);
  const data=Object.fromEntries(fd);
  showSpinner();
  try{
    const r=await fetch('ajax/enrollment_crud.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    const res=await r.json();
    hideSpinner();
    if(res.success){
      toastSuccess(res.message);
      bootstrap.Modal.getInstance(document.getElementById('enrollModal'))?.hide();
      setTimeout(()=>location.reload(),800);
    } else toastError(res.message||'Error occurred');
  } catch(err){ hideSpinner(); toastError('Request failed'); }
}

function deleteRecord(id, table, label){
  confirmAction(`Are you sure you want to delete this ${label} record? This will affect historical reports.`)
    .then(r=>{
      if(!r.isConfirmed) return;
      showSpinner();
      fetch('ajax/delete_record.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,table})})
        .then(r=>r.json()).then(res=>{
          hideSpinner();
          if(res.success){toastSuccess(res.message);setTimeout(()=>location.reload(),800);}
          else toastError(res.message);
        }).catch(()=>{hideSpinner();toastError('Request failed');});
    });
}

// --- Year-to-Year Chart.js Rendering ---
document.addEventListener("DOMContentLoaded", function() {
  const chartCanvas = document.getElementById('syComparisonChart');
  if (!chartCanvas) return;

  const ctx = chartCanvas.getContext('2d');
  
  function getThemeColors() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    return {
      baseColor: isDark ? '#6B9BE8' : '#1B2A6B',
      targetColor: isDark ? '#F0CA76' : '#C9A227',
      repeatersColor: isDark ? '#F0CA76' : '#C9A227',
      repeatersGlow: isDark ? 'rgba(240, 202, 118, 0.15)' : 'rgba(201, 162, 39, 0.1)',
      dropoutsColor: isDark ? '#F5A0A0' : '#8B1A1A',
      dropoutsGlow: isDark ? 'rgba(245, 160, 160, 0.15)' : 'rgba(139, 26, 26, 0.1)',
      textColor: isDark ? '#8D96B8' : '#6B6880',
      gridColor: isDark ? '#343C60' : '#E8E2D4'
    };
  }

  let themeColors = getThemeColors();

  const syComparisonChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Total Enrollees', 'Total Repeaters', 'Total Dropouts'],
      datasets: [
        {
          label: 'Baseline S.Y. ' + <?= json_encode($comp_base) ?>,
          data: [
            <?= (int)$base_totals['enrollment'] ?>,
            <?= (int)$base_totals['repeaters'] ?>,
            <?= (int)$base_totals['dropouts'] ?>
          ],
          backgroundColor: themeColors.baseColor,
          borderRadius: 6,
          borderWidth: 0
        },
        {
          label: 'Compare S.Y. ' + <?= json_encode($comp_target) ?>,
          data: [
            <?= (int)$target_totals['enrollment'] ?>,
            <?= (int)$target_totals['repeaters'] ?>,
            <?= (int)$target_totals['dropouts'] ?>
          ],
          backgroundColor: themeColors.targetColor,
          borderRadius: 6,
          borderWidth: 0
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: themeColors.textColor,
            font: { family: 'Poppins', size: 12, weight: '500' }
          }
        },
        tooltip: {
          padding: 10,
          bodyFont: { family: 'Poppins' },
          titleFont: { family: 'Poppins', weight: '600' },
          callbacks: {
            label: function(context) {
              return ' ' + context.dataset.label + ': ' + context.raw.toLocaleString();
            }
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            color: themeColors.textColor,
            font: { family: 'Poppins', size: 11 }
          }
        },
        y: {
          grid: { color: themeColors.gridColor },
          ticks: {
            color: themeColors.textColor,
            font: { family: 'Poppins', size: 11 }
          }
        }
      }
    }
  });

  // --- 5-Year Longitudinal Trend Line Chart Rendering ---
  const ctxTrend = document.getElementById('longitudinalTrendChart');
  let longitudinalTrendChart = null;
  if (ctxTrend) {
    longitudinalTrendChart = new Chart(ctxTrend.getContext('2d'), {
      type: 'line',
      data: {
        labels: <?= json_encode($trend_sy_list) ?>,
        datasets: [
          {
            label: 'Total Repeaters',
            data: <?= json_encode($trend_rep_data) ?>,
            borderColor: themeColors.repeatersColor,
            backgroundColor: themeColors.repeatersGlow,
            borderWidth: 4.5,
            tension: 0,
            fill: false,
            pointStyle: 'triangle',
            pointBackgroundColor: themeColors.repeatersColor,
            pointBorderColor: '#ffffff',
            pointBorderWidth: 2,
            pointRadius: 7,
            pointHoverRadius: 10
          },
          {
            label: 'Total Dropouts',
            data: <?= json_encode($trend_drp_data) ?>,
            borderColor: themeColors.dropoutsColor,
            backgroundColor: themeColors.dropoutsGlow,
            borderWidth: 4.5,
            tension: 0,
            fill: false,
            pointStyle: 'circle',
            pointBackgroundColor: themeColors.dropoutsColor,
            pointBorderColor: '#ffffff',
            pointBorderWidth: 2,
            pointRadius: 6,
            pointHoverRadius: 9
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            labels: {
              usePointStyle: true,
              color: themeColors.textColor,
              font: { family: 'Poppins', size: 12, weight: '500' }
            }
          },
          tooltip: {
            padding: 10,
            bodyFont: { family: 'Poppins' },
            titleFont: { family: 'Poppins', weight: '600' },
            callbacks: {
              label: function(context) {
                return ' ' + context.dataset.label + ': ' + context.raw.toLocaleString();
              }
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: {
              color: themeColors.textColor,
              font: { family: 'Poppins', size: 11 }
            }
          },
          y: {
            grid: { color: themeColors.gridColor },
            ticks: {
              color: themeColors.textColor,
              font: { family: 'Poppins', size: 11 }
            }
          }
        }
      },
      plugins: [{
        id: 'valueLabels',
        afterDatasetsDraw(chart, args, options) {
          const { ctx } = chart;
          ctx.save();
          ctx.font = 'bold 11px Poppins';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'bottom';
          
          // Subtle text shadow for high readability on any background
          const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
          ctx.shadowColor = isDark ? 'rgba(0, 0, 0, 0.9)' : 'rgba(255, 255, 255, 0.9)';
          ctx.shadowBlur = 5;
          ctx.shadowOffsetX = 0;
          ctx.shadowOffsetY = 0;

          chart.data.datasets.forEach((dataset, datasetIndex) => {
            const meta = chart.getDatasetMeta(datasetIndex);
            meta.data.forEach((element, index) => {
              const { x, y } = element;
              const val = dataset.data[index];
              if (val !== undefined && val !== null) {
                ctx.fillStyle = dataset.borderColor;
                
                // Slight y-offset adjustment to handle overlapping points beautifully
                let yOffset = -8;
                if (datasetIndex === 0) { // Repeaters (Triangle point is taller)
                  yOffset = -12;
                }
                
                ctx.fillText(val.toLocaleString(), x, y + yOffset);
              }
            });
          });
          ctx.restore();
        }
      }]
    });
  }
  // --- Grade-Level Trends Dashboard Interactivity ---
  const gradeTrendsData = <?= json_encode($grade_trends_data) ?>;
  let enrollChartInstance = null;
  let failureChartInstance = null;
  window.updateTrendsDashboard = function() {
    const gradeSelect = document.getElementById('trendGradeSelect');
    if (!gradeSelect) return;
    const gradeId = gradeSelect.value;
    const data = gradeTrendsData[gradeId];
    if (!data) return;
    
    const len = data.years.length;

    // --- 1. Populate Table Grid (First, before any chart rendering to guarantee table is loaded) ---
    try {
      let tableHtml = '';
      for (let i = 0; i < len; i++) {
        const year = data.years[i];
        const enr = data.enrollment[i] || 0;
        const drp = data.dropouts[i] || 0;
        const rep = data.repeaters[i] || 0;
        
        let enrYoY = '—';
        if (i > 0 && data.enrollment[i-1] > 0) {
          const diff = enr - data.enrollment[i-1];
          const pct = ((diff / data.enrollment[i-1]) * 100).toFixed(1);
          enrYoY = diff > 0 ? `<span class="text-success fw-600"><i class="bi bi-caret-up-fill me-1"></i>+${pct}%</span>` : 
                   (diff < 0 ? `<span class="text-danger fw-600"><i class="bi bi-caret-down-fill me-1"></i>${pct}%</span>` : `<span class="text-muted">0.0%</span>`);
        }
        
        const drRate = enr > 0 ? ((drp / enr) * 100).toFixed(1) : 0;
        const rrRate = enr > 0 ? ((rep / enr) * 100).toFixed(1) : 0;
        
        const drStatus = drRate > 10 ? 'badge-danger' : (drRate > 3 ? 'badge-warn' : 'badge-good');
        const rrStatus = rrRate > 8 ? 'badge-danger' : (rrRate > 3 ? 'badge-warn' : 'badge-good');
        
        tableHtml += `
          <tr>
            <td class="fw-700">${year}</td>
            <td class="fw-700">${enr.toLocaleString()}</td>
            <td>${enrYoY}</td>
            <td class="fw-600">${drp.toLocaleString()}</td>
            <td><span class="kpi-badge ${drStatus}">${drRate}%</span></td>
            <td class="fw-600">${rep.toLocaleString()}</td>
            <td><span class="kpi-badge ${rrStatus}">${rrRate}%</span></td>
          </tr>
        `;
      }
      const tBody = document.getElementById('trendsTableBody');
      if (tBody) tBody.innerHTML = tableHtml;
    } catch (tableErr) {
      console.error("Error populating table grid:", tableErr);
    }
    
    // --- 2. Update KPI Values (based on the selected School Year dropdown) ---
    try {
      const sySelect = document.getElementById('trendSySelect');
      const selectedSy = sySelect ? sySelect.value : <?= json_encode($selected_sy) ?>;
      const currIndex = data.years.indexOf(selectedSy);
      
      // Fallback to the latest year if the selected S.Y. is not found in the 5-year range
      const targetIndex = (currIndex !== -1) ? currIndex : data.years.length - 1;
      
      const currEnroll = data.enrollment[targetIndex] || 0;
      const currDropouts = data.dropouts[targetIndex] || 0;
      const currRepeaters = data.repeaters[targetIndex] || 0;
      
      const prevEnroll = (targetIndex > 0) ? data.enrollment[targetIndex - 1] : 0;
      const prevDropouts = (targetIndex > 0) ? data.dropouts[targetIndex - 1] : 0;
      const prevRepeaters = (targetIndex > 0) ? data.repeaters[targetIndex - 1] : 0;
      
      const kpiEnrollEl = document.getElementById('trendKpiEnroll');
      if (kpiEnrollEl) kpiEnrollEl.innerText = currEnroll.toLocaleString();
      const kpiDropEl = document.getElementById('trendKpiDropouts');
      if (kpiDropEl) kpiDropEl.innerText = currDropouts.toLocaleString();
      const kpiRepEl = document.getElementById('trendKpiRepeaters');
      if (kpiRepEl) kpiRepEl.innerText = currRepeaters.toLocaleString();
      
      // Helper to format YoY changes in KPI cards
      function formatYoY(curr, prev, labelId, badgeId, isGoodLower) {
        const diff = curr - prev;
        const pct = prev > 0 ? ((diff / prev) * 100).toFixed(1) : 0;
        const lblEl = document.getElementById(labelId);
        const badgeEl = document.getElementById(badgeId);
        
        if (!lblEl || !badgeEl) return;
        
        let text = '';
        if (diff > 0) {
          text = `Increased by <strong>${diff.toLocaleString()}</strong> vs last year`;
          badgeEl.className = isGoodLower ? 'badge-aesthetic bad' : 'badge-aesthetic good';
          badgeEl.innerHTML = `<i class="bi bi-arrow-up-right-circle-fill"></i> +${pct}%`;
        } else if (diff < 0) {
          text = `Decreased by <strong>${Math.abs(diff).toLocaleString()}</strong> vs last year`;
          badgeEl.className = isGoodLower ? 'badge-aesthetic good' : 'badge-aesthetic bad';
          badgeEl.innerHTML = `<i class="bi bi-arrow-down-left-circle-fill"></i> ${pct}%`;
        } else {
          text = `No change vs last year`;
          badgeEl.className = 'badge-aesthetic neutral';
          badgeEl.innerHTML = `No change`;
        }
        lblEl.innerHTML = text;
      }
      
      formatYoY(currEnroll, prevEnroll, 'trendEnrollSub', 'trendEnrollBadge', false);
      formatYoY(currDropouts, prevDropouts, 'trendDropoutsSub', 'trendDropoutsBadge', true);
      formatYoY(currRepeaters, prevRepeaters, 'trendRepeatersSub', 'trendRepeatersBadge', true);
    } catch (kpiErr) {
      console.error("Error updating KPIs:", kpiErr);
    }
    
    // --- 3. Draw or Update Enrollment Chart ---
    try {
      const freshColors = getThemeColors();
      if (enrollChartInstance) {
        enrollChartInstance.data.labels = data.years;
        enrollChartInstance.data.datasets[0].data = data.enrollment;
        enrollChartInstance.data.datasets[0].borderColor = freshColors.baseColor;
        enrollChartInstance.data.datasets[0].backgroundColor = freshColors.baseColor + '20';
        enrollChartInstance.update();
      } else {
        const ctxEnr = document.getElementById('gradeEnrollChart');
        if (ctxEnr) {
          enrollChartInstance = new Chart(ctxEnr.getContext('2d'), {
            type: 'line',
            data: {
              labels: data.years,
              datasets: [{
                label: 'BOSY Enrollment',
                data: data.enrollment,
                borderColor: freshColors.baseColor,
                backgroundColor: freshColors.baseColor + '15',
                fill: true,
                tension: 0.35,
                borderWidth: 4,
                pointRadius: 5,
                pointBackgroundColor: freshColors.baseColor,
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2
              }]
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: { display: false },
                tooltip: { padding: 10, bodyFont: { family: 'Poppins' } }
              },
              scales: {
                x: { grid: { display: false }, ticks: { color: freshColors.textColor, font: { family: 'Poppins' } } },
                y: { grid: { color: freshColors.gridColor }, ticks: { color: freshColors.textColor, font: { family: 'Poppins' } } }
              }
            },
            plugins: [{
              id: 'valueLabels',
              afterDatasetsDraw(chart, args, options) {
                const { ctx } = chart;
                ctx.save();
                ctx.font = 'bold 11px Poppins';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'bottom';
                const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
                ctx.shadowColor = isDark ? 'rgba(0, 0, 0, 0.9)' : 'rgba(255, 255, 255, 0.9)';
                ctx.shadowBlur = 4;
                chart.data.datasets.forEach((dataset, datasetIndex) => {
                  const meta = chart.getDatasetMeta(datasetIndex);
                  meta.data.forEach((element, index) => {
                    const { x, y } = element;
                    const val = dataset.data[index];
                    if (val !== undefined && val !== null) {
                      ctx.fillStyle = dataset.borderColor;
                      ctx.fillText(val.toLocaleString(), x, y - 8);
                    }
                  });
                });
                ctx.restore();
              }
            }]
          });
        }
      }
    } catch (chartEnrErr) {
      console.error("Error rendering enrollment chart:", chartEnrErr);
    }
    
    // --- 4. Draw or Update Failures Chart ---
    try {
      const freshColors = getThemeColors();
      if (failureChartInstance) {
        failureChartInstance.data.labels = data.years;
        failureChartInstance.data.datasets[0].data = data.repeaters;
        failureChartInstance.data.datasets[0].borderColor = freshColors.repeatersColor;
        failureChartInstance.data.datasets[0].pointBackgroundColor = freshColors.repeatersColor;
        failureChartInstance.data.datasets[1].data = data.dropouts;
        failureChartInstance.data.datasets[1].borderColor = freshColors.dropoutsColor;
        failureChartInstance.data.datasets[1].pointBackgroundColor = freshColors.dropoutsColor;
        failureChartInstance.update();
      } else {
        const ctxFail = document.getElementById('gradeFailureChart');
        if (ctxFail) {
          failureChartInstance = new Chart(ctxFail.getContext('2d'), {
            type: 'line',
            data: {
              labels: data.years,
              datasets: [
                {
                  label: 'Repeaters',
                  data: data.repeaters,
                  borderColor: freshColors.repeatersColor,
                  backgroundColor: freshColors.repeatersColor + '10',
                  fill: false,
                  tension: 0.3,
                  borderWidth: 3.5,
                  pointRadius: 6,
                  pointStyle: 'triangle',
                  pointBackgroundColor: freshColors.repeatersColor,
                  pointBorderColor: '#ffffff',
                  pointBorderWidth: 2
                },
                {
                  label: 'Dropouts',
                  data: data.dropouts,
                  borderColor: freshColors.dropoutsColor,
                  backgroundColor: freshColors.dropoutsColor + '10',
                  fill: false,
                  tension: 0.3,
                  borderWidth: 3.5,
                  pointRadius: 5,
                  pointStyle: 'circle',
                  pointBackgroundColor: freshColors.dropoutsColor,
                  pointBorderColor: '#ffffff',
                  pointBorderWidth: 2
                }
              ]
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: {
                  position: 'top',
                  labels: {
                    usePointStyle: true,
                    color: freshColors.textColor,
                    font: { family: 'Poppins', size: 11, weight: '500' }
                  }
                },
                tooltip: { padding: 10, bodyFont: { family: 'Poppins' } }
              },
              scales: {
                x: { grid: { display: false }, ticks: { color: freshColors.textColor, font: { family: 'Poppins' } } },
                y: { grid: { color: freshColors.gridColor }, ticks: { color: freshColors.textColor, font: { family: 'Poppins' } } }
              }
            },
            plugins: [{
              id: 'valueLabels',
              afterDatasetsDraw(chart, args, options) {
                const { ctx } = chart;
                ctx.save();
                ctx.font = 'bold 11px Poppins';
                ctx.textAlign = 'center';
                const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
                ctx.shadowColor = isDark ? 'rgba(0, 0, 0, 0.9)' : 'rgba(255, 255, 255, 0.9)';
                ctx.shadowBlur = 4;
                chart.data.datasets.forEach((dataset, datasetIndex) => {
                  const meta = chart.getDatasetMeta(datasetIndex);
                  meta.data.forEach((element, index) => {
                    const { x, y } = element;
                    const val = dataset.data[index];
                    if (val !== undefined && val !== null) {
                      ctx.fillStyle = dataset.borderColor;
                      if (datasetIndex === 0) { // Repeaters
                        ctx.textBaseline = 'bottom';
                        ctx.fillText(val.toLocaleString(), x, y - 10);
                      } else { // Dropouts
                        ctx.textBaseline = 'top';
                        ctx.fillText(val.toLocaleString(), x, y + 8);
                      }
                    }
                  });
                });
                ctx.restore();
              }
            }]
          });
        }
      }
    } catch (chartFailErr) {
      console.error("Error rendering failures chart:", chartFailErr);
    }
  };

  // Initial load
  updateTrendsDashboard();

  // Watch for theme toggles to dynamically update the chart
  const themeObserver = new MutationObserver(function() {
    const freshColors = getThemeColors();
    
    syComparisonChart.data.datasets[0].backgroundColor = freshColors.baseColor;
    syComparisonChart.data.datasets[1].backgroundColor = freshColors.targetColor;
    
    syComparisonChart.options.plugins.legend.labels.color = freshColors.textColor;
    syComparisonChart.options.scales.x.ticks.color = freshColors.textColor;
    syComparisonChart.options.scales.y.ticks.color = freshColors.textColor;
    syComparisonChart.options.scales.y.grid.color = freshColors.gridColor;
    
    syComparisonChart.update();
 
    if (enrollChartInstance) {
      enrollChartInstance.data.datasets[0].borderColor = freshColors.baseColor;
      enrollChartInstance.data.datasets[0].backgroundColor = freshColors.baseColor + '15';
      enrollChartInstance.options.scales.x.ticks.color = freshColors.textColor;
      enrollChartInstance.options.scales.y.ticks.color = freshColors.textColor;
      enrollChartInstance.options.scales.y.grid.color = freshColors.gridColor;
      enrollChartInstance.update();
    }
 
    if (failureChartInstance) {
      failureChartInstance.data.datasets[0].borderColor = freshColors.repeatersColor;
      failureChartInstance.data.datasets[0].pointBackgroundColor = freshColors.repeatersColor;
      failureChartInstance.data.datasets[1].borderColor = freshColors.dropoutsColor;
      failureChartInstance.data.datasets[1].pointBackgroundColor = freshColors.dropoutsColor;
      failureChartInstance.options.scales.x.ticks.color = freshColors.textColor;
      failureChartInstance.options.scales.y.ticks.color = freshColors.textColor;
      failureChartInstance.options.scales.y.grid.color = freshColors.gridColor;
      failureChartInstance.update();
    }

    if (longitudinalTrendChart) {
      longitudinalTrendChart.data.datasets[0].borderColor = freshColors.repeatersColor;
      longitudinalTrendChart.data.datasets[0].backgroundColor = freshColors.repeatersGlow;
      longitudinalTrendChart.data.datasets[0].pointBackgroundColor = freshColors.repeatersColor;
      longitudinalTrendChart.data.datasets[1].borderColor = freshColors.dropoutsColor;
      longitudinalTrendChart.data.datasets[1].backgroundColor = freshColors.dropoutsGlow;
      longitudinalTrendChart.data.datasets[1].pointBackgroundColor = freshColors.dropoutsColor;
      
      longitudinalTrendChart.options.plugins.legend.labels.color = freshColors.textColor;
      longitudinalTrendChart.options.scales.x.ticks.color = freshColors.textColor;
      longitudinalTrendChart.options.scales.y.ticks.color = freshColors.textColor;
      longitudinalTrendChart.options.scales.y.grid.color = freshColors.gridColor;
      longitudinalTrendChart.update();
    }
  });
  
  themeObserver.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['data-theme']
  });
});

function confirmDeleteSchoolYear(sy) {
  Swal.fire({
    title: 'Delete School Year ' + sy + '?',
    html: 'This will <strong class="text-danger">permanently delete ALL</strong> enrollees, repeaters, dropouts, seats, and teacher records for <strong>S.Y. ' + sy + '</strong>.<br><br>To confirm this destructive action, please type the school year <strong>' + sy + '</strong> below:',
    input: 'text',
    inputPlaceholder: sy,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: '<i class="bi bi-trash3-fill me-1"></i> Delete School Year',
    confirmButtonColor: '#dc2626',
    cancelButtonColor: '#6c757d',
    preConfirm: (inputValue) => {
      if (inputValue !== sy) {
        Swal.showValidationMessage('The input does not match ' + sy + '!');
        return false;
      }
      return inputValue;
    }
  }).then((result) => {
    if (result.isConfirmed) {
      showSpinner();
      fetch('ajax/delete_school_year.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ school_year: sy })
      })
      .then(response => response.json())
      .then(res => {
        hideSpinner();
        if (res.success) {
          toastSuccess(res.message);
          setTimeout(() => {
            window.location.href = 'enrollment.php';
          }, 1500);
        } else {
          toastError(res.message || 'Error occurred');
        }
      })
      .catch(() => {
        hideSpinner();
        toastError('Server request failed.');
      });
    }
  });
}
</script>
<?php include 'includes/footer.php'; ?>
