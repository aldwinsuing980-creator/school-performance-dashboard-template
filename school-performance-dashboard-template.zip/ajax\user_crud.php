<?php
// ajax/user_crud.php
require_once __DIR__ . '/../config/session.php';
require_login();

// Restrict strictly to Admin role
if (!has_role('Admin')) {
    json_response(['success' => false, 'message' => 'Access denied.'], 403);
}

$data   = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';
$id     = (int)($data['id'] ?? 0);

if (!$id || !$action) {
    json_response(['success' => false, 'message' => 'Missing required fields.'], 400);
}

try {
    // 1. Verify user exists
    $stmt = $pdo->prepare("SELECT username, full_name, role FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        json_response(['success' => false, 'message' => 'User account not found.'], 404);
    }

    if ($action === 'update_role') {
        $new_role = clean($data['role'] ?? '');
        if (!in_array($new_role, ['Admin', 'Faculty', 'Student', 'Encoder', 'Viewer'], true)) {
            json_response(['success' => false, 'message' => 'Invalid role specified.'], 400);
        }

        // Prevent self-demotion from Admin to ensure there's always an admin
        if ($id === current_user_id() && $new_role !== 'Admin') {
            json_response(['success' => false, 'message' => 'You cannot demote your own administrator account.'], 400);
        }

        $upd = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
        $upd->execute([$new_role, $id]);
        
        log_activity($pdo, current_user_id(), "Updated role of user '{$user['username']}' from '{$user['role']}' to '{$new_role}'", 'Users');
        json_response(['success' => true, 'message' => 'User role updated successfully.']);

    } elseif ($action === 'delete') {
        // Prevent deleting oneself
        if ($id === current_user_id()) {
            json_response(['success' => false, 'message' => 'You cannot delete your own logged-in administrator account.'], 400);
        }

        $del = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $del->execute([$id]);
        
        log_activity($pdo, current_user_id(), "Deleted user account '{$user['username']}' ({$user['full_name']})", 'Users');
        json_response(['success' => true, 'message' => 'User account deleted successfully.']);
    } else {
        json_response(['success' => false, 'message' => 'Unknown action: "' . $action . '"'], 400);
    }

} catch (PDOException $e) {
    json_response(['success' => false, 'message' => 'Database error: ' . $e->getMessage()], 500);
}
?>
