<?php
require_once __DIR__ . '/../config/session.php';
require_login();
if(!has_role('Admin')) json_response(['success'=>false,'message'=>'Access denied.'],403);

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
if(!$data) json_response(['success'=>false,'message'=>'Invalid payload.'],400);

$sy = trim($data['school_year'] ?? '');
if(!$sy) json_response(['success'=>false,'message'=>'School year is required.'],400);

// ── AUTO-MIGRATION: Ensure gender + semester columns exist ────
try {
    // Gender columns
    $cols = $pdo->query("SHOW COLUMNS FROM enrollment_data LIKE 'male_count'")->fetch();
    if(!$cols){
        $pdo->exec("ALTER TABLE enrollment_data ADD COLUMN male_count INT NOT NULL DEFAULT 0 AFTER bosy_enrollment, ADD COLUMN female_count INT NOT NULL DEFAULT 0 AFTER male_count");
        $pdo->exec("ALTER TABLE repeaters_data ADD COLUMN male_count INT NOT NULL DEFAULT 0 AFTER repeaters_count, ADD COLUMN female_count INT NOT NULL DEFAULT 0 AFTER male_count");
        $pdo->exec("ALTER TABLE dropouts_data ADD COLUMN male_count INT NOT NULL DEFAULT 0 AFTER dropouts_count, ADD COLUMN female_count INT NOT NULL DEFAULT 0 AFTER male_count");
    }
    // Semester column on repeaters_data
    $semCol = $pdo->query("SHOW COLUMNS FROM repeaters_data LIKE 'semester'")->fetch();
    if(!$semCol){
        $pdo->exec("ALTER TABLE repeaters_data ADD COLUMN semester ENUM('1st Sem','2nd Sem','Full Year') NOT NULL DEFAULT 'Full Year' AFTER strand_id");
    }
    // Semester column on dropouts_data
    $semCol2 = $pdo->query("SHOW COLUMNS FROM dropouts_data LIKE 'semester'")->fetch();
    if(!$semCol2){
        $pdo->exec("ALTER TABLE dropouts_data ADD COLUMN semester ENUM('1st Sem','2nd Sem','Full Year') NOT NULL DEFAULT 'Full Year' AFTER strand_id");
    }
} catch(Exception $e) { /* ignore if already exists */ }

$saved_count = 0;

try {
    $pdo->beginTransaction();

    // Flatten data from flat JSON keys
    $jhs=[]; $shs=[]; $shs_annual=[]; $tg=[]; $ta_jhs=[]; $ta_shs=[]; $seats=[];
    foreach($data as $k => $v){
        if(preg_match('/^jhs\[(\d+)\]\[(\w+)\]$/', $k, $m)) $jhs[$m[1]][$m[2]] = (int)$v;
        elseif(preg_match('/^shs\[(\d+)\]\[(\d+)\]\[(\w+)\]\[(\w+)\]$/', $k, $m)) $shs[$m[1]][$m[2]][$m[3]][$m[4]] = (int)$v;
        elseif(preg_match('/^shs_annual\[(\d+)\]\[(\w+)\]\[(\w+)\]$/', $k, $m)) $shs_annual[$m[1]][$m[2]][$m[3]] = (int)$v;
        elseif(preg_match('/^tg\[(\d+)\]$/', $k, $m)) $tg[$m[1]] = (int)$v;
        elseif(preg_match('/^ta_jhs\[(.+)\]$/', $k, $m)) $ta_jhs[$m[1]] = (int)$v;
        elseif(preg_match('/^ta_shs\[(.+)\]$/', $k, $m)) $ta_shs[$m[1]] = (int)$v;
        elseif(preg_match('/^seats\[(\d+)\]$/', $k, $m)) $seats[$m[1]] = (int)$v;
    }

    /**
     * Helper: Clean Upsert (Delete existing including duplicates, then Insert)
     * This ensures a clean state and no display redundancy.
     */
    $cleanUpsert = function($table, $keys, $values) use ($pdo) {
        $where = []; $params = [];
        foreach($keys as $k => $v){
            if($v === null){ $where[] = "`$k` IS NULL"; }
            else{ $where[] = "`$k`=?"; $params[] = $v; }
        }
        // 1. Delete ALL matching records to resolve duplicates
        $pdo->prepare("DELETE FROM `$table` WHERE " . implode(" AND ", $where))->execute($params);

        // 2. Insert the fresh record
        $cols = array_merge(array_keys($keys), array_keys($values));
        $vals = array_merge(array_values($keys), array_values($values));
        $q = array_fill(0, count($cols), "?");
        $pdo->prepare("INSERT INTO `$table` (" . implode(",", $cols) . ") VALUES(" . implode(",", $q) . ")")->execute($vals);
        return 1;
    };

    // PROCESS JHS ENROLLMENT
    foreach($jhs as $gid => $vals){
        $em=$vals['enroll_m']??0; $ef=$vals['enroll_f']??0; $te=$em+$ef;
        $rm=$vals['rep_m']??0;    $rf=$vals['rep_f']??0;    $tr=$rm+$rf;
        $dm=$vals['drop_m']??0;   $df=$vals['drop_f']??0;   $td=$dm+$df;
        
        $saved_count += $cleanUpsert('enrollment_data', 
            ['grade_level_id'=>$gid, 'strand_id'=>null, 'semester'=>'Full Year', 'school_year'=>$sy],
            ['bosy_enrollment'=>$te, 'male_count'=>$em, 'female_count'=>$ef]
        );
        $saved_count += $cleanUpsert('repeaters_data', 
            ['grade_level_id'=>$gid, 'strand_id'=>null, 'semester'=>'Full Year', 'school_year'=>$sy],
            ['repeaters_count'=>$tr, 'male_count'=>$rm, 'female_count'=>$rf]
        );
        $saved_count += $cleanUpsert('dropouts_data', 
            ['grade_level_id'=>$gid, 'strand_id'=>null, 'semester'=>'Full Year', 'school_year'=>$sy],
            ['dropouts_count'=>$td, 'male_count'=>$dm, 'female_count'=>$df]
        );
    }

    // PROCESS SHS ENROLLMENT
    foreach($shs as $gid => $strands_data){
        foreach($strands_data as $sid => $sems){
            // Enrollment per semester
            foreach(['s1'=>'1st Sem','s2'=>'2nd Sem'] as $sk => $slabel){
                if(!isset($sems[$sk])) continue;
                $d = $sems[$sk];
                $em=$d['enroll_m']??0; $ef=$d['enroll_f']??0; $te=$em+$ef;
                $saved_count += $cleanUpsert('enrollment_data', 
                    ['grade_level_id'=>$gid, 'strand_id'=>$sid, 'semester'=>$slabel, 'school_year'=>$sy],
                    ['bosy_enrollment'=>$te, 'male_count'=>$em, 'female_count'=>$ef]
                );
            }
        }
    }

    // PROCESS SHS GRADE-LEVEL SEMESTRAL SUMMARIES (Irregulars/Dropouts)
    foreach($shs_annual as $gid => $sems){
        foreach(['s1'=>'1st Sem','s2'=>'2nd Sem'] as $sk => $slabel){
            if(!isset($sems[$sk])) continue;
            $vals = $sems[$sk];
            $annual_rep = $vals['rep'] ?? 0;
            $annual_drop = $vals['drop'] ?? 0;
            
            $saved_count += $cleanUpsert('repeaters_data', 
                ['grade_level_id'=>$gid, 'strand_id'=>null, 'semester'=>$slabel, 'school_year'=>$sy],
                ['repeaters_count'=>$annual_rep, 'male_count'=>0, 'female_count'=>0]
            );
            $saved_count += $cleanUpsert('dropouts_data', 
                ['grade_level_id'=>$gid, 'strand_id'=>null, 'semester'=>$slabel, 'school_year'=>$sy],
                ['dropouts_count'=>$annual_drop, 'male_count'=>0, 'female_count'=>0]
            );
        }
    }

    // PROCESS TEACHERS
    foreach($tg as $gid => $cnt){
        $saved_count += $cleanUpsert('teachers_per_grade', ['grade_level_id'=>$gid, 'school_year'=>$sy], ['teacher_count'=>$cnt]);
    }
    foreach($ta_jhs as $area => $cnt){
        $saved_count += $cleanUpsert('teachers_per_area',
            ['learning_area'=>$area, 'level_type'=>'Junior High', 'school_year'=>$sy],
            ['teacher_count'=>$cnt, 'grade_level_covered'=>'Grade 7-10']
        );
    }
    foreach($ta_shs as $area => $cnt){
        $saved_count += $cleanUpsert('teachers_per_area',
            ['learning_area'=>$area, 'level_type'=>'Senior High', 'school_year'=>$sy],
            ['teacher_count'=>$cnt, 'grade_level_covered'=>'Grade 11-12']
        );
    }

    // PROCESS SEATS
    foreach($seats as $gid => $cnt){
        $saved_count += $cleanUpsert('seats_data', ['grade_level_id'=>$gid, 'strand_id'=>null, 'school_year'=>$sy], ['available_seats'=>$cnt]);
    }

    $pdo->commit();
    log_activity($pdo, current_user_id(), "Bulk data entry: {$saved_count} records saved for S.Y. {$sy}", 'Data Entry');
    json_response(['success'=>true, 'message'=>'Data saved successfully.', 'inserted'=>$saved_count]);

} catch(PDOException $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    json_response(['success'=>false, 'message'=>'Database error: '.$e->getMessage()], 500);
}

