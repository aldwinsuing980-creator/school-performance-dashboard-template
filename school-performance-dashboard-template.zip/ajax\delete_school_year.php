<?php
require_once __DIR__ . '/../config/session.php';
require_login();

// 1. Strict security role check: Only Admins can delete school years
if (!has_role('Admin')) {
    json_response(['success' => false, 'message' => 'Only Administrators can delete a School Year.'], 403);
}

$data = json_decode(file_get_contents('php://input'), true);
$school_year = trim($data['school_year'] ?? '');

// 2. Validate school year format (e.g. 2025-2026)
if (empty($school_year) || !preg_match('/^\d{4}-\d{4}$/', $school_year)) {
    json_response(['success' => false, 'message' => 'Invalid School Year format.'], 400);
}

try {
    $pdo->beginTransaction();

    // 3. Delete records from all related tables
    $tables = [
        'enrollment_data',
        'repeaters_data',
        'dropouts_data',
        'seats_data',
        'teachers_per_grade',
        'teachers_per_area'
    ];

    $deleted_counts = [];
    foreach ($tables as $table) {
        $stmt = $pdo->prepare("DELETE FROM `{$table}` WHERE school_year = ?");
        $stmt->execute([$school_year]);
        $deleted_counts[$table] = $stmt->rowCount();
    }

    $pdo->commit();

    // 4. Log audit log activity
    log_activity(
        $pdo, 
        current_user_id(), 
        "Deleted entire School Year: {$school_year} (Cleared records: " . json_encode($deleted_counts) . ")", 
        'Administrative'
    );

    json_response([
        'success' => true, 
        'message' => "School Year {$school_year} and all its associated data have been permanently deleted."
    ]);

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_response(['success' => false, 'message' => 'Database error: ' . $e->getMessage()], 500);
}
?>
