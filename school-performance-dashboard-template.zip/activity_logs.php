<?php
require_once __DIR__ . '/config/session.php';
require_login();
if(!has_role('Admin')) { header('Location: dashboard.php'); exit; }

$page_title = 'Activity Logs';
$breadcrumb = 'Activity Logs';

$per_page = 25;
$page_num = max(1, (int)($_GET['p'] ?? 1));
$offset   = ($page_num - 1) * $per_page;
$search   = clean($_GET['q'] ?? '');

$where = $search ? "WHERE al.action_description LIKE ? OR u.username LIKE ? OR al.module LIKE ?" : '';
$params = $search ? ["%$search%","%$search%","%$search%"] : [];

$count_q = $pdo->prepare("SELECT COUNT(*) FROM activity_logs al LEFT JOIN users u ON u.id=al.user_id $where");
$count_q->execute($params); $total = (int)$count_q->fetchColumn();
$total_pages = ceil($total / $per_page);

$logs_q = $pdo->prepare("
  SELECT al.*, u.username, u.full_name
  FROM activity_logs al
  LEFT JOIN users u ON u.id=al.user_id
  $where
  ORDER BY al.timestamp DESC
  LIMIT $per_page OFFSET $offset
");
$logs_q->execute($params);
$logs = $logs_q->fetchAll();

include 'includes/header.php';
?>
<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
  <div class="section-header mb-0">
    <h1 class="section-title"><i class="bi bi-clock-history me-2 text-primary-nhs"></i>Activity Logs</h1>
    <p class="section-sub">Audit trail — <?= number_format($total) ?> total entries</p>
  </div>
  <form method="GET" class="d-flex gap-2">
    <input type="text" name="q" class="form-control form-control-sm" placeholder="Search logs..." value="<?= htmlspecialchars($search) ?>" style="width:220px">
    <button type="submit" class="btn-primary-nhs py-1 px-3"><i class="bi bi-search"></i></button>
  </form>
</div>

<div class="data-card">
  <div class="data-card-header">
    <span class="data-card-title">System Audit Trail</span>
    <span class="text-muted small">Page <?= $page_num ?> of <?= $total_pages ?></span>
  </div>
  <div class="table-responsive">
    <table class="nhs-table">
      <thead>
        <tr><th>#</th><th>User</th><th>Module</th><th>Action</th><th>IP Address</th><th>Timestamp</th></tr>
      </thead>
      <tbody>
        <?php foreach($logs as $i=>$log): ?>
        <tr>
          <td class="text-muted"><?= ($offset+$i+1) ?></td>
          <td>
            <div class="fw-600"><?= htmlspecialchars($log['full_name']??'System') ?></div>
            <div class="text-muted small">@<?= htmlspecialchars($log['username']??'—') ?></div>
          </td>
          <td><span class="kpi-badge badge-info"><?= htmlspecialchars($log['module']??'—') ?></span></td>
          <td class="small"><?= htmlspecialchars($log['action_description']) ?></td>
          <td class="text-muted small"><?= htmlspecialchars($log['ip_address']??'—') ?></td>
          <td class="text-muted small"><?= date('M j, Y g:i A', strtotime($log['timestamp'])) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($logs)): ?>
        <tr><td colspan="6" class="text-center text-muted py-4">No logs found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <!-- Pagination -->
  <?php if($total_pages > 1): ?>
  <div class="p-3 d-flex justify-content-center">
    <nav>
      <ul class="pagination pagination-sm mb-0">
        <li class="page-item <?= $page_num<=1?'disabled':'' ?>">
          <a class="page-link" href="?p=<?= $page_num-1 ?>&q=<?= urlencode($search) ?>">‹</a>
        </li>
        <?php for($pg=max(1,$page_num-2);$pg<=min($total_pages,$page_num+2);$pg++): ?>
        <li class="page-item <?= $pg==$page_num?'active':'' ?>">
          <a class="page-link" href="?p=<?=$pg?>&q=<?= urlencode($search) ?>"><?=$pg?></a>
        </li>
        <?php endfor; ?>
        <li class="page-item <?= $page_num>=$total_pages?'disabled':'' ?>">
          <a class="page-link" href="?p=<?= $page_num+1 ?>&q=<?= urlencode($search) ?>">›</a>
        </li>
      </ul>
    </nav>
  </div>
  <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
