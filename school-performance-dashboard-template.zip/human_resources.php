<?php
require_once __DIR__ . '/config/session.php';
require_login();

// Restrict strictly to Admin and Faculty roles
if (!has_role('Admin', 'Faculty')) {
    $page_title = 'Access Denied';
    $breadcrumb = 'Access Denied';
    include 'includes/header.php';
    echo '<div class="d-flex align-items-center justify-content-center" style="min-height:50vh;">
      <div class="text-center">
        <div style="font-size:4rem;margin-bottom:1rem;">🔒</div>
        <h2 class="fw-700 text-dark mb-2">Access Denied</h2>
        <p class="text-muted mb-3">You do not have permission to view this page. This area is reserved for staff members.</p>
        <a href="dashboard.php" class="btn-primary-nhs"><i class="bi bi-arrow-left me-1"></i> Back to Dashboard</a>
      </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

$page_title = 'Human Resources';
$breadcrumb = 'Human Resources';

$sy_rows = $pdo->query("SELECT DISTINCT school_year FROM teachers_per_grade ORDER BY school_year DESC")->fetchAll();
$sy_list  = array_column($sy_rows, 'school_year');
$sel_sy   = $_GET['sy'] ?? ($sy_list[0] ?? '2025-2026');

$allowed_level_types = [];
if (has_kinder()) $allowed_level_types[] = 'Kindergarten';
if (has_elementary()) $allowed_level_types[] = 'Elementary';
if (has_jhs()) $allowed_level_types[] = 'Junior High';
if (has_shs()) $allowed_level_types[] = 'Senior High';
if (empty($allowed_level_types)) $allowed_level_types = ['Junior High', 'Senior High'];
$level_type_clause = "gl.level_type IN ('" . implode("','", $allowed_level_types) . "')";

$grades  = $pdo->query("SELECT * FROM grade_levels WHERE level_type IN ('" . implode("','", $allowed_level_types) . "') ORDER BY id")->fetchAll();
$jhs_grades = array_filter($grades, fn($g) => in_array($g['level_type'], ['Kindergarten', 'Elementary', 'Junior High']));

// Teachers per grade (JHS / Basic Ed)
$allowed_tg_levels = [];
if (has_kinder() || has_elementary() || has_jhs()) {
  $allowed_tg_levels[] = 'Kindergarten';
  $allowed_tg_levels[] = 'Elementary';
  $allowed_tg_levels[] = 'Junior High';
}
$tg_clause = empty($allowed_tg_levels) ? "0" : "gl.level_type IN ('" . implode("','", $allowed_tg_levels) . "')";

$tg_q = $pdo->prepare("
  SELECT tg.*, gl.grade_name, gl.level_type
  FROM teachers_per_grade tg
  JOIN grade_levels gl ON gl.id=tg.grade_level_id
  WHERE tg.school_year=? AND $tg_clause ORDER BY gl.id
");
$tg_q->execute([$sel_sy]);
$jhs_teachers = $tg_q->fetchAll();

// Teachers per area
$ta_q = $pdo->prepare("SELECT * FROM teachers_per_area WHERE school_year=? ORDER BY level_type, learning_area");
$ta_q->execute([$sel_sy]);
$area_teachers = $ta_q->fetchAll();
foreach ($area_teachers as &$ta) {
    if ($ta['learning_area'] === 'Araling Panlipunan') $ta['learning_area'] = 'Social Studies (Araling Panlipunan)';
    if ($ta['learning_area'] === 'ESP/Values') $ta['learning_area'] = 'Values Education (EsP)';
}
unset($ta);

// Standard: JHS 1:35, SHS 1:35
$enroll_q = $pdo->prepare("
  SELECT gl.level_type, 
         COALESCE(SUM(
           CASE
             WHEN gl.level_type='Senior High' THEN (CASE WHEN e.semester='1st Sem' THEN e.bosy_enrollment ELSE 0 END)
             ELSE e.bosy_enrollment
           END
         ),0) as enroll 
  FROM grade_levels gl 
  LEFT JOIN enrollment_data e ON e.grade_level_id=gl.id AND e.school_year=? 
  GROUP BY gl.level_type
");
$enroll_q->execute([$sel_sy]);
$enroll_by_type = [];
foreach($enroll_q->fetchAll() as $r) $enroll_by_type[$r['level_type']] = (int)$r['enroll'];

include 'includes/header.php';
?>
<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
  <div class="section-header mb-0">
    <h1 class="section-title"><i class="bi bi-people-fill me-2 text-primary-nhs"></i>Human Resources</h1>
    <p class="section-sub">Teacher staffing — S.Y. <?= htmlspecialchars($sel_sy) ?></p>
  </div>
</div>

<?php 
  $has_basic = has_jhs() || has_kinder() || has_elementary();
  $basic_tab_title = "JHS — Per Grade Level";
  if (!has_jhs() && (has_kinder() || has_elementary())) {
    $basic_tab_title = "Basic Ed — Per Grade Level";
  } else if (has_jhs() && (has_kinder() || has_elementary())) {
    $basic_tab_title = "Basic Ed & JHS";
  }
?>
<ul class="nav nav-pills mb-4">
  <?php if ($has_basic): ?>
  <li class="nav-item">
    <button class="nav-link active" data-bs-toggle="pill" data-bs-target="#jhsTab">
      <i class="bi bi-person-video2 me-1"></i><?= $basic_tab_title ?>
    </button>
  </li>
  <?php endif; ?>
  <?php if (has_shs()): ?>
  <li class="nav-item">
    <button class="nav-link <?= !$has_basic ? 'active' : '' ?>" data-bs-toggle="pill" data-bs-target="#shsTab">
      <i class="bi bi-book-fill me-1"></i>SHS — Per Learning Area
    </button>
  </li>
  <?php endif; ?>
</ul>

<div class="tab-content">
  <!-- JHS Tab -->
  <div class="tab-pane fade <?= $has_basic ? 'show active' : '' ?>" id="jhsTab">
    <div class="data-card">
      <div class="data-card-header">
        <span class="data-card-title"><?= !has_jhs() && (has_kinder() || has_elementary()) ? 'Basic Education' : 'Junior High School' ?> Teachers</span>
        <?php if(has_role('Admin')): ?>
        <button class="btn-primary-nhs" data-bs-toggle="modal" data-bs-target="#jhsTeacherModal" onclick="resetJHSForm()">
          <i class="bi bi-plus-circle"></i> Add Record
        </button>
        <?php endif; ?>
      </div>
      <div class="table-responsive">
        <table class="nhs-table">
          <thead>
            <tr><th>#</th><th>Grade Level</th><th>Teacher Count</th><th>Students Enrolled</th>
            <th>Ratio (1:N)</th><th>Standard</th><th>Status</th>
            <?php if(has_role('Admin')): ?><th>Actions</th><?php endif; ?></tr>
          </thead>
          <tbody>
            <?php foreach($jhs_teachers as $i=>$r):
              // Get enrollment for this grade
              $eq=$pdo->prepare("SELECT COALESCE(SUM(bosy_enrollment),0) FROM enrollment_data WHERE grade_level_id=? AND school_year=?");
              $eq->execute([$r['grade_level_id'],$sel_sy]);
              $g_enroll=(int)$eq->fetchColumn();
              $ratio = $r['teacher_count']>0 ? round($g_enroll/$r['teacher_count'],1) : 0;
              $status_cls = $ratio<=35?'badge-good':($ratio<=45?'badge-warn':'badge-danger');
              $status_t   = $ratio<=35?'🟢 Standard':($ratio<=45?'🟡 High':'🔴 Overloaded');
            ?>
            <tr>
              <td class="text-muted"><?= $i+1 ?></td>
              <td class="fw-600"><?= htmlspecialchars($r['grade_name']) ?></td>
              <td class="fw-600"><?= number_format($r['teacher_count']) ?></td>
              <td><?= number_format($g_enroll) ?></td>
              <td>1 : <?= $ratio ?></td>
              <td class="text-muted">1 : 35</td>
              <td><span class="kpi-badge <?= $status_cls ?>"><?= $status_t ?></span></td>
              <?php if(has_role('Admin')): ?>
              <td>
                <button class="btn btn-sm btn-outline-primary me-1" onclick='editJHSTeacher(<?= json_encode($r) ?>)'>
                  <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteRecord(<?= $r['id'] ?>,'teachers_per_grade','JHS Teacher')">
                  <i class="bi bi-trash"></i>
                </button>
              </td>
              <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            <?php if(empty($jhs_teachers)): ?>
            <tr><td colspan="8" class="text-center text-muted py-4">No records found</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- SHS Tab -->
  <div class="tab-pane fade <?= !$has_basic ? 'show active' : '' ?>" id="shsTab">
    <div class="data-card">
      <div class="data-card-header">
        <span class="data-card-title">Senior High School — Teachers per Learning Area (Grade 11–12)</span>
        <?php if(has_role('Admin')): ?>
        <button class="btn-primary-nhs" data-bs-toggle="modal" data-bs-target="#shsTeacherModal" onclick="resetSHSForm()">
          <i class="bi bi-plus-circle"></i> Add Record
        </button>
        <?php endif; ?>
      </div>
      <div class="table-responsive">
        <table class="nhs-table">
          <thead>
            <tr><th>#</th><th>Learning Area</th><th>Level Type</th><th>Grade Level Covered</th>
            <th>Teacher Count</th><th>Coverage Status</th>
            <?php if(has_role('Admin')): ?><th>Actions</th><?php endif; ?></tr>
          </thead>
          <tbody>
            <?php 
            $shs_index = 1;
            foreach($area_teachers as $i=>$r):
              if ($r['level_type'] === 'Junior High') continue;
              $status_cls = $r['teacher_count']>=2?'badge-good':($r['teacher_count']==1?'badge-warn':'badge-danger');
              $status_t   = $r['teacher_count']>=2?'🟢 Adequate':($r['teacher_count']==1?'🟡 Minimum':'🔴 Understaffed');
            ?>
            <tr>
              <td class="text-muted"><?= $shs_index++ ?></td>
              <td class="fw-600"><?= htmlspecialchars($r['learning_area']) ?></td>
              <td><span class="kpi-badge badge-primary"><?= htmlspecialchars($r['level_type']) ?></span></td>
              <td class="text-muted small"><?= htmlspecialchars($r['grade_level_covered']??'—') ?></td>
              <td class="fw-600"><?= number_format($r['teacher_count']) ?></td>
              <td><span class="kpi-badge <?= $status_cls ?>"><?= $status_t ?></span></td>
              <?php if(has_role('Admin')): ?>
              <td>
                <button class="btn btn-sm btn-outline-primary me-1" onclick='editAreaTeacher(<?= json_encode($r) ?>)'>
                  <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteRecord(<?= $r['id'] ?>,'teachers_per_area','Area Teacher')">
                  <i class="bi bi-trash"></i>
                </button>
              </td>
              <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            <?php if($shs_index === 1): ?>
            <tr><td colspan="7" class="text-center text-muted py-4">No SHS learning area records found</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- JHS Teacher Modal -->
<?php if(has_role('Admin')): ?>
<div class="modal fade" id="jhsTeacherModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="jhsModalTitle"><i class="bi bi-person-video2 me-2"></i>JHS Teacher Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form onsubmit="submitJHSTeacher(event)">
        <div class="modal-body">
          <input type="hidden" id="jhsId" name="id">
          <input type="hidden" name="action" id="jhsAction" value="add">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Grade Level *</label>
              <select name="grade_level_id" id="jhsGrade" class="form-select" required>
                <?php foreach($jhs_grades as $g): 
                  $lvl_short = 'JHS';
                  if ($g['level_type'] === 'Senior High') $lvl_short = 'SHS';
                  elseif ($g['level_type'] === 'Kindergarten') $lvl_short = 'Kinder';
                  elseif ($g['level_type'] === 'Elementary') $lvl_short = 'Elem';
                ?>
                <option value="<?=$g['id']?>"><?= htmlspecialchars($g['grade_name']) ?> (<?= $lvl_short ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-6">
              <label class="form-label">Teacher Count *</label>
              <input type="number" name="teacher_count" id="jhsCount" class="form-control" min="0" required>
            </div>
            <div class="col-6">
              <label class="form-label">School Year *</label>
              <select name="school_year" class="form-select">
                <?php foreach($sy_list as $sy): ?>
                <option value="<?=$sy?>" <?=$sy===$sel_sy?'selected':''?>><?=$sy?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn-primary-nhs"><i class="bi bi-save me-1"></i>Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- SHS / Area Teacher Modal -->
<div class="modal fade" id="shsTeacherModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="shsModalTitle"><i class="bi bi-book me-2"></i>Learning Area Teacher Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form onsubmit="submitAreaTeacher(event)">
        <div class="modal-body">
          <input type="hidden" id="shsId" name="id">
          <input type="hidden" name="action" id="shsAction" value="add">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Learning Area *</label>
              <input type="text" name="learning_area" id="shsArea" class="form-control" placeholder="e.g. Mathematics" required>
            </div>
            <div class="col-6">
              <label class="form-label">Level Type *</label>
              <select name="level_type" id="shsLvl" class="form-select">
                <option value="Junior High">Junior High</option>
                <option value="Senior High">Senior High</option>
                <option value="Both">Both</option>
              </select>
            </div>
            <div class="col-6">
              <label class="form-label">Teacher Count *</label>
              <input type="number" name="teacher_count" id="shsCount" class="form-control" min="0" required>
            </div>
            <div class="col-12">
              <label class="form-label">Grade Level Covered</label>
              <input type="text" name="grade_level_covered" id="shsCovered" class="form-control" placeholder="e.g. Grade 7-10">
            </div>
            <div class="col-12">
              <label class="form-label">School Year *</label>
              <select name="school_year" class="form-select">
                <?php foreach($sy_list as $sy): ?>
                <option value="<?=$sy?>" <?=$sy===$sel_sy?'selected':''?>><?=$sy?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn-primary-nhs"><i class="bi bi-save me-1"></i>Save</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
function resetJHSForm(){document.getElementById('jhsAction').value='add';document.getElementById('jhsId').value='';document.getElementById('jhsCount').value='';}
function editJHSTeacher(r){
  document.getElementById('jhsAction').value='edit';
  document.getElementById('jhsId').value=r.id;
  document.getElementById('jhsGrade').value=r.grade_level_id;
  document.getElementById('jhsCount').value=r.teacher_count;
  new bootstrap.Modal(document.getElementById('jhsTeacherModal')).show();
}
async function submitJHSTeacher(e){
  e.preventDefault();
  const data=Object.fromEntries(new FormData(e.target));
  showSpinner();
  const r=await fetch('ajax/teacher_crud.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...data,type:'jhs'})});
  const res=await r.json();hideSpinner();
  if(res.success){toastSuccess(res.message);bootstrap.Modal.getInstance(document.querySelector('.modal.show'))?.hide();setTimeout(()=>location.reload(),700);}
  else toastError(res.message);
}
function resetSHSForm(){document.getElementById('shsAction').value='add';document.getElementById('shsId').value='';['shsArea','shsCount','shsCovered'].forEach(id=>document.getElementById(id).value='');}
function editAreaTeacher(r){
  document.getElementById('shsAction').value='edit';
  document.getElementById('shsId').value=r.id;
  document.getElementById('shsArea').value=r.learning_area;
  document.getElementById('shsLvl').value=r.level_type;
  document.getElementById('shsCount').value=r.teacher_count;
  document.getElementById('shsCovered').value=r.grade_level_covered||'';
  new bootstrap.Modal(document.getElementById('shsTeacherModal')).show();
}
async function submitAreaTeacher(e){
  e.preventDefault();
  const data=Object.fromEntries(new FormData(e.target));
  showSpinner();
  const r=await fetch('ajax/teacher_crud.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...data,type:'area'})});
  const res=await r.json();hideSpinner();
  if(res.success){toastSuccess(res.message);bootstrap.Modal.getInstance(document.querySelector('.modal.show'))?.hide();setTimeout(()=>location.reload(),700);}
  else toastError(res.message);
}
function deleteRecord(id,table,label){
  confirmAction(`Delete this ${label} record? This affects historical reports.`).then(r=>{
    if(!r.isConfirmed)return;
    showSpinner();
    fetch('ajax/delete_record.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,table})})
      .then(r=>r.json()).then(res=>{hideSpinner();if(res.success){toastSuccess(res.message);setTimeout(()=>location.reload(),700);}else toastError(res.message);});
  });
}
</script>
<?php include 'includes/footer.php'; ?>
