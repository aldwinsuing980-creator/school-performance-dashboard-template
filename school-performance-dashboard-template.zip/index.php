<?php
require_once __DIR__ . '/config/session.php';
require_login();

$page_title = 'Dashboard';
$breadcrumb = 'Overview';

// ── School Year filter ───────────────────────────────────────
$sy_rows = $pdo->query("SELECT DISTINCT school_year FROM enrollment_data ORDER BY school_year DESC")->fetchAll();
$sy_list = array_column($sy_rows, 'school_year');
$selected_sy = $_GET['sy'] ?? ($sy_list[0] ?? '2025-2026');

// ── KPI 1: Total BOSY Enrollment ─────────────────────────────
$q = $pdo->prepare("
  SELECT COALESCE(SUM(
    CASE
      WHEN gl.level_type='Senior High' THEN (CASE WHEN e.semester='1st Sem' THEN e.bosy_enrollment ELSE 0 END)
      ELSE e.bosy_enrollment
    END
  ),0) as total 
  FROM enrollment_data e
  JOIN grade_levels gl ON gl.id = e.grade_level_id
  WHERE e.school_year=?
");
$q->execute([$selected_sy]); $total_enroll = (int)$q->fetchColumn();

// ── Enrollment by grade ──────────────────────────────────────
$q = $pdo->prepare("
  SELECT gl.grade_name, gl.level_type,
    COALESCE(SUM(
      CASE
        WHEN gl.level_type='Senior High' THEN (CASE WHEN e.semester='1st Sem' THEN e.bosy_enrollment ELSE 0 END)
        ELSE e.bosy_enrollment
      END
    ),0) AS enroll
  FROM grade_levels gl
  LEFT JOIN enrollment_data e ON e.grade_level_id=gl.id AND e.school_year=?
  GROUP BY gl.id ORDER BY gl.id
");
$q->execute([$selected_sy]);
$enroll_by_grade = $q->fetchAll();

// ── KPI 2: Repeater Rate ─────────────────────────────────────
$q = $pdo->prepare("SELECT COALESCE(SUM(repeaters_count),0) FROM repeaters_data WHERE school_year=?");
$q->execute([$selected_sy]); $total_repeaters = (int)$q->fetchColumn();
$repeater_rate = $total_enroll > 0 ? round($total_repeaters / $total_enroll * 100, 2) : 0;

// ── KPI 3: Dropout Rate & Retention ─────────────────────────
$q = $pdo->prepare("SELECT COALESCE(SUM(dropouts_count),0) FROM dropouts_data WHERE school_year=?");
$q->execute([$selected_sy]); $total_dropouts = (int)$q->fetchColumn();
$dropout_rate   = $total_enroll > 0 ? round($total_dropouts / $total_enroll * 100, 2) : 0;
$retention_rate = round(100 - $dropout_rate, 2);

// ── KPI 4: Classroom Utilization ─────────────────────────────
$q = $pdo->query("SELECT COUNT(*) as total, SUM(is_functional) as functional, COALESCE(SUM(CASE WHEN is_functional=1 THEN total_area ELSE 0 END),0) as area FROM classrooms");
$cls = $q->fetch();
$total_rooms = (int)$cls['total'];
$func_rooms  = (int)$cls['functional'];
$total_area  = (float)$cls['area'];
$util_rate   = $total_rooms > 0 ? round($func_rooms / $total_rooms * 100, 1) : 0;
$area_per_student = $total_enroll > 0 ? round($total_area / $total_enroll, 2) : 0;

// ── KPI 5: Seat Sufficiency ──────────────────────────────────
$q = $pdo->prepare("SELECT COALESCE(SUM(available_seats),0) FROM seats_data WHERE school_year=?");
$q->execute([$selected_sy]); $total_seats = (int)$q->fetchColumn();
$seat_ratio = $total_enroll > 0 ? round($total_seats / $total_enroll * 100, 1) : 0;

// ── KPI 6 & 7: Teacher ratios ────────────────────────────────
$q = $pdo->prepare("SELECT COALESCE(SUM(teacher_count),0) FROM teachers_per_grade WHERE school_year=?");
$q->execute([$selected_sy]); $jhs_teachers = (int)$q->fetchColumn();

$jhs_enroll = 0;
foreach($enroll_by_grade as $r) if($r['level_type']==='Junior High') $jhs_enroll += $r['enroll'];
$shs_enroll = $total_enroll - $jhs_enroll;

$jhs_ratio = $jhs_teachers > 0 ? round($jhs_enroll / $jhs_teachers, 1) : 0;

$q = $pdo->prepare("SELECT COALESCE(SUM(teacher_count),0) FROM teachers_per_area WHERE level_type='Senior High' AND school_year=?");
$q->execute([$selected_sy]); $shs_teachers = (int)$q->fetchColumn();
$shs_ratio = $shs_teachers > 0 ? round($shs_enroll / $shs_teachers, 1) : 0;

// ── Repeaters & Dropouts per grade ──────────────────────────
$q = $pdo->prepare("
  SELECT gl.grade_name,
    (SELECT COALESCE(SUM(r.repeaters_count),0) FROM repeaters_data r WHERE r.grade_level_id=gl.id AND r.school_year=?) AS rep,
    (SELECT COALESCE(SUM(d.dropouts_count),0) FROM dropouts_data d WHERE d.grade_level_id=gl.id AND d.school_year=?) AS drop_
  FROM grade_levels gl
  ORDER BY gl.id
");
$q->execute([$selected_sy,$selected_sy]);
$perf_matrix = $q->fetchAll();

// ── Teachers per learning area ──────────────────────────────
$q = $pdo->prepare("SELECT learning_area, teacher_count, level_type FROM teachers_per_area WHERE school_year=? ORDER BY teacher_count DESC");
$q->execute([$selected_sy]); $teacher_areas = $q->fetchAll();

// ── Enrollment trend (last 5 SY) ────────────────────────────
$trend_q = $pdo->prepare("
  SELECT e.school_year, 
    COALESCE(SUM(
      CASE
        WHEN gl.level_type='Senior High' THEN (CASE WHEN e.semester='1st Sem' THEN e.bosy_enrollment ELSE 0 END)
        ELSE e.bosy_enrollment
      END
    ),0) as total
  FROM enrollment_data e
  JOIN grade_levels gl ON gl.id = e.grade_level_id
  GROUP BY e.school_year ORDER BY e.school_year ASC LIMIT 5
");
$trend_q->execute(); $enroll_trend = $trend_q->fetchAll();

include 'includes/header.php';
?>
<div id="dashboardExport">
<!-- ── Section Header ──────────────────────────────────────── -->
<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
  <div class="section-header mb-0">
    <h1 class="section-title"><i class="bi bi-speedometer2 me-2 text-primary-nhs"></i>Performance Dashboard</h1>
    <p class="section-sub">School Year: <strong><?= htmlspecialchars($selected_sy) ?></strong> — Real-time KPI Overview</p>
  </div>
  <button class="btn-primary-nhs" onclick="exportToPDF('dashboardExport','NHS_Dashboard_<?= $selected_sy ?>.pdf')">
    <i class="bi bi-file-earmark-pdf"></i> Export PDF
  </button>
</div>

<!-- ── KPI ROW 1 ─────────────────────────────────────────────── -->
<div class="row g-3 mb-4">
  <!-- Total Enrollment -->
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card kpi-info">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon navy"><i class="bi bi-people-fill"></i></div>
        <div>
          <div class="kpi-label">Total BOSY Enrollment</div>
          <div class="kpi-value text-primary-nhs"><?= number_format($total_enroll) ?></div>
          <div class="kpi-sub">All grade levels</div>
        </div>
      </div>
    </div>
  </div>
  <!-- Repeater Rate -->
  <?php
    $rep_class = $repeater_rate <= 3 ? 'kpi-good' : ($repeater_rate <= 8 ? 'kpi-warn' : 'kpi-danger');
    $rep_color = $repeater_rate <= 3 ? 'green' : ($repeater_rate <= 8 ? 'yellow' : 'red');
    $rep_badge = $repeater_rate <= 3 ? 'badge-good' : ($repeater_rate <= 8 ? 'badge-warn' : 'badge-danger');
    $rep_status = $repeater_rate <= 3 ? '🟢 Good' : ($repeater_rate <= 8 ? '🟡 Monitor' : '🔴 Critical');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $rep_class ?>">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $rep_color ?>"><i class="bi bi-arrow-repeat"></i></div>
        <div>
          <div class="kpi-label">Repeater Rate</div>
          <div class="kpi-value"><?= $repeater_rate ?>%</div>
          <div class="kpi-sub"><?= number_format($total_repeaters) ?> repeaters
            <span class="kpi-badge <?= $rep_badge ?> ms-1"><?= $rep_status ?></span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Dropout Rate -->
  <?php
    $do_class = $dropout_rate <= 5 ? 'kpi-good' : ($dropout_rate <= 10 ? 'kpi-warn' : 'kpi-danger');
    $do_color = $dropout_rate <= 5 ? 'green' : ($dropout_rate <= 10 ? 'yellow' : 'red');
    $do_badge = $dropout_rate <= 5 ? 'badge-good' : ($dropout_rate <= 10 ? 'badge-warn' : 'badge-danger');
    $do_status= $dropout_rate <= 5 ? '🟢 Good' : ($dropout_rate <= 10 ? '🟡 Monitor' : '🔴 Critical');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $do_class ?>">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $do_color ?>"><i class="bi bi-person-dash-fill"></i></div>
        <div>
          <div class="kpi-label">Dropout Rate</div>
          <div class="kpi-value"><?= $dropout_rate ?>%</div>
          <div class="kpi-sub">Retention: <strong><?= $retention_rate ?>%</strong>
            <span class="kpi-badge <?= $do_badge ?> ms-1"><?= $do_status ?></span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Retention Rate -->
  <?php $ret_class = $retention_rate >= 95 ? 'kpi-good' : ($retention_rate >= 90 ? 'kpi-warn' : 'kpi-danger'); ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $ret_class ?>">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon green"><i class="bi bi-person-check-fill"></i></div>
        <div>
          <div class="kpi-label">Retention Rate</div>
          <div class="kpi-value text-success"><?= $retention_rate ?>%</div>
          <div class="kpi-sub">Students staying enrolled</div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ── KPI ROW 2 ─────────────────────────────────────────────── -->
<div class="row g-3 mb-4">
  <!-- Classroom Utilization -->
  <?php
    $util_class = $util_rate >= 90 ? 'kpi-good' : ($util_rate >= 70 ? 'kpi-warn' : 'kpi-danger');
    $util_color = $util_rate >= 90 ? 'green' : ($util_rate >= 70 ? 'yellow' : 'red');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $util_class ?>">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $util_color ?>"><i class="bi bi-building-fill"></i></div>
        <div>
          <div class="kpi-label">Classroom Utilization</div>
          <div class="kpi-value"><?= $util_rate ?>%</div>
          <div class="kpi-sub"><?= $func_rooms ?>/<?= $total_rooms ?> functional &middot; <?= number_format($total_area,0) ?> sqm</div>
        </div>
      </div>
    </div>
  </div>
  <!-- Floor Area per Student -->
  <?php
    $area_class = $area_per_student >= 1.4 ? 'kpi-good' : ($area_per_student >= 1.0 ? 'kpi-warn' : 'kpi-danger');
    $area_color = $area_per_student >= 1.4 ? 'green' : ($area_per_student >= 1.0 ? 'yellow' : 'red');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $area_class ?>">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $area_color ?>"><i class="bi bi-grid-3x3"></i></div>
        <div>
          <div class="kpi-label">Floor Area / Student</div>
          <div class="kpi-value"><?= $area_per_student ?> <small class="fs-6">sqm</small></div>
          <div class="kpi-sub">DepEd Standard: 1.4 sqm</div>
        </div>
      </div>
    </div>
  </div>
  <!-- Seat Sufficiency -->
  <?php
    $seat_class = $seat_ratio >= 100 ? 'kpi-good' : ($seat_ratio >= 90 ? 'kpi-warn' : 'kpi-danger');
    $seat_color = $seat_ratio >= 100 ? 'green' : ($seat_ratio >= 90 ? 'yellow' : 'red');
    $seat_label = $seat_ratio >= 100 ? 'Sufficient' : ($seat_ratio >= 90 ? 'Near Shortage' : 'Overcrowded');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $seat_class ?>">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $seat_color ?>"><i class="bi bi-person-workspace"></i></div>
        <div>
          <div class="kpi-label">Seat Sufficiency</div>
          <div class="kpi-value"><?= $seat_ratio ?>%</div>
          <div class="kpi-sub"><?= number_format($total_seats) ?> seats / <?= number_format($total_enroll) ?> students &middot; <em><?= $seat_label ?></em></div>
        </div>
      </div>
    </div>
  </div>
  <!-- Teacher Ratio (JHS) -->
  <?php
    $jhs_rclass = $jhs_ratio <= 35 ? 'kpi-good' : ($jhs_ratio <= 45 ? 'kpi-warn' : 'kpi-danger');
    $jhs_rcolor = $jhs_ratio <= 35 ? 'green' : ($jhs_ratio <= 45 ? 'yellow' : 'red');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $jhs_rclass ?>">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $jhs_rcolor ?>"><i class="bi bi-person-video3"></i></div>
        <div>
          <div class="kpi-label">Teacher Ratio (JHS)</div>
          <div class="kpi-value">1 : <?= $jhs_ratio ?></div>
          <div class="kpi-sub"><?= $jhs_teachers ?> teachers · Standard: 1:35</div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- ── CHARTS ROW ──────────────────────────────────────────── -->
<div class="row g-3 mb-4">
  <!-- Enrollment Trend -->
  <div class="col-xl-8">
    <div class="chart-card">
      <div class="chart-card-title"><i class="bi bi-bar-chart-fill me-2 text-primary-nhs"></i>Enrollment by Grade Level</div>
      <div class="chart-card-sub">BOSY Enrollment distribution — S.Y. <?= htmlspecialchars($selected_sy) ?></div>
      <div class="chart-wrapper" style="height:280px">
        <canvas id="enrollChart"></canvas>
      </div>
    </div>
  </div>
  <!-- Facility Status -->
  <div class="col-xl-4">
    <div class="chart-card">
      <div class="chart-card-title"><i class="bi bi-building me-2 text-primary-nhs"></i>Facility Status</div>
      <div class="chart-card-sub">Functional vs. Non-Functional Classrooms</div>
      <div class="chart-wrapper" style="height:280px">
        <canvas id="facilityChart"></canvas>
      </div>
    </div>
  </div>
</div>

<div class="row g-3 mb-4">
  <!-- Performance Health Matrix -->
  <div class="col-xl-7">
    <div class="chart-card">
      <div class="chart-card-title"><i class="bi bi-activity me-2 text-primary-nhs"></i>Performance Health Matrix</div>
      <div class="chart-card-sub">Repeaters vs. Dropouts per Grade Level</div>
      <div class="chart-wrapper" style="height:280px">
        <canvas id="perfChart"></canvas>
      </div>
    </div>
  </div>
  <!-- Resource Allocation -->
  <div class="col-xl-5">
    <div class="chart-card">
      <div class="chart-card-title"><i class="bi bi-person-badge me-2 text-primary-nhs"></i>Teachers per Learning Area</div>
      <div class="chart-card-sub">Workforce distribution — <?= htmlspecialchars($selected_sy) ?></div>
      <div class="chart-wrapper" style="height:280px">
        <canvas id="teacherChart"></canvas>
      </div>
    </div>
  </div>
</div>

<!-- ── Enrollment Trend Line ──────────────────────────────── -->
<div class="row g-3 mb-4">
  <div class="col-12">
    <div class="chart-card">
      <div class="chart-card-title"><i class="bi bi-graph-up-arrow me-2 text-primary-nhs"></i>Enrollment Trend (5-Year)</div>
      <div class="chart-card-sub">Historical total enrollment across all grade levels</div>
      <div class="chart-wrapper" style="height:240px">
        <canvas id="trendChart"></canvas>
      </div>
    </div>
  </div>
</div>

<!-- ── Junior High School Summary ────────────────────────────────── -->
<div class="data-card mb-4">
  <div class="data-card-header">
    <span class="data-card-title"><i class="bi bi-table me-2"></i>Junior High School Summary</span>
    <?php if(!defined('FEATURE_DATA_ENTRY') || FEATURE_DATA_ENTRY): ?>
    <a href="enrollment.php?sy=<?= urlencode($selected_sy) ?>" class="btn-outline-nhs">
      <i class="bi bi-arrow-right"></i> Manage Data
    </a>
    <?php endif; ?>
  </div>
  <div class="table-responsive">
    <table class="nhs-table">
      <thead>
        <tr>
          <th>Grade Level</th><th>Type</th><th>Enrollment</th>
          <th>Repeater</th><th>Dropouts</th><th>Rep. Rate</th><th>Drop. Rate</th><th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($perf_matrix as $i => $row):
          if ($enroll_by_grade[$i]['level_type'] !== 'Junior High') continue;
          $enroll_g = $enroll_by_grade[$i]['enroll'] ?? 0;
          $r_rate   = $enroll_g > 0 ? round($row['rep']/$enroll_g*100,1) : 0;
          $d_rate   = $enroll_g > 0 ? round($row['drop_']/$enroll_g*100,1) : 0;
          $status   = ($r_rate == 0 && $d_rate == 0) ? 'badge-good' : (($d_rate > 10 || $r_rate > 8) ? 'badge-danger' : 'badge-warn');
          $status_t = ($r_rate == 0 && $d_rate == 0) ? '🎉 Excellent' : (($d_rate > 10 || $r_rate > 8) ? '🔴 Critical' : '🟡 Monitor');
        ?>
        <tr>
          <td class="fw-600"><?= htmlspecialchars($row['grade_name']) ?></td>
          <td><span class="kpi-badge badge-info"><?= $enroll_by_grade[$i]['level_type'] ?></span></td>
          <td><?= number_format($enroll_g) ?></td>
          <td><?= number_format($row['rep']) ?></td>
          <td><?= number_format($row['drop_']) ?></td>
          <td><?= $r_rate ?>%</td>
          <td><?= $d_rate ?>%</td>
          <td><span class="kpi-badge <?= $status ?>"><?= $status_t ?></span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ── Senior High School Summary ────────────────────────────────── -->
<div class="data-card mb-4">
  <div class="data-card-header">
    <span class="data-card-title"><i class="bi bi-table me-2"></i>Senior High School Summary</span>
    <?php if(!defined('FEATURE_DATA_ENTRY') || FEATURE_DATA_ENTRY): ?>
    <a href="enrollment.php?sy=<?= urlencode($selected_sy) ?>" class="btn-outline-nhs">
      <i class="bi bi-arrow-right"></i> Manage Data
    </a>
    <?php endif; ?>
  </div>
  <div class="table-responsive">
    <table class="nhs-table">
      <thead>
        <tr>
          <th>Grade Level</th><th>Type</th><th>Enrollment</th>
          <th>Repeater</th><th>Dropouts</th><th>Rep. Rate</th><th>Drop. Rate</th><th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($perf_matrix as $i => $row):
          if ($enroll_by_grade[$i]['level_type'] !== 'Senior High') continue;
          $enroll_g = $enroll_by_grade[$i]['enroll'] ?? 0;
          $r_rate   = $enroll_g > 0 ? round($row['rep']/$enroll_g*100,1) : 0;
          $d_rate   = $enroll_g > 0 ? round($row['drop_']/$enroll_g*100,1) : 0;
          $status   = ($r_rate == 0 && $d_rate == 0) ? 'badge-good' : (($d_rate > 10 || $r_rate > 8) ? 'badge-danger' : 'badge-warn');
          $status_t = ($r_rate == 0 && $d_rate == 0) ? '🎉 Excellent' : (($d_rate > 10 || $r_rate > 8) ? '🔴 Critical' : '🟡 Monitor');
        ?>
        <tr>
          <td class="fw-600"><?= htmlspecialchars($row['grade_name']) ?></td>
          <td><span class="kpi-badge badge-primary"><?= $enroll_by_grade[$i]['level_type'] ?></span></td>
          <td><?= number_format($enroll_g) ?></td>
          <td><?= number_format($row['rep']) ?></td>
          <td><?= number_format($row['drop_']) ?></td>
          <td><?= $r_rate ?>%</td>
          <td><?= $d_rate ?>%</td>
          <td><span class="kpi-badge <?= $status ?>"><?= $status_t ?></span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</div><!-- end #dashboardExport -->

<script>
document.addEventListener('DOMContentLoaded', function() {
// ── Chart data from PHP ─────────────────────────────────────
const enrollLabels = <?= json_encode(array_column($enroll_by_grade,'grade_name')) ?>;
const enrollData   = <?= json_encode(array_column($enroll_by_grade,'enroll')) ?>;
const perfLabels   = <?= json_encode(array_column($perf_matrix,'grade_name')) ?>;
const perfRep      = <?= json_encode(array_column($perf_matrix,'rep')) ?>;
const perfDrop     = <?= json_encode(array_column($perf_matrix,'drop_')) ?>;
const funcRooms    = <?= $func_rooms ?>;
const nonFuncRooms = <?= $total_rooms - $func_rooms ?>;
const taLabels     = <?= json_encode(array_column($teacher_areas,'learning_area')) ?>;
const taData       = <?= json_encode(array_column($teacher_areas,'teacher_count')) ?>;
const trendLabels  = <?= json_encode(array_column($enroll_trend,'school_year')) ?>;
const trendData    = <?= json_encode(array_column($enroll_trend,'total')) ?>;

// --- ⚡ Proper Contrast & Theme Settings for Highly Readable NHS Charts ---
const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
const textColor = isDark ? '#F1F4FD' : '#1A1A2E'; // Bold, crisp text for ultimate legibility
const gridColor = isDark ? 'rgba(61, 70, 112, 0.4)' : '#E2E8F0'; // Soft readable grids

// Bold and clear fonts for high readability/accessibility
Chart.defaults.font.family = "'Poppins', sans-serif";
Chart.defaults.font.size   = 12;
Chart.defaults.font.weight = '600'; // Global semi-bold text inside charts
Chart.defaults.color       = textColor;

// Dynamic High-Contrast Semantic Colors
const chartNavy  = isDark ? '#6B9BE8' : '#1B2A6B';
const chartGold  = isDark ? '#F0CA76' : '#C9A227';
const chartRed   = isDark ? '#F5A0A0' : '#8B1A1A';
const chartGreen = isDark ? '#7DD9A3' : '#16a34a';

// Grades-demarcated high-contrast palette for Enrollment bar chart
const themePalette = isDark ? [
  '#6B9BE8', '#F0CA76', '#F5A0A0', '#56C1FF', '#FFBD80', '#A5D6A7'
] : [
  '#1B2A6B', '#C9A227', '#8B1A1A', '#2E3F8F', '#A07D0F', '#B02020'
];

const activeCharts = [];

// 1. Enrollment Bar Chart (Solid Distinct Colors per Grade)
const enrollCtx = document.getElementById('enrollChart').getContext('2d');
const enrollChart = new Chart(enrollCtx, {
  type: 'bar',
  data: {
    labels: enrollLabels,
    datasets: [{
      label: 'BOSY Enrollment',
      data: enrollData,
      backgroundColor: themePalette,
      borderRadius: 6,
      borderSkipped: false,
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { 
      legend: { display: false }, 
      tooltip: { 
        backgroundColor: isDark ? '#252A44' : '#ffffff',
        titleColor: isDark ? '#ffffff' : '#1A1A2E',
        titleFont: { family: 'Poppins', weight: '700', size: 13 },
        bodyColor: textColor,
        bodyFont: { family: 'Poppins', weight: '600', size: 12 },
        borderColor: isDark ? '#3D4670' : '#cbd5e1',
        borderWidth: 1,
        callbacks: { label: ctx => ' ' + ctx.parsed.y.toLocaleString() + ' students' } 
      } 
    },
    scales: {
      y: { 
        grid: { color: gridColor }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 }, 
          callback: v => v.toLocaleString() 
        } 
      },
      x: { 
        grid: { display: false }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 } 
        } 
      }
    }
  }
});
activeCharts.push(enrollChart);

// 2. Facility Status (Solid Green/Red)
const facilityCtx = document.getElementById('facilityChart').getContext('2d');
const facilityChart = new Chart(facilityCtx, {
  type: 'doughnut',
  data: {
    labels: ['Functional', 'Non-Functional'],
    datasets: [{ 
      data: [funcRooms, nonFuncRooms], 
      backgroundColor: [chartGreen, chartRed], 
      borderWidth: isDark ? 2 : 1, 
      borderColor: isDark ? '#20253E' : '#ffffff',
      hoverOffset: 8 
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: {
      legend: { 
        position: 'bottom', 
        labels: { 
          padding: 16, 
          usePointStyle: true, 
          color: textColor, 
          font: { weight: '600', size: 12 } 
        } 
      },
      tooltip: { 
        backgroundColor: isDark ? '#252A44' : '#ffffff',
        titleColor: isDark ? '#ffffff' : '#1A1A2E',
        titleFont: { family: 'Poppins', weight: '700', size: 13 },
        bodyColor: textColor,
        bodyFont: { family: 'Poppins', weight: '600', size: 12 },
        borderColor: isDark ? '#3D4670' : '#cbd5e1',
        borderWidth: 1,
        callbacks: { label: ctx => ` ${ctx.label}: ${ctx.parsed} rooms` } 
      }
    },
    cutout: '68%'
  }
});
activeCharts.push(facilityChart);

// 3. Performance Health Matrix (Solid Gold/Red)
const perfCtx = document.getElementById('perfChart').getContext('2d');
const perfChart = new Chart(perfCtx, {
  type: 'bar',
  data: {
    labels: perfLabels,
    datasets: [
      { 
        label: 'Repeaters', 
        data: perfRep,  
        backgroundColor: chartGold, 
        borderRadius: 5 
      },
      { 
        label: 'Dropouts',  
        data: perfDrop, 
        backgroundColor: chartRed, 
        borderRadius: 5 
      }
    ]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { 
      legend: { 
        position: 'bottom',
        labels: { 
          color: textColor, 
          boxWidth: 12, 
          padding: 12, 
          font: { weight: '600', size: 12 } 
        }
      },
      tooltip: {
        backgroundColor: isDark ? '#252A44' : '#ffffff',
        titleColor: isDark ? '#ffffff' : '#1A1A2E',
        titleFont: { family: 'Poppins', weight: '700', size: 13 },
        bodyColor: textColor,
        bodyFont: { family: 'Poppins', weight: '600', size: 12 },
        borderColor: isDark ? '#3D4670' : '#cbd5e1',
        borderWidth: 1
      }
    },
    scales: {
      y: { 
        grid: { color: gridColor }, 
        beginAtZero: true, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 } 
        } 
      },
      x: { 
        grid: { display: false }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 } 
        } 
      }
    }
  }
});
activeCharts.push(perfChart);

// 4. Teacher Resource Horizontal Bar (Solid Navy)
const teacherCtx = document.getElementById('teacherChart').getContext('2d');
const teacherChart = new Chart(teacherCtx, {
  type: 'bar',
  data: {
    labels: taLabels,
    datasets: [{ 
      label: 'Teachers', 
      data: taData, 
      backgroundColor: chartNavy, 
      borderRadius: 5 
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false, indexAxis: 'y',
    plugins: { 
      legend: { display: false },
      tooltip: {
        backgroundColor: isDark ? '#252A44' : '#ffffff',
        titleColor: isDark ? '#ffffff' : '#1A1A2E',
        titleFont: { family: 'Poppins', weight: '700', size: 13 },
        bodyColor: textColor,
        bodyFont: { family: 'Poppins', weight: '600', size: 12 },
        borderColor: isDark ? '#3D4670' : '#cbd5e1',
        borderWidth: 1
      }
    },
    scales: {
      x: { 
        grid: { color: gridColor }, 
        beginAtZero: true, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 }, 
          stepSize: 1 
        } 
      },
      y: { 
        grid: { display: false }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 11 } 
        } 
      }
    }
  }
});
activeCharts.push(teacherChart);

// 5. Enrollment Trend Line (Solid Navy with Soft Fill Glow)
const trendCtx = document.getElementById('trendChart').getContext('2d');
const trendGrad = trendCtx.createLinearGradient(0, 0, 0, 240);
trendGrad.addColorStop(0, isDark ? 'rgba(107, 155, 232, 0.25)' : 'rgba(27, 42, 107, 0.15)');
trendGrad.addColorStop(1, 'rgba(27, 42, 107, 0.0)');

const trendChart = new Chart(trendCtx, {
  type: 'line',
  data: {
    labels: trendLabels,
    datasets: [{
      label: 'Total Enrollment',
      data: trendData,
      borderColor: chartNavy,
      backgroundColor: trendGrad,
      fill: true,
      tension: 0.4,
      pointBackgroundColor: chartGold,
      pointBorderColor: chartNavy,
      pointBorderWidth: 2,
      pointRadius: 5,
      pointHoverRadius: 8
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { 
      legend: { display: false },
      tooltip: {
        backgroundColor: isDark ? '#252A44' : '#ffffff',
        titleColor: isDark ? '#ffffff' : '#1A1A2E',
        titleFont: { family: 'Poppins', weight: '700', size: 13 },
        bodyColor: textColor,
        bodyFont: { family: 'Poppins', weight: '600', size: 12 },
        borderColor: isDark ? '#3D4670' : '#cbd5e1',
        borderWidth: 1
      }
    },
    scales: {
      y: { 
        grid: { color: gridColor }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 }, 
          callback: v => v.toLocaleString() 
        } 
      },
      x: { 
        grid: { display: false }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 } 
        } 
      }
    }
  }
});
activeCharts.push(trendChart);

// --- ⚡ Real-Time Theme Transition Listener for Charts ---
const themeToggle = document.getElementById('darkModeToggle');
if (themeToggle) {
  themeToggle.addEventListener('change', function() {
    setTimeout(() => {
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      const newTextColor = isDark ? '#F1F4FD' : '#1A1A2E';
      const newGridColor = isDark ? 'rgba(61, 70, 112, 0.4)' : '#E2E8F0';
      const newNavy  = isDark ? '#6B9BE8' : '#1B2A6B';
      const newGold  = isDark ? '#F0CA76' : '#C9A227';
      const newRed   = isDark ? '#F5A0A0' : '#8B1A1A';
      const newGreen = isDark ? '#7DD9A3' : '#16a34a';

      const newPalette = isDark ? [
        '#6B9BE8', '#F0CA76', '#F5A0A0', '#56C1FF', '#FFBD80', '#A5D6A7'
      ] : [
        '#1B2A6B', '#C9A227', '#8B1A1A', '#2E3F8F', '#A07D0F', '#B02020'
      ];

      Chart.defaults.color = newTextColor;

      activeCharts.forEach(chart => {
        // Update scales tick colors & grid colors
        if (chart.options.scales) {
          Object.keys(chart.options.scales).forEach(scaleKey => {
            const scale = chart.options.scales[scaleKey];
            if (scale.ticks) scale.ticks.color = newTextColor;
            if (scale.grid) scale.grid.color = newGridColor;
          });
        }
        // Update legend colors
        if (chart.options.plugins && chart.options.plugins.legend && chart.options.plugins.legend.labels) {
          chart.options.plugins.legend.labels.color = newTextColor;
        }
        // Update tooltip card text colors
        if (chart.options.plugins && chart.options.plugins.tooltip) {
          chart.options.plugins.tooltip.bodyColor = newTextColor;
          chart.options.plugins.tooltip.backgroundColor = isDark ? '#252A44' : '#ffffff';
          chart.options.plugins.tooltip.titleColor = isDark ? '#ffffff' : '#1A1A2E';
          chart.options.plugins.tooltip.borderColor = isDark ? '#3D4670' : '#cbd5e1';
        }

        // Update dataset styling rules dynamically
        chart.data.datasets.forEach(dataset => {
          if (dataset.label === 'BOSY Enrollment') {
            dataset.backgroundColor = newPalette;
          } else if (dataset.label === 'Repeaters') {
            dataset.backgroundColor = newGold;
          } else if (dataset.label === 'Dropouts') {
            dataset.backgroundColor = newRed;
          } else if (dataset.label === 'Teachers') {
            dataset.backgroundColor = newNavy;
          } else if (dataset.label === 'Total Enrollment') {
            dataset.borderColor = newNavy;
            dataset.pointBackgroundColor = newGold;
            dataset.pointBorderColor = newNavy;
            const ctx = chart.ctx;
            const trendGrad = ctx.createLinearGradient(0, 0, 0, 240);
            trendGrad.addColorStop(0, isDark ? 'rgba(107, 155, 232, 0.25)' : 'rgba(27, 42, 107, 0.15)');
            trendGrad.addColorStop(1, 'rgba(27, 42, 107, 0.0)');
            dataset.backgroundColor = trendGrad;
          } else if (chart.canvas.id === 'facilityChart') {
            dataset.backgroundColor = [newGreen, newRed];
            dataset.borderColor = isDark ? '#20253E' : '#ffffff';
          }
        });

        chart.update();
      });
    }, 50);
  });
}
});
</script>

<?php include 'includes/footer.php'; ?>
