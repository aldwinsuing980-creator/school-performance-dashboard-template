<?php
// calendar.php
require_once __DIR__ . '/config/session.php';
require_login();

$page_title = 'School Calendar';
$breadcrumb = 'Academic Schedules';

$sy_rows = $pdo->query("SELECT DISTINCT school_year FROM enrollment_data ORDER BY school_year DESC")->fetchAll();
$sy_list = array_column($sy_rows, 'school_year');
$sel_sy  = $_GET['sy'] ?? ($sy_list[0] ?? '2025-2026');

include 'includes/header.php';
?>
<!-- FullCalendar CDN Stylesheet -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.css">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js"></script>

<style>
  .calendar-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 24px;
    box-shadow: var(--shadow);
  }
  
  /* Premium FullCalendar Custom Styling */
  .fc {
    font-family: 'Poppins', sans-serif;
    --fc-today-bg-color: rgba(27, 42, 107, 0.05);
    --fc-button-bg-color: #1B2A6B;
    --fc-button-border-color: #1B2A6B;
    --fc-button-hover-bg-color: #2E3F8F;
    --fc-button-hover-border-color: #2E3F8F;
    --fc-button-active-bg-color: #0F4C81;
    --fc-button-active-border-color: #0F4C81;
  }
  
  .fc .fc-button-primary {
    font-weight: 600;
    font-size: 0.85rem;
    padding: 8px 16px;
    border-radius: 10px !important;
    text-transform: capitalize;
    box-shadow: 0 4px 6px -1px rgba(27, 42, 107, 0.1);
    transition: all 0.2s ease;
  }
  
  .fc .fc-button-primary:focus {
    box-shadow: 0 0 0 3px rgba(27, 42, 107, 0.25) !important;
  }
  
  .fc-theme-standard th {
    background-color: var(--bg);
    padding: 12px 0 !important;
  }
  
  .fc-col-header-cell-cushion {
    font-size: 0.85rem;
    font-weight: 700;
    color: var(--primary) !important;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-decoration: none !important;
  }
  
  .fc-daygrid-day-number {
    font-size: 0.9rem;
    font-weight: 600;
    color: var(--text-dark) !important;
    padding: 8px !important;
    text-decoration: none !important;
  }
  
  .fc-daygrid-event {
    border-radius: 8px !important;
    padding: 4px 8px !important;
    font-size: 0.78rem !important;
    font-weight: 600 !important;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05) !important;
    border: none !important;
    cursor: pointer;
    transition: transform 0.15s ease;
  }
  
  .fc-daygrid-event:hover {
    transform: scale(1.02);
  }
  
  .calendar-legend {
    display: flex;
    gap: 1.5rem;
    flex-wrap: wrap;
    margin-top: 1.5rem;
    padding: 1rem;
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 12px;
  }
  
  .legend-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.82rem;
    font-weight: 600;
    color: var(--text-muted);
  }
  
  .legend-color {
    width: 14px;
    height: 14px;
    border-radius: 4px;
  }
  
  /* --- Dark Mode Custom Overrides --- */
  [data-theme="dark"] .fc {
    --fc-border-color: #334155;
    --fc-daygrid-event-dot-color: #cbd5e1;
    --fc-page-bg-color: #0f172a;
    --fc-neutral-bg-color: #1e293b;
    --fc-list-event-hover-bg-color: #1e293b;
    color: #f8fafc;
  }
  
  [data-theme="dark"] .fc-theme-standard th,
  [data-theme="dark"] .fc-theme-standard td {
    border-color: #334155 !important;
  }
  
  [data-theme="dark"] .fc-day-today {
    background-color: rgba(107, 155, 232, 0.1) !important;
  }
  
  [data-theme="dark"] .fc-col-header-cell-cushion {
    color: var(--accent) !important;
  }
  
  [data-theme="dark"] .fc-daygrid-day-number {
    color: #cbd5e1 !important;
  }
  
  [data-theme="dark"] .fc-button-primary {
    background-color: #1b2a6b !important;
    border-color: #1b2a6b !important;
  }
  [data-theme="dark"] .fc-button-primary:hover {
    background-color: #2e3f8f !important;
    border-color: #2e3f8f !important;
  }
</style>

<div class="container-fluid py-2">
  <!-- Section Header -->
  <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
    <div class="section-header mb-0">
      <h1 class="section-title"><i class="bi bi-calendar3 me-2 text-primary-nhs"></i>School Calendar</h1>
      <p class="section-sub">Academic schedules, suspensions, and examination timelines</p>
    </div>
    
    <!-- Access Shortcuts based on role -->
    <?php if(has_role('Admin', 'Encoder', 'Faculty')): ?>
    <a href="announcements.php" class="btn-primary-nhs text-white text-decoration-none d-inline-flex align-items-center gap-2">
      <i class="bi bi-plus-circle"></i> Create Schedule Notice
    </a>
    <?php endif; ?>
  </div>

  <!-- Calendar Card -->
  <div class="calendar-card">
    <!-- Calendar Div container for FullCalendar -->
    <div id="calendar" style="min-height: 600px;"></div>
    
    <!-- Legend -->
    <div class="calendar-legend">
      <div class="legend-item">
        <div class="legend-color" style="background-color: #1b2a6b;"></div>
        <span>📢 Academic & General Notices</span>
      </div>
      <div class="legend-item">
        <div class="legend-color" style="background-color: #c9a227;"></div>
        <span>🏆 Examinations & School Events</span>
      </div>
      <div class="legend-item">
        <div class="legend-color" style="background-color: #dc2626;"></div>
        <span>🌧️ Class Suspensions</span>
      </div>
    </div>
  </div>
</div>

<!-- FullCalendar Initialization script -->
<script>
document.addEventListener('DOMContentLoaded', function() {
  const calendarEl = document.getElementById('calendar');
  
  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,listMonth'
    },
    editable: false,
    selectable: false,
    businessHours: true,
    dayMaxEvents: true, // limit events cell expansion
    events: 'ajax/calendar_events.php', // Feed URL
    
    // Clicking on events opens detailed SweetAlert modal
    eventClick: function(info) {
      const p = info.event.extendedProps;
      const cat = p.category;
      
      let catBadge = '';
      if(cat === 'suspension') {
        catBadge = '<span class="badge bg-danger text-white">🌧️ Class Suspension</span>';
      } else if (cat === 'event') {
        catBadge = '<span class="badge bg-warning text-dark">🏆 School Event / Exam</span>';
      } else {
        catBadge = '<span class="badge bg-primary text-white">📢 Academic Notice</span>';
      }
      
      let datePeriod = '';
      if (p.start_raw === p.end_raw) {
        datePeriod = `<strong>Date:</strong> ${p.start_raw}`;
      } else {
        datePeriod = `<strong>Duration Period:</strong> ${p.start_raw} to ${p.end_raw}`;
      }

      Swal.fire({
        title: `<strong>${info.event.title}</strong>`,
        icon: cat === 'suspension' ? 'warning' : 'info',
        html: `
          <div style="text-align: left; line-height: 1.6; font-family: 'Poppins', sans-serif; font-size: 0.92rem;">
            <p style="margin-bottom: 8px;">${catBadge}</p>
            <p style="margin-bottom: 8px;">${datePeriod}</p>
            <hr style="margin: 12px 0; border-color: rgba(0,0,0,0.1);">
            <div style="white-space: pre-wrap; color: var(--text); font-size:0.9rem;">${p.content}</div>
          </div>
        `,
        confirmButtonText: '<i class="bi bi-check-circle-fill me-1"></i> Close',
        confirmButtonColor: '#1B2A6B',
        background: document.documentElement.getAttribute('data-theme') === 'dark' ? '#252A44' : '#ffffff',
        color: document.documentElement.getAttribute('data-theme') === 'dark' ? '#DCE2F4' : '#1A1A2E',
        customClass: { popup: 'rounded-4' }
      });
    }
  });
  
  calendar.render();
});
</script>

<?php include 'includes/footer.php'; ?>
