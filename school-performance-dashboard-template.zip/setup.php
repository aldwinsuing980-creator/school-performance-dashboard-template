<?php
// setup.php — First-Time School Setup Wizard
// This page only loads when setup_complete is NOT set in system_settings.
require_once __DIR__ . '/config/db_connect.php';

// If already set up, redirect to login
if (APP_SETUP_COMPLETE) {
    header('Location: login.php'); exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>School Dashboard Setup Wizard</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: 'Outfit', sans-serif;
  min-height: 100vh;
  background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
  position: relative;
  overflow: hidden;
}
body::before {
  content: '';
  position: fixed;
  width: 600px; height: 600px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(59,130,246,0.12) 0%, transparent 70%);
  top: -200px; left: -200px;
  pointer-events: none;
}
body::after {
  content: '';
  position: fixed;
  width: 500px; height: 500px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(139,92,246,0.1) 0%, transparent 70%);
  bottom: -150px; right: -150px;
  pointer-events: none;
}

.wizard-shell {
  width: 100%;
  max-width: 780px;
  background: rgba(15, 23, 42, 0.85);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 24px;
  backdrop-filter: blur(20px);
  box-shadow: 0 32px 80px rgba(0,0,0,0.5);
  overflow: hidden;
  position: relative;
  z-index: 1;
  animation: slideUp 0.5s ease-out;
}
@keyframes slideUp {
  from { opacity: 0; transform: translateY(30px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* Progress Header */
.wizard-header {
  background: linear-gradient(135deg, #1B2A6B, #2563eb);
  padding: 2rem 2.5rem 1.5rem;
}
.wizard-steps {
  display: flex;
  align-items: center;
  gap: 0;
  margin-top: 1.5rem;
}
.wizard-step {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  position: relative;
  flex: 1;
}
.wizard-step:not(:last-child)::after {
  content: '';
  position: absolute;
  top: 20px;
  left: 50%;
  width: 100%;
  height: 2px;
  background: rgba(255,255,255,0.2);
  z-index: 0;
  transition: background 0.4s;
}
.wizard-step.done:not(:last-child)::after {
  background: rgba(255,255,255,0.7);
}
.step-circle {
  width: 40px; height: 40px;
  border-radius: 50%;
  background: rgba(255,255,255,0.15);
  border: 2px solid rgba(255,255,255,0.3);
  color: rgba(255,255,255,0.6);
  display: flex; align-items: center; justify-content: center;
  font-weight: 700; font-size: 0.95rem;
  position: relative; z-index: 1;
  transition: all 0.3s;
}
.wizard-step.active .step-circle {
  background: #fff;
  border-color: #fff;
  color: #1B2A6B;
  box-shadow: 0 0 0 4px rgba(255,255,255,0.2);
}
.wizard-step.done .step-circle {
  background: #22c55e;
  border-color: #22c55e;
  color: #fff;
}
.step-label {
  font-size: 0.7rem;
  color: rgba(255,255,255,0.5);
  text-align: center;
  font-weight: 500;
  letter-spacing: 0.3px;
}
.wizard-step.active .step-label {
  color: rgba(255,255,255,0.95);
  font-weight: 700;
}
.wizard-step.done .step-label { color: rgba(255,255,255,0.7); }

/* Body */
.wizard-body {
  padding: 2.5rem;
}
.step-pane { display: none; }
.step-pane.active { display: block; animation: fadeStep 0.3s ease; }
@keyframes fadeStep {
  from { opacity: 0; transform: translateX(12px); }
  to   { opacity: 1; transform: translateX(0); }
}

.step-title {
  font-size: 1.6rem;
  font-weight: 800;
  color: #f1f5f9;
  margin-bottom: 0.4rem;
}
.step-sub {
  color: #64748b;
  font-size: 0.95rem;
  margin-bottom: 2rem;
}

.form-label {
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #94a3b8;
  margin-bottom: 0.5rem;
}
.form-control, .form-select {
  background: rgba(30,41,59,0.8);
  border: 1px solid rgba(255,255,255,0.1);
  color: #f1f5f9;
  border-radius: 12px;
  padding: 0.8rem 1.1rem;
  font-family: 'Outfit', sans-serif;
  transition: all 0.2s;
}
.form-control:focus, .form-select:focus {
  background: rgba(30,41,59,0.95);
  border-color: #3b82f6;
  color: #f1f5f9;
  box-shadow: 0 0 0 3px rgba(59,130,246,0.15);
}
.form-control::placeholder { color: #475569; }

/* Color picker row */
.color-row { display: flex; gap: 1rem; align-items: center; }
.color-picker-wrap input[type="color"] {
  width: 52px; height: 48px;
  border-radius: 10px;
  border: 1px solid rgba(255,255,255,0.1);
  padding: 4px;
  cursor: pointer;
  background: rgba(30,41,59,0.8);
}
.preset-dot {
  width: 28px; height: 28px;
  border-radius: 50%;
  border: 2px solid rgba(255,255,255,0.15);
  cursor: pointer;
  flex-shrink: 0;
  transition: transform 0.2s, border-color 0.2s;
}
.preset-dot:hover { transform: scale(1.2); border-color: rgba(255,255,255,0.5); }

/* Logo upload */
.logo-drop {
  border: 2px dashed rgba(255,255,255,0.12);
  border-radius: 16px;
  padding: 2rem;
  text-align: center;
  cursor: pointer;
  transition: all 0.2s;
  color: #64748b;
}
.logo-drop:hover { border-color: #3b82f6; color: #93c5fd; }
.logo-preview-img {
  width: 90px; height: 90px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid rgba(255,255,255,0.15);
  margin: 0 auto 0.75rem;
  display: block;
}

/* Navigation */
.wizard-footer {
  padding: 1.25rem 2.5rem 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-top: 1px solid rgba(255,255,255,0.05);
}
.btn-wiz-back {
  background: transparent;
  border: 1px solid rgba(255,255,255,0.15);
  color: #94a3b8;
  border-radius: 12px;
  padding: 0.75rem 1.5rem;
  font-weight: 600;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.2s;
}
.btn-wiz-back:hover { border-color: rgba(255,255,255,0.3); color: #f1f5f9; }
.btn-wiz-next {
  background: linear-gradient(135deg, #3b82f6, #1d4ed8);
  border: none;
  color: #fff;
  border-radius: 12px;
  padding: 0.75rem 2rem;
  font-weight: 700;
  font-size: 0.95rem;
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 4px 15px rgba(59,130,246,0.3);
}
.btn-wiz-next:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(59,130,246,0.4); }
.btn-wiz-next:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

/* Welcome step */
.welcome-icon {
  width: 80px; height: 80px;
  background: linear-gradient(135deg, #1B2A6B, #2563eb);
  border-radius: 20px;
  display: flex; align-items: center; justify-content: center;
  font-size: 2rem; color: #fff;
  margin-bottom: 1.5rem;
  box-shadow: 0 8px 25px rgba(37,99,235,0.4);
}
.feature-badge {
  background: rgba(59,130,246,0.1);
  border: 1px solid rgba(59,130,246,0.2);
  color: #93c5fd;
  border-radius: 8px;
  padding: 0.6rem 1rem;
  font-size: 0.85rem;
  display: flex;
  align-items: center;
  gap: 0.6rem;
}

/* Done step */
.done-checkmark {
  width: 80px; height: 80px;
  border-radius: 50%;
  background: linear-gradient(135deg, #22c55e, #16a34a);
  display: flex; align-items: center; justify-content: center;
  font-size: 2.5rem; color: #fff;
  margin: 0 auto 1.5rem;
  animation: popIn 0.5s cubic-bezier(0.34,1.56,0.64,1) both;
  box-shadow: 0 8px 25px rgba(34,197,94,0.4);
}
@keyframes popIn {
  from { transform: scale(0); }
  to   { transform: scale(1); }
}

.spinner-overlay {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.6);
  z-index: 9999;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 1rem;
  color: #fff;
  font-size: 1.1rem;
  font-weight: 600;
}
.spinner-overlay.show { display: flex; }
</style>
</head>
<body>

<!-- Loading Spinner -->
<div class="spinner-overlay" id="spinnerOverlay">
  <div class="spinner-border text-light" style="width:3rem;height:3rem;"></div>
  <div>Setting up your dashboard...</div>
</div>

<div class="wizard-shell">

  <!-- Header with Progress -->
  <div class="wizard-header">
    <div class="d-flex align-items-center gap-3">
      <i class="bi bi-speedometer2 fs-2 text-white"></i>
      <div>
        <div class="text-white fw-800 fs-5">School Dashboard Setup</div>
        <div class="text-white-50 small">Complete the steps below to configure your dashboard</div>
      </div>
    </div>
    <div class="wizard-steps mt-4">
      <div class="wizard-step active" id="stepBtn-1"><div class="step-circle">1</div><div class="step-label">Welcome</div></div>
      <div class="wizard-step" id="stepBtn-2"><div class="step-circle">2</div><div class="step-label">School Info</div></div>
      <div class="wizard-step" id="stepBtn-3"><div class="step-circle">3</div><div class="step-label">Admin Account</div></div>
      <div class="wizard-step" id="stepBtn-4"><div class="step-circle">4</div><div class="step-label">Branding</div></div>
      <div class="wizard-step" id="stepBtn-5"><div class="step-circle"><i class="bi bi-check2"></i></div><div class="step-label">Done!</div></div>
    </div>
  </div>

  <!-- Wizard Body -->
  <div class="wizard-body">

    <!-- Step 1: Welcome -->
    <div class="step-pane active" id="step-1">
      <div class="welcome-icon"><i class="bi bi-mortarboard-fill"></i></div>
      <h2 class="step-title">Welcome to your School Dashboard!</h2>
      <p class="step-sub">This wizard will help you set up your analytics dashboard in just a few minutes. Let's get started!</p>
      <div class="d-flex flex-column gap-2">
        <div class="feature-badge"><i class="bi bi-graph-up-arrow text-info"></i>Enrollment & performance analytics</div>
        <div class="feature-badge"><i class="bi bi-building text-warning"></i>Facilities & classroom management</div>
        <div class="feature-badge"><i class="bi bi-people-fill text-success"></i>Human resources tracking</div>
        <div class="feature-badge"><i class="bi bi-palette-fill text-purple" style="color:#a78bfa;"></i>Fully customizable to your school's branding</div>
      </div>
    </div>

    <!-- Step 2: School Info -->
    <div class="step-pane" id="step-2">
      <h2 class="step-title">School Information</h2>
      <p class="step-sub">Tell us about your school. These details will appear throughout the dashboard.</p>
      <div class="row g-3">
        <div class="col-12">
          <label class="form-label">School / Academy Name *</label>
          <input type="text" id="setup_school_name" class="form-control" placeholder="e.g. Juan Luna National High School" required>
        </div>
        <div class="col-12">
          <label class="form-label">School Tagline <span style="font-weight:400;text-transform:none;color:#475569;">(shown on login page)</span></label>
          <input type="text" id="setup_tagline" class="form-control" placeholder="e.g. Empowering Students Through Excellence">
        </div>
        <div class="col-md-6">
          <label class="form-label">DepEd Division</label>
          <input type="text" id="setup_division" class="form-control" placeholder="e.g. Division of Pangasinan II">
        </div>
        <div class="col-md-6">
          <label class="form-label">BEIS School ID</label>
          <input type="text" id="setup_school_id" class="form-control" placeholder="e.g. 300123">
        </div>
        <div class="col-12">
          <label class="form-label">School Address</label>
          <input type="text" id="setup_address" class="form-control" placeholder="e.g. Brgy. Poblacion, Municipality, Province">
        </div>
        <div class="col-12">
          <label class="form-label">Contact Number / Email</label>
          <input type="text" id="setup_contact" class="form-control" placeholder="e.g. 09XX-XXX-XXXX or email@school.edu.ph">
        </div>
        <div class="col-12">
          <label class="form-label">Academic Levels Offered *</label>
          <div class="d-flex flex-wrap gap-4 mt-2 p-3 rounded-3" style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08);">
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="level_kinder" value="kinder">
              <label class="form-check-label text-white small fw-500" for="level_kinder">Kindergarten</label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="level_elem" value="elem">
              <label class="form-check-label text-white small fw-500" for="level_elem">Elementary (G1-G6)</label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="level_jhs" value="jhs" checked>
              <label class="form-check-label text-white small fw-500" for="level_jhs">Junior High (G7-G10)</label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" id="level_shs" value="shs" checked>
              <label class="form-check-label text-white small fw-500" for="level_shs">Senior High (G11-G12)</label>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Step 3: Admin Account -->
    <div class="step-pane" id="step-3">
      <h2 class="step-title">Administrator Account</h2>
      <p class="step-sub">Set up the main admin credentials for this dashboard. You can add more users later.</p>
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Admin Username *</label>
          <input type="text" id="setup_username" class="form-control" placeholder="e.g. admin" value="admin" required>
        </div>
        <div class="col-md-6">
          <label class="form-label">Full Name *</label>
          <input type="text" id="setup_fullname" class="form-control" placeholder="e.g. System Administrator" required>
        </div>
        <div class="col-12">
          <label class="form-label">Email Address</label>
          <input type="email" id="setup_email" class="form-control" placeholder="e.g. admin@school.edu.ph">
        </div>
        <div class="col-md-6">
          <label class="form-label">Password *</label>
          <input type="password" id="setup_password" class="form-control" placeholder="Minimum 6 characters" required minlength="6">
        </div>
        <div class="col-md-6">
          <label class="form-label">Confirm Password *</label>
          <input type="password" id="setup_password2" class="form-control" placeholder="Re-enter password" required>
        </div>
      </div>
    </div>

    <!-- Step 4: Branding -->
    <div class="step-pane" id="step-4">
      <h2 class="step-title">Branding & Theme</h2>
      <p class="step-sub">Customize the dashboard to match your school's colors. You can always change this later in Settings.</p>

      <div class="mb-4">
        <label class="form-label">School Logo</label>
        <div class="logo-drop" id="logoDrop" onclick="document.getElementById('setup_logo_file').click()">
          <img id="setup_logo_preview" src="assets/img/school-logo.png" onerror="this.style.display='none'" class="logo-preview-img">
          <i class="bi bi-cloud-arrow-up fs-2 d-block mb-2"></i>
          <div class="fw-600" style="color:#94a3b8;">Click to upload your school logo</div>
          <div class="small mt-1" style="color:#475569;">PNG, JPG, JPEG up to 2MB</div>
        </div>
        <input type="file" id="setup_logo_file" accept="image/png,image/jpeg,image/jpg" class="d-none" onchange="previewSetupLogo(event)">
      </div>

      <div class="mb-3">
        <label class="form-label">Primary Theme Color</label>
        <div class="color-row">
          <div class="color-picker-wrap">
            <input type="color" id="setup_primary_color" value="#1B2A6B" oninput="syncSetupColor(this.value)">
          </div>
          <input type="text" id="setup_primary_hex" class="form-control" style="max-width:130px;font-family:monospace;" value="#1B2A6B" oninput="if(/^#[0-9A-Fa-f]{6}$/.test(this.value))document.getElementById('setup_primary_color').value=this.value;">
          <div class="d-flex gap-2 flex-wrap">
            <?php
            $presets2 = ['#1B2A6B','#0F4C81','#065F46','#7C3AED','#B91C1C','#0E7490','#92400E','#1F2937'];
            foreach ($presets2 as $c): ?>
            <div class="preset-dot" style="background:<?= $c ?>;" onclick="applySetupPreset('<?= $c ?>')" title="<?= $c ?>"></div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <div class="mb-3">
        <label class="form-label">Accent / Secondary Color</label>
        <div class="color-row">
          <div class="color-picker-wrap">
            <input type="color" id="setup_secondary_color" value="#C9A227">
          </div>
          <input type="text" id="setup_secondary_hex" class="form-control" style="max-width:130px;font-family:monospace;" value="#C9A227" oninput="if(/^#[0-9A-Fa-f]{6}$/.test(this.value))document.getElementById('setup_secondary_color').value=this.value;">
        </div>
      </div>
    </div>

    <!-- Step 5: Done -->
    <div class="step-pane" id="step-5">
      <div style="text-align:center; padding: 2rem 0;">
        <div class="done-checkmark">✓</div>
        <h2 class="step-title" style="text-align:center;">You're all set!</h2>
        <p class="step-sub" style="text-align:center; max-width:400px; margin: 0 auto 2rem;">Your school dashboard has been successfully configured. Click the button below to launch it!</p>
        <div id="summaryBox" style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:1.25rem;text-align:left;font-size:0.9rem;color:#94a3b8;max-width:400px;margin:0 auto;">
          Loading summary...
        </div>
      </div>
    </div>

  </div><!-- /wizard-body -->

  <!-- Footer Navigation -->
  <div class="wizard-footer">
    <button class="btn-wiz-back" id="btnBack" onclick="prevStep()" style="visibility:hidden;">
      <i class="bi bi-arrow-left me-2"></i>Back
    </button>
    <div style="color:#475569;font-size:0.8rem;">Step <span id="currentStepNum">1</span> of 4</div>
    <button class="btn-wiz-next" id="btnNext" onclick="nextStep()">
      Get Started <i class="bi bi-arrow-right ms-2"></i>
    </button>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
let currentStep = 1;
const totalSteps = 5;
let logoFile = null;

function showStep(step) {
  document.querySelectorAll('.step-pane').forEach(p => p.classList.remove('active'));
  document.getElementById('step-' + step).classList.add('active');

  for (let i = 1; i <= totalSteps; i++) {
    const btn = document.getElementById('stepBtn-' + i);
    btn.classList.remove('active', 'done');
    if (i < step) btn.classList.add('done');
    if (i === step) btn.classList.add('active');
  }

  document.getElementById('btnBack').style.visibility = step === 1 ? 'hidden' : 'visible';
  const nextBtn = document.getElementById('btnNext');
  document.getElementById('currentStepNum').innerText = Math.min(step, 4);

  if (step === totalSteps) {
    nextBtn.innerHTML = '<i class="bi bi-rocket-takeoff me-2"></i>Launch Dashboard';
    nextBtn.onclick = launchDashboard;
    buildSummary();
  } else {
    nextBtn.innerHTML = 'Continue <i class="bi bi-arrow-right ms-2"></i>';
    nextBtn.onclick = nextStep;
  }
}

function nextStep() {
  if (!validateStep(currentStep)) return;
  if (currentStep < totalSteps) {
    currentStep++;
    showStep(currentStep);
  }
}

function prevStep() {
  if (currentStep > 1) {
    currentStep--;
    showStep(currentStep);
  }
}

function validateStep(step) {
  if (step === 2) {
    const name = document.getElementById('setup_school_name').value.trim();
    if (!name) { Swal.fire({ icon:'warning', title:'School name required', text:'Please enter your school name.', background:'#1e293b', color:'#f1f5f9', confirmButtonColor:'#3b82f6' }); return false; }
    
    // Validate at least one level checked
    const offered = [];
    if (document.getElementById('level_kinder').checked) offered.push('kinder');
    if (document.getElementById('level_elem').checked) offered.push('elem');
    if (document.getElementById('level_jhs').checked) offered.push('jhs');
    if (document.getElementById('level_shs').checked) offered.push('shs');
    if (offered.length === 0) {
      Swal.fire({ icon:'warning', title:'Select Levels Offered', text:'Please select at least one grade level offered by your school.', background:'#1e293b', color:'#f1f5f9', confirmButtonColor:'#3b82f6' });
      return false;
    }
  }
  if (step === 3) {
    const u = document.getElementById('setup_username').value.trim();
    const fn = document.getElementById('setup_fullname').value.trim();
    const p1 = document.getElementById('setup_password').value;
    const p2 = document.getElementById('setup_password2').value;
    if (!u || !fn) { Swal.fire({ icon:'warning', title:'Required fields', text:'Username and Full Name are required.', background:'#1e293b', color:'#f1f5f9', confirmButtonColor:'#3b82f6' }); return false; }
    if (p1.length < 6) { Swal.fire({ icon:'warning', title:'Weak password', text:'Password must be at least 6 characters.', background:'#1e293b', color:'#f1f5f9', confirmButtonColor:'#3b82f6' }); return false; }
    if (p1 !== p2) { Swal.fire({ icon:'error', title:'Passwords do not match', text:'Please make sure both passwords are the same.', background:'#1e293b', color:'#f1f5f9', confirmButtonColor:'#3b82f6' }); return false; }
  }
  return true;
}

function buildSummary() {
  const name = document.getElementById('setup_school_name').value || '—';
  const div  = document.getElementById('setup_division').value || '—';
  const user = document.getElementById('setup_username').value || 'admin';
  const color= document.getElementById('setup_primary_color').value;
  
  const offered = [];
  if (document.getElementById('level_kinder').checked) offered.push('Kindergarten');
  if (document.getElementById('level_elem').checked) offered.push('Elementary');
  if (document.getElementById('level_jhs').checked) offered.push('Junior High');
  if (document.getElementById('level_shs').checked) offered.push('Senior High');

  document.getElementById('summaryBox').innerHTML = `
    <div class="d-flex flex-column gap-2">
      <div><strong style="color:#f1f5f9;">🏫 School:</strong> ${name}</div>
      <div><strong style="color:#f1f5f9;">📋 Division:</strong> ${div}</div>
      <div><strong style="color:#f1f5f9;">👤 Admin User:</strong> ${user}</div>
      <div><strong style="color:#f1f5f9;">🎓 Levels:</strong> ${offered.join(', ')}</div>
      <div class="d-flex align-items-center gap-2"><strong style="color:#f1f5f9;">🎨 Theme:</strong>
        <span style="display:inline-block;width:18px;height:18px;border-radius:4px;background:${color};border:1px solid rgba(255,255,255,0.2);"></span> ${color}</div>
    </div>`;
}

async function launchDashboard() {
  document.getElementById('spinnerOverlay').classList.add('show');
  
  const offered = [];
  if (document.getElementById('level_kinder').checked) offered.push('kinder');
  if (document.getElementById('level_elem').checked) offered.push('elem');
  if (document.getElementById('level_jhs').checked) offered.push('jhs');
  if (document.getElementById('level_shs').checked) offered.push('shs');

  const formData = new FormData();
  formData.append('school_name',       document.getElementById('setup_school_name').value.trim());
  formData.append('school_tagline',    document.getElementById('setup_tagline').value.trim());
  formData.append('school_division',   document.getElementById('setup_division').value.trim());
  formData.append('school_id',         document.getElementById('setup_school_id').value.trim());
  formData.append('school_address',    document.getElementById('setup_address').value.trim());
  formData.append('school_contact',    document.getElementById('setup_contact').value.trim());
  formData.append('offered_levels',    offered.join(','));
  formData.append('admin_username',    document.getElementById('setup_username').value.trim());
  formData.append('admin_fullname',    document.getElementById('setup_fullname').value.trim());
  formData.append('admin_email',       document.getElementById('setup_email').value.trim());
  formData.append('admin_password',    document.getElementById('setup_password').value);
  formData.append('primary_color',     document.getElementById('setup_primary_color').value);
  formData.append('secondary_color',   document.getElementById('setup_secondary_color').value);
  if (logoFile) formData.append('school_logo', logoFile);

  try {
    const r = await fetch('ajax/setup_crud.php', { method:'POST', body: formData });
    const res = await r.json();
    document.getElementById('spinnerOverlay').classList.remove('show');
    if (res.success) {
      Swal.fire({
        icon: 'success',
        title: 'Dashboard Ready! 🚀',
        text: 'Redirecting you to the login page...',
        timer: 2000,
        showConfirmButton: false,
        background: '#1e293b',
        color: '#f1f5f9'
      }).then(() => { window.location.href = 'login.php'; });
    } else {
      Swal.fire({ icon:'error', title:'Setup Failed', text: res.message || 'Unknown error.', background:'#1e293b', color:'#f1f5f9', confirmButtonColor:'#3b82f6' });
    }
  } catch (e) {
    document.getElementById('spinnerOverlay').classList.remove('show');
    Swal.fire({ icon:'error', title:'Server Error', text:'Could not connect to the server.', background:'#1e293b', color:'#f1f5f9', confirmButtonColor:'#3b82f6' });
  }
}

function previewSetupLogo(event) {
  const file = event.target.files[0];
  if (!file) return;
  logoFile = file;
  const reader = new FileReader();
  reader.onload = e => {
    const img = document.getElementById('setup_logo_preview');
    img.src = e.target.result;
    img.style.display = 'block';
  };
  reader.readAsDataURL(file);
}

function syncSetupColor(hex) {
  document.getElementById('setup_primary_hex').value = hex;
}

function applySetupPreset(hex) {
  document.getElementById('setup_primary_color').value = hex;
  document.getElementById('setup_primary_hex').value = hex;
}

document.getElementById('setup_secondary_color').addEventListener('input', function() {
  document.getElementById('setup_secondary_hex').value = this.value;
});
</script>
</body>
</html>
