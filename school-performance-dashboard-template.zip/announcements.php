<?php
require_once __DIR__ . '/config/session.php';
require_login();

$page_title = 'Announcements';
$breadcrumb = 'School Board';

// Fetch announcements based on user role
// Admins/Encoders can see inactive ones; regular users can only see active ones
if (has_role('Admin', 'Encoder', 'Faculty')) {
    $q = $pdo->query("SELECT * FROM announcements ORDER BY created_at DESC");
} else {
    $today = date('Y-m-d');
    $q = $pdo->prepare("
        SELECT * FROM announcements 
        WHERE is_active = 1 
          AND (end_date IS NULL OR end_date >= ?)
        ORDER BY category = 'suspension' DESC, created_at DESC
    ");
    $q->execute([$today]);
}
$announcements = $q->fetchAll();

include 'includes/header.php';
?>
<style>
/* --- Color Palette & Glassmorphism Tokens --- */
:root {
  --glow-blue: 27, 42, 107;
  --glow-gold: 201, 162, 39;
  --glow-red: 220, 38, 38;
  --text-rgb: 26, 26, 46;
}
[data-theme="dark"] {
  --glow-blue: 107, 155, 232;
  --glow-gold: 240, 202, 118;
  --glow-red: 245, 160, 160;
  --text-rgb: 220, 226, 244;
}

.glass-panel-announcements {
  background: rgba(255, 255, 255, 0.55);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.4);
  border-radius: 16px;
  box-shadow: 0 8px 32px rgba(27, 42, 107, 0.05);
  transition: var(--transition);
}
[data-theme="dark"] .glass-panel-announcements {
  background: rgba(37, 42, 68, 0.45);
  border: 1px solid rgba(255, 255, 255, 0.06);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.22);
}

/* --- Premium Navigation Tab Pills --- */
.ann-nav-pills {
  background: var(--surface);
  border: 1px solid var(--border);
  padding: 6px;
  border-radius: 14px;
  display: inline-flex;
  gap: 4px;
  box-shadow: var(--shadow);
}
.ann-nav-pills .nav-link {
  color: var(--text-muted);
  font-weight: 500;
  font-size: .85rem;
  border-radius: 10px;
  padding: 8px 22px;
  border: none !important;
  background: transparent;
  transition: var(--transition);
}
.ann-nav-pills .nav-link:hover {
  color: var(--accent);
  background: var(--bg);
}
.ann-nav-pills .nav-link.active {
  background: var(--primary) !important;
  color: #ffffff !important;
  font-weight: 600;
}
[data-theme="dark"] .ann-nav-pills .nav-link.active {
  background: var(--accent) !important;
  color: var(--primary-dark) !important;
}

/* --- Announcement Cards & Styling --- */
.ann-card {
  position: relative;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 24px;
  box-shadow: var(--shadow);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
.ann-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 5px;
  height: 100%;
  background: var(--card-border-color, var(--primary));
  opacity: 0.85;
}
.ann-card:hover {
  transform: translateY(-4px);
  box-shadow: var(--shadow-md), 0 10px 24px rgba(var(--card-glow-rgb, var(--glow-blue)), 0.08);
}
.ann-card.inactive {
  opacity: 0.65;
  border-style: dashed;
}
.ann-card.inactive::before {
  background: var(--text-muted);
}

.ann-card.suspension {
  --card-border-color: rgb(var(--glow-red));
  --card-glow-rgb: var(--glow-red);
}
.ann-card.event {
  --card-border-color: rgb(var(--glow-gold));
  --card-glow-rgb: var(--glow-gold);
}
.ann-card.general {
  --card-border-color: rgb(var(--glow-blue));
  --card-glow-rgb: var(--glow-blue);
}

.ann-icon-badge {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.25rem;
}
.suspension .ann-icon-badge {
  background: rgba(220, 38, 38, 0.08);
  color: #dc2626;
}
.event .ann-icon-badge {
  background: rgba(201, 162, 39, 0.1);
  color: #c9a227;
}
.general .ann-icon-badge {
  background: rgba(27, 42, 107, 0.07);
  color: #1b2a6b;
}
[data-theme="dark"] .general .ann-icon-badge {
  background: rgba(107, 155, 232, 0.15);
  color: #6b9be8;
}

.ann-badge-aesthetic {
  font-size: 0.68rem;
  font-weight: 600;
  padding: 4px 10px;
  border-radius: 99px;
  text-transform: uppercase;
}
.ann-badge-aesthetic.suspension {
  background: rgba(220, 38, 38, 0.08) !important;
  color: #dc2626 !important;
  border: 1px solid rgba(220, 38, 38, 0.2) !important;
}
.ann-badge-aesthetic.event {
  background: rgba(201, 162, 39, 0.1) !important;
  color: #c9a227 !important;
  border: 1px solid rgba(201, 162, 39, 0.25) !important;
}
.ann-badge-aesthetic.general {
  background: rgba(27, 42, 107, 0.07) !important;
  color: #1b2a6b !important;
  border: 1px solid rgba(27, 42, 107, 0.15) !important;
}
[data-theme="dark"] .ann-badge-aesthetic.general {
  background: rgba(107, 155, 232, 0.15) !important;
  color: #6b9be8 !important;
  border: 1px solid rgba(107, 155, 232, 0.25) !important;
}

/* Switch Styling */
.switch-container {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.custom-switch {
  position: relative;
  display: inline-block;
  width: 38px;
  height: 20px;
}
.custom-switch input {
  opacity: 0;
  width: 0;
  height: 0;
}
.slider {
  position: absolute;
  cursor: pointer;
  top: 0; left: 0; right: 0; bottom: 0;
  background-color: var(--border);
  transition: .3s;
  border-radius: 20px;
}
.slider:before {
  position: absolute;
  content: "";
  height: 14px; width: 14px;
  left: 3px; bottom: 3px;
  background-color: white;
  transition: .3s;
  border-radius: 50%;
}
input:checked + .slider {
  background-color: var(--primary);
}
input:checked + .slider:before {
  transform: translateX(18px);
}
</style>

<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
  <div class="section-header mb-0">
    <h1 class="section-title"><i class="bi bi-megaphone-fill me-2 text-primary-nhs"></i>School Announcements</h1>
    <p class="section-sub">Stay informed with class schedules, announcements, and events</p>
  </div>
  <div class="d-flex gap-2">
    <?php if(has_role('Admin','Encoder','Faculty')): ?>
    <button class="btn-primary-nhs" data-bs-toggle="modal" data-bs-target="#announcementModal" onclick="openAddModal()">
      <i class="bi bi-plus-circle"></i> Create Announcement
    </button>
    <?php endif; ?>
  </div>
</div>

<!-- Glassmorphic Filter & Search Panel -->
<div class="glass-panel-announcements p-4 mb-4">
  <div class="row align-items-center g-3">
    <div class="col-md-7">
      <ul class="nav ann-nav-pills" id="announcementFilters" role="tablist">
        <li class="nav-item">
          <button class="nav-link active" onclick="filterCategory('all')">
            <i class="bi bi-grid-fill me-1"></i> All
          </button>
        </li>
        <li class="nav-item">
          <button class="nav-link" onclick="filterCategory('suspension')">
            <i class="bi bi-cloud-rain-heavy-fill me-1"></i> Class Suspensions
          </button>
        </li>
        <li class="nav-item">
          <button class="nav-link" onclick="filterCategory('event')">
            <i class="bi bi-calendar-event-fill me-1"></i> Events
          </button>
        </li>
        <li class="nav-item">
          <button class="nav-link" onclick="filterCategory('general')">
            <i class="bi bi-info-circle-fill me-1"></i> General
          </button>
        </li>
      </ul>
    </div>
    <div class="col-md-5">
      <div class="d-flex gap-2">
        <input type="text" id="announcementSearch" class="form-control" placeholder="Search announcements..." style="border-radius:12px; height:44px;">
      </div>
    </div>
  </div>
</div>

<!-- Announcements Grid -->
<div class="row g-4" id="announcementsContainer">
  <?php foreach ($announcements as $ann): 
    $cat_icon = 'bi-info-circle';
    if ($ann['category'] === 'suspension') $cat_icon = 'bi-exclamation-triangle-fill';
    elseif ($ann['category'] === 'event') $cat_icon = 'bi-calendar2-event-fill';
    
    $inactive_cls = $ann['is_active'] ? '' : 'inactive';
    $formatted_date = date('F d, Y - h:i A', strtotime($ann['created_at']));
    $date_span = '';
    if (!empty($ann['start_date']) || !empty($ann['end_date'])) {
        $start = !empty($ann['start_date']) ? date('M d, Y', strtotime($ann['start_date'])) : '—';
        $end = !empty($ann['end_date']) ? date('M d, Y', strtotime($ann['end_date'])) : '—';
        $date_span = "<div class='text-muted small mt-2'><i class='bi bi-calendar-range me-1'></i> Active Period: <strong>{$start}</strong> to <strong>{$end}</strong></div>";
    }
  ?>
  <div class="col-md-6 col-lg-4 ann-item" data-category="<?= $ann['category'] ?>" data-search-target="<?= strtolower($ann['title'] . ' ' . $ann['content']) ?>">
    <div class="ann-card <?= $ann['category'] ?> <?= $inactive_cls ?> h-100">
      <div class="d-flex justify-content-between align-items-start mb-3">
        <div class="ann-icon-badge">
          <i class="bi <?= $cat_icon ?>"></i>
        </div>
        <div class="d-flex align-items-center gap-2">
          <span class="ann-badge-aesthetic <?= $ann['category'] ?>"><?= ucfirst($ann['category']) ?></span>
          <?php if (!$ann['is_active']): ?>
          <span class="badge bg-secondary text-white small rounded-pill px-2 py-1">Draft</span>
          <?php endif; ?>
        </div>
      </div>
      
      <div class="flex-grow-1">
        <h5 class="fw-750 mb-1" style="color: var(--text);"><?= htmlspecialchars($ann['title']) ?></h5>
        <span class="text-muted small d-block font-monospace"><i class="bi bi-clock me-1"></i><?= $formatted_date ?></span>
        <p class="mt-3 text-muted" style="line-height:1.55; font-size:0.9rem; white-space: pre-wrap;"><?= htmlspecialchars($ann['content']) ?></p>
        <?= $date_span ?>
      </div>

      <?php if(has_role('Admin','Encoder','Faculty')): ?>
      <div class="mt-4 pt-3 border-top border-light border-opacity-10 d-flex justify-content-between align-items-center">
        <div class="switch-container">
          <label class="custom-switch">
            <input type="checkbox" <?= $ann['is_active'] ? 'checked' : '' ?> onchange="toggleAnnouncementStatus(<?= $ann['id'] ?>, this.checked)">
            <span class="slider"></span>
          </label>
          <span class="small text-muted font-monospace">Active</span>
        </div>
        <div>
          <button class="btn btn-sm btn-outline-primary me-1" style="border-radius:8px;" onclick="editAnnouncement(<?= htmlspecialchars(json_encode($ann)) ?>)">
            <i class="bi bi-pencil"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger" style="border-radius:8px;" onclick="deleteAnnouncement(<?= $ann['id'] ?>)">
            <i class="bi bi-trash"></i>
          </button>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
  
  <?php if (empty($announcements)): ?>
  <div class="col-12" id="noAnnouncementsPlaceholder">
    <div class="glass-panel-announcements p-5 text-center py-5 text-muted">
      <i class="bi bi-clipboard-x-fill display-4 text-muted"></i>
      <h4 class="mt-3 fw-700">No Announcements Boarded</h4>
      <p class="mb-0">Check back later for school activities and event schedules.</p>
    </div>
  </div>
  <?php endif; ?>
</div>

<!-- CRUD MODAL (Only for Admin/Encoder) -->
<?php if(has_role('Admin','Encoder','Faculty')): ?>
<div class="modal fade" id="announcementModal" tabindex="-1" aria-labelledby="announcementModalTitle">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="announcementModalTitle"><i class="bi bi-plus-circle me-2"></i>Create Announcement</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form id="announcementForm" onsubmit="submitAnnouncement(event)">
        <div class="modal-body">
          <input type="hidden" id="annId" name="id">
          <input type="hidden" name="action" id="annAction" value="add">
          
          <div class="row g-3">
            <div class="col-md-8">
              <label class="form-label fw-600">Announcement Title *</label>
              <input type="text" name="title" id="fTitle" class="form-control" placeholder="e.g. Typhoon Alert: Classes Suspended" required style="border-radius:10px;">
            </div>
            <div class="col-md-4">
              <label class="form-label fw-600">Category *</label>
              <select name="category" id="fCategory" class="form-select" required style="border-radius:10px;">
                <option value="general">📢 General Notice</option>
                <option value="suspension">🌧️ Class Suspension</option>
                <option value="event">🏆 School Event / Activity</option>
              </select>
            </div>
            
            <div class="col-12">
              <label class="form-label fw-600">Content / Details *</label>
              <textarea name="content" id="fContent" class="form-control" rows="5" placeholder="Write full details about the notice..." required style="border-radius:10px;"></textarea>
            </div>
            
            <div class="col-md-6">
              <label class="form-label fw-600">Active Start Date <span class="text-muted">(Optional)</span></label>
              <input type="date" name="start_date" id="fStartDate" class="form-control" style="border-radius:10px;">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-600">Active End Date <span class="text-muted">(Optional)</span></label>
              <input type="date" name="end_date" id="fEndDate" class="form-control" style="border-radius:10px;">
            </div>
            
            <div class="col-12">
              <div class="form-check form-switch mt-2">
                <input class="form-check-input" type="checkbox" name="is_active" id="fIsActive" value="1" checked>
                <label class="form-check-label fw-600" for="fIsActive">Publish immediately (Active)</label>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" style="border-radius:10px;" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn-primary-nhs"><i class="bi bi-save me-1"></i>Save Announcement</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
// Filter category buttons
let currentFilter = 'all';
function filterCategory(cat) {
  currentFilter = cat;
  
  // Update UI active buttons
  document.querySelectorAll('#announcementFilters button').forEach(btn => {
    btn.classList.remove('active');
  });
  event.currentTarget.classList.add('active');
  
  applyFilters();
}

// Search field filtering
document.getElementById('announcementSearch').addEventListener('input', function() {
  applyFilters();
});

// Primary filter engine
function applyFilters() {
  const query = document.getElementById('announcementSearch').value.toLowerCase();
  let visibleCount = 0;
  
  document.querySelectorAll('.ann-item').forEach(item => {
    const category = item.dataset.category;
    const searchText = item.dataset.searchTarget;
    
    const matchesCategory = (currentFilter === 'all' || category === currentFilter);
    const matchesSearch = searchText.includes(query);
    
    if (matchesCategory && matchesSearch) {
      item.style.display = '';
      visibleCount++;
    } else {
      item.style.display = 'none';
    }
  });
  
  // Show/hide placeholder if nothing matches
  const placeholder = document.getElementById('noAnnouncementsPlaceholder');
  if (visibleCount === 0) {
    if (!placeholder) {
      const container = document.getElementById('announcementsContainer');
      const emptyDiv = document.createElement('div');
      emptyDiv.id = 'noAnnouncementsPlaceholder';
      emptyDiv.className = 'col-12';
      emptyDiv.innerHTML = `
        <div class="glass-panel-announcements p-5 text-center py-5 text-muted">
          <i class="bi bi-clipboard-x-fill display-4 text-muted"></i>
          <h4 class="mt-3 fw-700">No Announcements Found</h4>
          <p class="mb-0">Try adjusting your filters or search query.</p>
        </div>
      `;
      container.appendChild(emptyDiv);
    } else {
      placeholder.style.display = '';
    }
  } else if (placeholder) {
    placeholder.style.display = 'none';
  }
}

// Dialog management
function openAddModal() {
  document.getElementById('announcementModalTitle').innerHTML = '<i class="bi bi-plus-circle me-2"></i>Create Announcement';
  document.getElementById('annAction').value = 'add';
  document.getElementById('annId').value = '';
  document.getElementById('announcementForm').reset();
  document.getElementById('fIsActive').checked = true;
}

function editAnnouncement(row) {
  document.getElementById('announcementModalTitle').innerHTML = '<i class="bi bi-pencil me-2"></i>Edit Announcement';
  document.getElementById('annAction').value = 'edit';
  document.getElementById('annId').value = row.id;
  document.getElementById('fTitle').value = row.title;
  document.getElementById('fCategory').value = row.category;
  document.getElementById('fContent').value = row.content;
  document.getElementById('fStartDate').value = row.start_date || '';
  document.getElementById('fEndDate').value = row.end_date || '';
  document.getElementById('fIsActive').checked = parseInt(row.is_active) === 1;
  
  new bootstrap.Modal(document.getElementById('announcementModal')).show();
}

async function submitAnnouncement(e) {
  e.preventDefault();
  const fd = new FormData(e.target);
  const data = Object.fromEntries(fd);
  
  // Format switch checkbox value
  data.is_active = document.getElementById('fIsActive').checked ? 1 : 0;
  
  showSpinner();
  try {
    const r = await fetch('ajax/announcements_crud.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const res = await r.json();
    hideSpinner();
    
    if (res.success) {
      toastSuccess(res.message);
      bootstrap.Modal.getInstance(document.getElementById('announcementModal'))?.hide();
      setTimeout(() => location.reload(), 800);
    } else {
      toastError(res.message || 'Error occurred');
    }
  } catch (err) {
    hideSpinner();
    toastError('Server request failed.');
  }
}

async function toggleAnnouncementStatus(id, isChecked) {
  const is_active = isChecked ? 1 : 0;
  try {
    const r = await fetch('ajax/announcements_crud.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'toggle_active', id, is_active })
    });
    const res = await r.json();
    if (res.success) {
      toastSuccess(res.message);
      // Toggle card opacity class
      const card = event.target.closest('.ann-card');
      if (isChecked) {
        card.classList.remove('inactive');
      } else {
        card.classList.add('inactive');
      }
    } else {
      toastError(res.message);
      event.target.checked = !isChecked; // Revert checkbox if error
    }
  } catch (err) {
    toastError('Network operation failed.');
    event.target.checked = !isChecked;
  }
}

function deleteAnnouncement(id) {
  confirmAction("Are you sure you want to delete this announcement? This action is permanent.")
    .then(r => {
      if (!r.isConfirmed) return;
      showSpinner();
      fetch('ajax/announcements_crud.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', id })
      })
      .then(r => r.json())
      .then(res => {
        hideSpinner();
        if (res.success) {
          toastSuccess(res.message);
          setTimeout(() => location.reload(), 800);
        } else {
          toastError(res.message);
        }
      })
      .catch(() => {
        hideSpinner();
        toastError('Server operation failed.');
      });
    });
}
</script>

<?php include 'includes/footer.php'; ?>
