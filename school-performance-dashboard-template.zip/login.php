<?php
// Prevent caching during development
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

require_once __DIR__ . '/config/session.php';
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php'); exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = clean($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($username && $password) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            if (isset($user['status']) && $user['status'] === 'Pending') {
                $error = 'Your account is pending Admin approval. Please wait for an administrator to approve your access.';
            } else {
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['username']  = $user['username'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['user_role'] = $user['role'];
                log_activity($pdo, $user['id'], "User '{$user['username']}' logged in.", 'Auth');
                header('Location: dashboard.php'); exit;
            }
        } else {
            $error = 'Invalid username or password.';
        }
    } else {
        $error = 'Please fill in all fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<title><?= htmlspecialchars(APP_NAME) ?> - Portal</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Outfit', sans-serif;
    min-height: 100vh;
    background-color: #f4f7f6;
    display: flex;
  }
  
  /* Split Screen Layout */
  .hero-section {
    flex: 1.2;
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 4rem;
    color: white;
    position: relative;
    overflow: hidden;
  }

  .hero-section::before {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background: url('assets/img/school-bg.jpg?v=<?= time() ?>') center bottom/cover no-repeat;
      transform: scale(1.22) translateY(4%);
      z-index: 0;
  }

  .hero-section::after {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background: linear-gradient(135deg, rgba(15, 76, 129, 0.45) 0%, rgba(9, 52, 87, 0.55) 100%);
      z-index: 0;
  }



  .hero-content {
      position: relative;
      z-index: 1;
      animation: fadeIn 1s ease-out;
  }

  .school-logo {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      border: 4px solid rgba(255, 255, 255, 0.3);
      margin-bottom: 1.5rem;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      backdrop-filter: blur(4px);
  }

  .hero-title {
      font-size: 3.5rem;
      font-weight: 700;
      line-height: 1.2;
      margin-bottom: 1rem;
      text-shadow: 0 4px 15px rgba(0,0,0,0.6);
  }

  .hero-subtitle {
      font-size: 1.2rem;
      font-weight: 300;
      opacity: 0.95;
      max-width: 80%;
      line-height: 1.6;
      text-shadow: 0 2px 8px rgba(0,0,0,0.5);
  }

  .login-section {
    flex: 0.8;
    background: #ffffff;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem;
    box-shadow: -10px 0 30px rgba(0,0,0,0.05);
    z-index: 2;
  }

  .login-card {
    width: 100%;
    max-width: 420px;
  }

  .login-header {
      margin-bottom: 2.5rem;
  }

  .login-header h2 {
      font-weight: 700;
      color: #0F4C81;
      font-size: 2rem;
      margin-bottom: 0.5rem;
  }

  .login-header p {
      color: #6c757d;
      font-size: 0.95rem;
  }

  .form-control {
    border: 1.5px solid #e2e8f0;
    border-radius: 12px;
    padding: 0.8rem 1.2rem;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    background-color: #f8fafc;
  }

  .form-control:focus {
    border-color: #0F4C81;
    background-color: #ffffff;
    box-shadow: 0 0 0 4px rgba(15, 76, 129, 0.1);
  }

  .input-group-text {
    background: #f8fafc;
    border: 1.5px solid #e2e8f0;
    border-right: none;
    border-radius: 12px 0 0 12px;
    color: #64748b;
  }

  .form-control {
      border-left: none;
  }
  
  .form-control:focus + .input-group-text,
  .input-group-text:has(+ .form-control:focus) {
      border-color: #0F4C81;
      color: #0F4C81;
  }

  .password-toggle {
      border-left: none;
      background: #f8fafc;
      border-radius: 0 12px 12px 0 !important;
      color: #64748b;
  }

  label {
    font-size: 0.85rem;
    font-weight: 600;
    color: #475569;
    margin-bottom: 0.5rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .btn-login {
    background: linear-gradient(135deg, #0F4C81, #093457);
    border: none;
    border-radius: 12px;
    padding: 0.9rem;
    font-weight: 600;
    font-size: 1rem;
    letter-spacing: 0.5px;
    transition: all 0.3s;
    box-shadow: 0 8px 20px rgba(15, 76, 129, 0.2);
    margin-top: 1rem;
  }

  .btn-login:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 25px rgba(15, 76, 129, 0.3);
  }

  .divider {
      display: flex;
      align-items: center;
      text-align: center;
      margin: 2rem 0;
      color: #cbd5e1;
  }
  .divider::before, .divider::after {
      content: '';
      flex: 1;
      border-bottom: 1px solid #e2e8f0;
  }
  .divider span {
      padding: 0 10px;
      font-size: 0.85rem;
  }

  .register-link {
    color: #0F4C81;
    font-weight: 600;
    text-decoration: none;
    transition: 0.2s;
  }

  .register-link:hover {
    color: #093457;
    text-decoration: underline;
  }

  @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
  }

  /* Responsive styling */
  @media (max-width: 992px) {
      body {
          flex-direction: column;
      }
      .hero-section {
          flex: none;
          padding: 3rem 2rem;
          min-height: 40vh;
      }
      .hero-title {
          font-size: 2.5rem;
      }
      .login-section {
          flex: 1;
          border-radius: 30px 30px 0 0;
          margin-top: -30px;
      }
  }
</style>
</head>
<body>

<div class="hero-section">
    <div class="hero-content">
        <img src="<?= htmlspecialchars(APP_LOGO) ?>" onerror="this.src='https://ui-avatars.com/api/?name=Branding&background=fff&color=0F4C81&size=100'" alt="Branding Logo" class="school-logo" style="object-fit: cover;">
        <h1 class="hero-title"><?= htmlspecialchars(APP_NAME) ?></h1>
        <p class="hero-subtitle"><?= htmlspecialchars(APP_TAGLINE) ?></p>
    </div>
</div>

<div class="login-section">
  <div class="login-card">
    <div class="login-header">
      <h2>Welcome Back</h2>
      <p>Please enter your credentials to access the system.</p>
    </div>
    
    <form method="POST" id="loginForm">
      <div class="mb-4">
        <label for="username">Username</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-person"></i></span>
          <input type="text" id="username" name="username" class="form-control" placeholder="admin" required autocomplete="username">
        </div>
      </div>
      
      <div class="mb-4">
        <label for="password">Password</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-lock"></i></span>
          <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" required autocomplete="current-password">
          <button type="button" class="btn btn-outline-secondary border password-toggle" onclick="togglePwd()">
            <i class="bi bi-eye" id="eyeIcon"></i>
          </button>
        </div>
      </div>
      
      <button type="submit" class="btn btn-login btn-primary w-100 text-white">
        Sign In <i class="bi bi-arrow-right ms-2"></i>
      </button>
    </form>
    
    <div class="divider"><span>OR</span></div>
    
    <p class="text-center text-muted mb-0" style="font-size: 0.9rem;">
      Don't have an account? <a href="register.php" class="register-link">Request Access</a>
    </p>
    <p class="text-center mt-4 mb-0" style="font-size: 0.75rem; color: #94a3b8;">
      <i class="bi bi-shield-lock me-1"></i>Secured System — Authorized Personnel Only
    </p>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function togglePwd(){
  const p = document.getElementById('password');
  const e = document.getElementById('eyeIcon');
  if (p.type === 'password') {
      p.type = 'text';
      e.className = 'bi bi-eye-slash';
  } else {
      p.type = 'password';
      e.className = 'bi bi-eye';
  }
}

<?php if($error): ?>
Swal.fire({
    icon: 'error',
    title: 'Authentication Failed',
    text: <?= json_encode($error) ?>,
    confirmButtonColor: '#0F4C81',
    borderRadius: '12px'
});
<?php endif; ?>
</script>
</body>
</html>
