<?php
require_once __DIR__ . '/config/db_connect.php';

$password = 'admin123';
$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $pdo->prepare("UPDATE users SET password = ?, role = 'Admin' WHERE username = 'admin'");
$stmt->execute([$hash]);

echo "Admin password has been reset to: <strong>admin123</strong><br><br>";
echo "<a href='login.php'>Click here to login</a>";
// Delete this file after running
@unlink(__FILE__);
?>
