<?php
// I-off ang display errors sa production para hindi masira ang JSON/AJAX responses
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
date_default_timezone_set('Asia/Manila');

// ============================================================
// DATABASE CONNECTION — School Performance Dashboard Template
// ============================================================
// Detect Environment (Local vs Live Server)
if ($_SERVER['HTTP_HOST'] === 'localhost' || $_SERVER['HTTP_HOST'] === '127.0.0.1') {
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'school_dashboard_db');
} else {
    define('DB_HOST', 'your_production_host');
    define('DB_USER', 'your_production_user');
    define('DB_PASS', 'your_production_password'); // TODO: Palitan ito ng iyong vPanel/Hosting Account password
    define('DB_NAME', 'your_production_db');
}

define('APP_TITLE',   'Performance Analytics Dashboard');
define('APP_VERSION', '1.0.0');

// Feature Flags
define('FEATURE_DATA_ENTRY', true);

// DepEd Standards
define('DEPED_AREA_PER_STUDENT',     1.4);   // sqm per student
define('DEPED_JHS_CLASS_SIZE',       45);
define('DEPED_SHS_CLASS_SIZE',       40);
define('DEPED_JHS_TEACHER_RATIO',    35);
define('DEPED_SHS_TEACHER_RATIO',    35);
define('DROPOUT_ALERT_THRESHOLD',    10);    // %
define('SEAT_OVERCROWD_THRESHOLD',   90);    // %

$pdo = null;
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
}

// Auto-migration block – Ensure 'status' column exists in 'users' table
try {
    $checkCol = $pdo->query("SHOW COLUMNS FROM users LIKE 'status'");
    if (!$checkCol->fetch()) {
        $pdo->exec("ALTER TABLE users ADD COLUMN status ENUM('Pending', 'Approved') DEFAULT 'Pending'");
        $pdo->exec("UPDATE users SET status = 'Approved'");
    }
    
    // Ensure 'role' column supports Admin, Faculty, and Student roles
    try {
        $pdo->exec("ALTER TABLE users MODIFY COLUMN role ENUM('Admin', 'Faculty', 'Student', 'Encoder', 'Viewer') DEFAULT 'Student'");
    } catch (Exception $role_alter_error) {
        // Fail silently
    }
    
    // Auto-create announcements table if it doesn't exist
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `announcements` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `title` VARCHAR(255) NOT NULL,
            `content` TEXT NOT NULL,
            `category` ENUM('suspension', 'event', 'general') DEFAULT 'general',
            `is_active` TINYINT(1) DEFAULT 1,
            `start_date` DATE NULL,
            `end_date` DATE NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // Auto-create system_settings table if it doesn't exist
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `system_settings` (
            `setting_key` VARCHAR(50) PRIMARY KEY,
            `setting_value` TEXT NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // Seed default settings if empty
    $checkSettings = $pdo->query("SELECT COUNT(*) FROM system_settings");
    if ((int)$checkSettings->fetchColumn() === 0) {
        $pdo->exec("
            INSERT INTO system_settings (setting_key, setting_value) VALUES 
            ('school_name', 'Your School Name'),
            ('school_logo', 'assets/img/school-logo.png'),
            ('school_tagline', 'Empowering Students through Data-Driven Education'),
            ('school_address', ''),
            ('school_division', ''),
            ('school_id', ''),
            ('school_contact', ''),
            ('primary_color', '#1B2A6B'),
            ('primary_color_rgb', '27, 42, 107'),
            ('secondary_color', '#C9A227'),
            ('deped_jhs_class_size', '45'),
            ('deped_shs_class_size', '40'),
            ('deped_jhs_teacher_ratio', '35'),
            ('deped_shs_teacher_ratio', '35'),
            ('offered_levels', 'jhs,shs')
        ");
    } else {
        // Seed offered_levels if missing in existing settings table
        $checkOffered = $pdo->query("SELECT COUNT(*) FROM system_settings WHERE setting_key = 'offered_levels'");
        if ((int)$checkOffered->fetchColumn() === 0) {
            $pdo->exec("INSERT INTO system_settings (setting_key, setting_value) VALUES ('offered_levels', 'jhs,shs')");
        }
    }

    // Alter level_type of grade_levels if not already done
    try {
        $pdo->exec("ALTER TABLE grade_levels MODIFY COLUMN level_type ENUM('Kindergarten', 'Elementary', 'Junior High', 'Senior High') NOT NULL");
    } catch (Exception $e) {
        // Safe to ignore if already altered
    }
    
    // Seed new grade levels
    $pdo->exec("
        INSERT IGNORE INTO grade_levels (id, grade_name, level_type) VALUES 
        (7, 'Kindergarten', 'Kindergarten'),
        (8, 'Grade 1', 'Elementary'),
        (9, 'Grade 2', 'Elementary'),
        (10, 'Grade 3', 'Elementary'),
        (11, 'Grade 4', 'Elementary'),
        (12, 'Grade 5', 'Elementary'),
        (13, 'Grade 6', 'Elementary')
    ");
} catch (Exception $migration_error) {
    // Fail silently to avoid interrupting application load if schema is locked
}

// Load dynamic branding from database
$school_name     = 'Your School Name';
$school_logo     = 'assets/img/school-logo.png';
$school_tagline  = 'Empowering Students through Data-Driven Education';
$school_address  = '';
$school_division = '';
$school_id_val   = '';
$school_contact  = '';
$primary_color   = '#1B2A6B';
$primary_color_rgb = '27, 42, 107';
$secondary_color = '#C9A227';
$setup_complete  = false;
$offered_levels  = 'jhs,shs';
try {
    $settings_stmt = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
    $settings_data = $settings_stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    if (!empty($settings_data['school_name']))      $school_name     = $settings_data['school_name'];
    if (!empty($settings_data['school_logo']))       $school_logo     = $settings_data['school_logo'];
    if (isset($settings_data['school_tagline']))     $school_tagline  = $settings_data['school_tagline'];
    if (isset($settings_data['school_address']))     $school_address  = $settings_data['school_address'];
    if (isset($settings_data['school_division']))    $school_division = $settings_data['school_division'];
    if (isset($settings_data['school_id']))          $school_id_val   = $settings_data['school_id'];
    if (isset($settings_data['school_contact']))     $school_contact  = $settings_data['school_contact'];
    if (!empty($settings_data['primary_color']))     $primary_color   = $settings_data['primary_color'];
    if (!empty($settings_data['primary_color_rgb'])) $primary_color_rgb = $settings_data['primary_color_rgb'];
    if (!empty($settings_data['secondary_color']))   $secondary_color = $settings_data['secondary_color'];
    if (!empty($settings_data['offered_levels']))   $offered_levels  = $settings_data['offered_levels'];
    $setup_complete = isset($settings_data['setup_complete']) && $settings_data['setup_complete'] === '1';
} catch (Exception $e) {
    // Fallback if schema doesn't exist yet
}
define('APP_NAME',              $school_name);
define('APP_LOGO',              $school_logo);
define('APP_TAGLINE',           $school_tagline);
define('APP_SCHOOL_ADDRESS',    $school_address);
define('APP_SCHOOL_DIVISION',   $school_division);
define('APP_SCHOOL_ID',         $school_id_val);
define('APP_SCHOOL_CONTACT',    $school_contact);
define('APP_PRIMARY_COLOR',     $primary_color);
define('APP_PRIMARY_COLOR_RGB', $primary_color_rgb);
define('APP_SECONDARY_COLOR',   $secondary_color);
define('APP_SETUP_COMPLETE',    $setup_complete);
define('APP_OFFERED_LEVELS',     $offered_levels);

$offered_arr = explode(',', APP_OFFERED_LEVELS);
define('APP_OFFERED_KINDER',     in_array('kinder', $offered_arr));
define('APP_OFFERED_ELEMENTARY', in_array('elem', $offered_arr));
define('APP_OFFERED_JHS',        in_array('jhs', $offered_arr));
define('APP_OFFERED_SHS',        in_array('shs', $offered_arr));

function has_kinder(): bool { return APP_OFFERED_KINDER; }
function has_elementary(): bool { return APP_OFFERED_ELEMENTARY; }
function has_jhs(): bool { return APP_OFFERED_JHS; }
function has_shs(): bool { return APP_OFFERED_SHS; }

// ── Setup Wizard Redirect ─────────────────────────────────
// If setup is not complete AND we are not already on the setup page, redirect.
$current_script = basename($_SERVER['SCRIPT_FILENAME'] ?? '');
$setup_exempt = ['setup.php', 'ajax/setup_crud.php', 'logout.php'];
if (!APP_SETUP_COMPLETE && !in_array($current_script, $setup_exempt)) {
    header('Location: ' . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/setup.php');
    exit;
}


// ── Helpers ──────────────────────────────────────────────────

/**
 * Log an activity into the audit table.
 */
function log_activity(PDO $pdo, ?int $user_id, string $description, string $module = ''): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $stmt = $pdo->prepare("
        INSERT INTO activity_logs (user_id, action_description, module, ip_address)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$user_id, $description, $module, $ip]);
}

/**
 * Return a JSON response and exit.
 */
function json_response(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Sanitize string input.
 */
function clean(string $val): string {
    return htmlspecialchars(strip_tags(trim($val)), ENT_QUOTES, 'UTF-8');
}

/**
 * Get current logged-in user id from session.
 */
function current_user_id(): ?int {
    return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
}

/**
 * Require login – redirect if not authenticated.
 */
function require_login(): void {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Check if user has required role.
 */
function has_role(string ...$roles): bool {
    return in_array($_SESSION['user_role'] ?? '', $roles, true);
}
?>
