<?php
require_once __DIR__ . '/../config/session.php';
require_login();
if(!has_role('Admin')) json_response(['success'=>false,'message'=>'Access denied.'],403);

$data   = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';
$type   = $data['type'] ?? '';

try {
    if ($type === 'jhs') {
        if ($action === 'add') {
            $s=$pdo->prepare("INSERT INTO teachers_per_grade (grade_level_id,teacher_count,school_year) VALUES(?,?,?)");
            $s->execute([(int)$data['grade_level_id'],(int)$data['teacher_count'],clean($data['school_year']??'')]);
            log_activity($pdo,current_user_id(),"Added JHS teacher record for grade {$data['grade_level_id']}",'HR');
            json_response(['success'=>true,'message'=>'JHS teacher record added.']);
        } elseif ($action === 'edit') {
            $s=$pdo->prepare("UPDATE teachers_per_grade SET grade_level_id=?,teacher_count=?,school_year=? WHERE id=?");
            $s->execute([(int)$data['grade_level_id'],(int)$data['teacher_count'],clean($data['school_year']??''),(int)$data['id']]);
            log_activity($pdo,current_user_id(),"Updated JHS teacher record ID:{$data['id']}",'HR');
            json_response(['success'=>true,'message'=>'Record updated.']);
        }
    } elseif ($type === 'area') {
        if ($action === 'add') {
            $s=$pdo->prepare("INSERT INTO teachers_per_area (learning_area,teacher_count,grade_level_covered,level_type,school_year) VALUES(?,?,?,?,?)");
            $s->execute([clean($data['learning_area']??''),(int)$data['teacher_count'],clean($data['grade_level_covered']??''),clean($data['level_type']??'Both'),clean($data['school_year']??'')]);
            log_activity($pdo,current_user_id(),"Added area teacher: {$data['learning_area']}",'HR');
            json_response(['success'=>true,'message'=>'Area teacher record added.']);
        } elseif ($action === 'edit') {
            $s=$pdo->prepare("UPDATE teachers_per_area SET learning_area=?,teacher_count=?,grade_level_covered=?,level_type=?,school_year=? WHERE id=?");
            $s->execute([clean($data['learning_area']??''),(int)$data['teacher_count'],clean($data['grade_level_covered']??''),clean($data['level_type']??'Both'),clean($data['school_year']??''),(int)$data['id']]);
            log_activity($pdo,current_user_id(),"Updated area teacher ID:{$data['id']}",'HR');
            json_response(['success'=>true,'message'=>'Record updated.']);
        }
    }
    json_response(['success'=>false,'message'=>'Unknown request.'],400);
} catch(PDOException $e){
    json_response(['success'=>false,'message'=>'DB error: '.$e->getMessage()],500);
}
