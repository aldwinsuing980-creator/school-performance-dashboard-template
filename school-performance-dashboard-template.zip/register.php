<?php
require_once __DIR__ . '/config/session.php';
if (isset($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }
$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username  = clean($_POST['username'] ?? '');
    $email     = clean($_POST['email'] ?? '');
    $full_name = clean($_POST['full_name'] ?? '');
    $password  = $_POST['password'] ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';
    $role      = clean($_POST['role'] ?? 'Student');
    if (!in_array($role, ['Admin', 'Faculty', 'Student'], true)) {
        $role = 'Student';
    }
    if (!$username || !$email || !$full_name || !$password) {
        $error = 'All fields are required.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } else {
        $chk = $pdo->prepare("SELECT id FROM users WHERE username=? OR email=?");
        $chk->execute([$username, $email]);
        if ($chk->fetch()) {
            $error = 'Username or email already exists.';
        } else {
            $status = ($role === 'Student') ? 'Approved' : 'Pending';
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $ins  = $pdo->prepare("INSERT INTO users (username, password, email, full_name, role, status) VALUES (?, ?, ?, ?, ?, ?)");
            $ins->execute([$username, $hash, $email, $full_name, $role, $status]);
            
            if ($status === 'Approved') {
                log_activity($pdo, $pdo->lastInsertId(), "New Student '{$username}' registered and automatically activated.", 'Auth');
                $success = 'Account created successfully! You can now log in immediately.';
            } else {
                log_activity($pdo, $pdo->lastInsertId(), "New user '{$username}' registered with requested role '{$role}' (Pending Approval).", 'Auth');
                $success = 'Account created! Please wait for Admin approval before logging in.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Register — <?= htmlspecialchars(APP_NAME) ?> Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
  body{font-family:'Poppins',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;
    background:linear-gradient(135deg,#0F4C81 0%,#093457 50%,#061f36 100%);}
  .card-reg{width:100%;max-width:480px;background:#fff;border-radius:20px;box-shadow:0 25px 60px rgba(0,0,0,.35);overflow:hidden;}
  .card-header-bg{background:linear-gradient(135deg,#0F4C81,#093457);padding:28px 32px 22px;text-align:center;}
  .card-header-bg h1{color:#fff;font-size:1.2rem;font-weight:700;margin:0;}
  .card-header-bg p{color:rgba(255,255,255,.75);font-size:.8rem;}
  .card-body-custom{padding:28px 32px;}
  .form-control{border:1.5px solid #dee2e6;border-radius:10px;padding:.6rem 1rem;font-family:'Poppins',sans-serif;font-size:.88rem;transition:.2s;}
  .form-control:focus{border-color:#0F4C81;box-shadow:0 0 0 3px rgba(15,76,129,.15);}
  .input-group-text{background:#f0f4ff;border:1.5px solid #dee2e6;color:#0F4C81;border-radius:10px 0 0 10px;}
  .btn-reg{background:linear-gradient(135deg,#0F4C81,#093457);border:none;border-radius:10px;padding:.65rem;
    font-family:'Poppins',sans-serif;font-weight:600;transition:.2s;}
  .btn-reg:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(15,76,129,.35);}
  label{font-size:.82rem;font-weight:500;color:#374151;margin-bottom:3px;}
</style>
</head>
<body>
<div class="card-reg">
  <div class="card-header-bg">
    <h1><i class="bi bi-person-plus-fill me-2"></i>Request Dashboard Access</h1>
    <p class="mb-0"><?= htmlspecialchars(APP_NAME) ?> — Authorized Personnel</p>
  </div>
  <div class="card-body-custom">
    <form method="POST" id="regForm">
      <div class="mb-3">
        <label>Full Name</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-person"></i></span>
          <input type="text" name="full_name" class="form-control" placeholder="e.g. Juan Dela Cruz" required>
        </div>
      </div>
      <div class="mb-3">
        <label>Username</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-at"></i></span>
          <input type="text" name="username" class="form-control" placeholder="Choose a username" required>
        </div>
      </div>
      <div class="mb-3">
        <label>Email Address</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-envelope"></i></span>
          <input type="email" name="email" class="form-control" placeholder="your@email.com" required>
        </div>
      </div>
      <div class="mb-3">
        <label>Password</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-lock"></i></span>
          <input type="password" name="password" id="pwd" class="form-control" placeholder="Min. 8 characters" required>
        </div>
      </div>
      <div class="mb-3">
        <label>Requested Role</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-shield-lock"></i></span>
          <select name="role" class="form-select" required>
            <option value="Student">Student (Student Portal access)</option>
            <option value="Faculty">Faculty (Teacher/Staff analytics)</option>
            <option value="Admin">Admin (System Administrator)</option>
          </select>
        </div>
      </div>
      <div class="mb-4">
        <label>Confirm Password</label>
        <div class="input-group">
          <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
          <input type="password" name="confirm_password" id="cpwd" class="form-control" placeholder="Repeat password" required>
        </div>
      </div>
      <button type="submit" class="btn btn-reg btn-primary w-100 text-white">
        <i class="bi bi-check-circle me-2"></i>Create Account
      </button>
    </form>
    <p class="text-center text-muted mt-3 mb-0" style="font-size:.82rem;">
      Already have an account? <a href="login.php" style="color:#0F4C81;font-weight:600;">Sign In</a>
    </p>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
<?php if($error): ?>
Swal.fire({icon:'error',title:'Registration Failed',text:<?=json_encode($error)?>,confirmButtonColor:'#0F4C81'});
<?php elseif($success): ?>
Swal.fire({icon:'success',title:'Account Created!',text:<?=json_encode($success)?>,confirmButtonColor:'#0F4C81'})
  .then(()=>window.location='login.php');
<?php endif; ?>
</script>
</body>
</html>
