<?php
// includes/header.php
// Usage: include at top of every page AFTER session check
// Variables expected: $page_title (string)
$current_page = basename($_SERVER['PHP_SELF'], '.php');
$school_years_raw = $pdo->query("SELECT DISTINCT school_year FROM enrollment_data ORDER BY school_year DESC")->fetchAll();
$school_years = array_column($school_years_raw, 'school_year');
$selected_sy  = $_GET['sy'] ?? ($school_years[0] ?? '2025-2026');
if ($selected_sy === 'new_sy') {
    $selected_sy = $school_years[0] ?? '2025-2026';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta name="description" content="<?= htmlspecialchars(APP_NAME) ?> Performance Analytics Dashboard — Data-driven school management.">
<title><?= htmlspecialchars($page_title ?? 'Dashboard') ?> — <?= htmlspecialchars(APP_NAME) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<link rel="stylesheet" href="assets/css/style.css?v=<?= time() ?>">
<style>
/* Dynamic School Theme Colors — set from system_settings */
:root {
  --primary:        <?= APP_PRIMARY_COLOR ?>;
  --primary-rgb:    <?= APP_PRIMARY_COLOR_RGB ?>;
  --secondary:      <?= APP_SECONDARY_COLOR ?>;
}
</style>
</head>
<body>
<script>
/* Apply saved theme immediately to avoid flash-of-light-mode */
(function(){
  const t = localStorage.getItem('app_theme');
  if(t === 'dark') document.documentElement.setAttribute('data-theme','dark');
})();
</script>
<script>
/* School Theme Color Palette — used by all charts. Driven by system_settings. */
const PRIMARY_COLOR   = '<?= APP_PRIMARY_COLOR ?>';
const SECONDARY_COLOR = '<?= APP_SECONDARY_COLOR ?>';
// Legacy aliases kept for backward-compatibility with existing chart code
const NHS_NAVY   = PRIMARY_COLOR;
const NHS_NAVY2  = PRIMARY_COLOR;
const NHS_GOLD   = SECONDARY_COLOR;
const NHS_GOLD2  = SECONDARY_COLOR;
const NHS_RED    = '#8B1A1A';
const NHS_RED2   = '#B02020';
const CHART_PALETTE = [
  PRIMARY_COLOR, SECONDARY_COLOR, '#8B1A1A',
  '#2E3F8F','#A07D0F','#B02020','#3D5291','#D4AC3A','#C0392B','#4A6DB5'
];
</script>
<?php include __DIR__ . '/sidebar.php'; ?>
<div class="main-content" id="mainContent">
  <!-- Top Navbar -->
  <nav class="top-navbar d-flex align-items-center justify-content-between px-4">
    <div class="d-flex align-items-center gap-3">
      <button class="btn btn-sm btn-icon" id="sidebarToggle" title="Toggle Sidebar">
        <i class="bi bi-list fs-5"></i>
      </button>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-0">
          <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none">Home</a></li>
          <?php if(isset($breadcrumb)): ?>
          <li class="breadcrumb-item active"><?= htmlspecialchars($breadcrumb) ?></li>
          <?php endif; ?>
        </ol>
      </nav>
    </div>
    <div class="d-flex align-items-center gap-3">
      <!-- School Year Filter -->
      <form method="GET" class="d-flex align-items-center gap-2" id="syForm">
        <?php foreach($_GET as $k=>$v): if($k==='sy') continue; ?>
          <input type="hidden" name="<?=htmlspecialchars($k)?>" value="<?=htmlspecialchars($v)?>">
        <?php endforeach; ?>
        <label class="mb-0 text-muted small fw-500">S.Y.</label>
        <?php
          $is_data_entry = ($current_page === 'data_entry' || $current_page === 'new_data_entry');
          $onchange_attr = $is_data_entry ? 'handleSYChange(this)' : 'this.form.submit()';
        ?>
        <div class="d-flex align-items-center gap-1">
          <select name="sy" id="globalSY" class="form-select form-select-sm sy-select" onchange="<?= $onchange_attr ?>">
            <?php if(!in_array($selected_sy, $school_years)): ?>
            <option value="<?=htmlspecialchars($selected_sy)?>" selected><?=htmlspecialchars($selected_sy)?></option>
            <?php endif; ?>
            <?php foreach($school_years as $sy): ?>
            <option value="<?=$sy?>" <?=$sy===$selected_sy?'selected':''?>><?=$sy?></option>
            <?php endforeach; ?>
            <?php if($is_data_entry): ?>
            <option value="new_sy">+ New School Year</option>
            <?php endif; ?>
          </select>
          <?php if(has_role('Admin')): ?>
          <button type="button" class="btn btn-sm btn-outline-danger d-inline-flex align-items-center justify-content-center p-0" style="width: 32px; height: 32px; border-radius: 8px; flex-shrink: 0;" title="Delete active School Year" onclick="confirmDeleteSchoolYear('<?= htmlspecialchars($selected_sy) ?>')">
            <i class="bi bi-trash"></i>
          </button>
          <?php endif; ?>
        </div>
      </form>
      <!-- Dark Mode Toggle -->
      <div class="dark-toggle-wrap" title="Toggle dark mode">
        <i class="bi bi-sun-fill dark-toggle-icon" id="dmIconSun"></i>
        <label class="dark-toggle" aria-label="Toggle dark mode">
          <input type="checkbox" id="darkModeToggle">
          <span class="dark-toggle-track"></span>
        </label>
        <i class="bi bi-moon-fill dark-toggle-icon" id="dmIconMoon"></i>
      </div>
      <!-- User Dropdown -->
      <div class="dropdown">
        <button class="btn btn-sm d-flex align-items-center gap-2 user-btn" data-bs-toggle="dropdown">
          <div class="avatar-sm"><?= strtoupper(substr($_SESSION['full_name']??'U',0,1)) ?></div>
          <span class="d-none d-md-inline small fw-600"><?= htmlspecialchars($_SESSION['full_name']??'User') ?></span>
          <i class="bi bi-chevron-down small"></i>
        </button>
        <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0">
          <li><span class="dropdown-item-text small text-muted">
            <i class="bi bi-shield-check me-1"></i><?= htmlspecialchars($_SESSION['user_role']??'') ?>
          </span></li>
          <li><hr class="dropdown-divider my-1"></li>
          <li><a class="dropdown-item small" href="change_password.php">
            <i class="bi bi-key-fill me-2 text-primary"></i>Change Password
          </a></li>
          <li><hr class="dropdown-divider my-1"></li>
          <li><a class="dropdown-item small" href="logout.php">
            <i class="bi bi-box-arrow-right me-2 text-danger"></i>Sign Out
          </a></li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Page Body -->
  <div class="page-body p-4">

<script>
/* ── Dark Mode Toggle Logic ──────────────────────────────── */
(function() {
  const toggle   = document.getElementById('darkModeToggle');
  const iconSun  = document.getElementById('dmIconSun');
  const iconMoon = document.getElementById('dmIconMoon');
  const KEY      = 'app_theme';

  function applyTheme(dark) {
    if (dark) {
      document.documentElement.setAttribute('data-theme', 'dark');
      localStorage.setItem(KEY, 'dark');
    } else {
      document.documentElement.removeAttribute('data-theme');
      localStorage.setItem(KEY, 'light');
    }
    toggle.checked        = dark;
    iconSun.style.color   = dark ? 'var(--text-muted)' : 'var(--accent)';
    iconMoon.style.color  = dark ? 'var(--accent)'     : 'var(--text-muted)';
  }

  /* Initialise from storage */
  applyTheme(localStorage.getItem(KEY) === 'dark');

  /* React to toggle click */
  toggle.addEventListener('change', function() {
    applyTheme(this.checked);
  });
})();

function confirmDeleteSchoolYear(sy) {
  Swal.fire({
    title: 'Delete School Year ' + sy + '?',
    html: 'This will <strong class="text-danger">permanently delete ALL</strong> enrollees, repeaters, dropouts, seats, and teacher records for <strong>S.Y. ' + sy + '</strong>.<br><br>To confirm this destructive action, please type the school year <strong>' + sy + '</strong> below:',
    input: 'text',
    inputPlaceholder: sy,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: '<i class="bi bi-trash3-fill me-1"></i> Delete School Year',
    confirmButtonColor: '#dc2626',
    cancelButtonColor: '#6c757d',
    preConfirm: (inputValue) => {
      if (inputValue !== sy) {
        Swal.showValidationMessage('The input does not match ' + sy + '!');
        return false;
      }
      return inputValue;
    }
  }).then((result) => {
    if (result.isConfirmed) {
      showSpinner();
      fetch('ajax/delete_school_year.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ school_year: sy })
      })
      .then(response => response.json())
      .then(res => {
        hideSpinner();
        if (res.success) {
          toastSuccess(res.message);
          setTimeout(() => {
            const currentPage = window.location.pathname.split("/").pop() || 'dashboard.php';
            if (currentPage === 'enrollment.php' || currentPage === 'dashboard.php' || currentPage === 'insights.php') {
              window.location.href = currentPage;
            } else {
              window.location.href = 'dashboard.php';
            }
          }, 1500);
        } else {
          toastError(res.message || 'Error occurred');
        }
      })
      .catch(() => {
        hideSpinner();
        toastError('Server request failed.');
      });
    }
  });
}
</script>
