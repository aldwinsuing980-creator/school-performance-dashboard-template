<?php
require_once __DIR__ . '/config/session.php';
require_login();

$page_title = 'Dashboard';
$breadcrumb = 'Overview';

// â”€â”€ School Year filter â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
$sy_rows = $pdo->query("SELECT DISTINCT school_year FROM enrollment_data ORDER BY school_year DESC")->fetchAll();
$sy_list = array_column($sy_rows, 'school_year');
$selected_sy = $_GET['sy'] ?? ($sy_list[0] ?? '2025-2026');

// Fetch active class suspensions for warning banner
$today_date = date('Y-m-d');
$susp_q = $pdo->prepare("
  SELECT * FROM announcements 
  WHERE is_active = 1 
    AND category = 'suspension'
    AND (start_date IS NULL OR start_date <= ?)
    AND (end_date IS NULL OR end_date >= ?)
  ORDER BY created_at DESC
");
$susp_q->execute([$today_date, $today_date]);
$suspension_alerts = $susp_q->fetchAll();

$allowed_level_types = [];
if (has_kinder()) $allowed_level_types[] = 'Kindergarten';
if (has_elementary()) $allowed_level_types[] = 'Elementary';
if (has_jhs()) $allowed_level_types[] = 'Junior High';
if (has_shs()) $allowed_level_types[] = 'Senior High';
if (empty($allowed_level_types)) $allowed_level_types = ['Junior High', 'Senior High'];

$level_type_clause = "gl.level_type IN ('" . implode("','", $allowed_level_types) . "')";

// ── KPI 1: Total BOSY Enrollment ─────────────────────────────
$q = $pdo->prepare("
  SELECT COALESCE(SUM(
    CASE
      WHEN gl.level_type='Senior High' THEN (CASE WHEN e.semester='1st Sem' THEN e.bosy_enrollment ELSE 0 END)
      ELSE e.bosy_enrollment
    END
  ),0) as total 
  FROM enrollment_data e
  JOIN grade_levels gl ON gl.id = e.grade_level_id
  WHERE e.school_year=? AND $level_type_clause
");
$q->execute([$selected_sy]); $total_enroll = (int)$q->fetchColumn();

// ── Enrollment by grade ──────────────────────────────────────
$q = $pdo->prepare("
  SELECT gl.grade_name, gl.level_type,
    COALESCE(SUM(
      CASE
        WHEN gl.level_type='Senior High' THEN (CASE WHEN e.semester='1st Sem' THEN e.bosy_enrollment ELSE 0 END)
        ELSE e.bosy_enrollment
      END
    ),0) AS enroll
  FROM grade_levels gl
  LEFT JOIN enrollment_data e ON e.grade_level_id=gl.id AND e.school_year=?
  WHERE $level_type_clause
  GROUP BY gl.id ORDER BY gl.id
");
$q->execute([$selected_sy]);
$enroll_by_grade = $q->fetchAll();

// ── KPI 2: Repeater Rate ─────────────────────────────────────
$q = $pdo->prepare("
  SELECT COALESCE(SUM(r.repeaters_count),0) 
  FROM repeaters_data r
  JOIN grade_levels gl ON gl.id = r.grade_level_id
  WHERE r.school_year=? AND $level_type_clause
");
$q->execute([$selected_sy]); $total_repeaters = (int)$q->fetchColumn();
$repeater_rate = $total_enroll > 0 ? round($total_repeaters / $total_enroll * 100, 2) : 0;

// ── KPI 3: Dropout Rate & Retention ──────────────────────────
$q = $pdo->prepare("
  SELECT COALESCE(SUM(d.dropouts_count),0) 
  FROM dropouts_data d
  JOIN grade_levels gl ON gl.id = d.grade_level_id
  WHERE d.school_year=? AND $level_type_clause
");
$q->execute([$selected_sy]); $total_dropouts = (int)$q->fetchColumn();
$dropout_rate   = $total_enroll > 0 ? round($total_dropouts / $total_enroll * 100, 2) : 0;
$retention_rate = round(100 - $dropout_rate, 2);

// ── KPI 4: Classroom Utilization ─────────────────────────────
$q = $pdo->query("SELECT COUNT(*) as total, SUM(is_functional) as functional, COALESCE(SUM(CASE WHEN is_functional=1 THEN total_area ELSE 0 END),0) as area FROM classrooms");
$cls = $q->fetch();
$total_rooms = (int)$cls['total'];
$func_rooms  = (int)$cls['functional'];
$total_area  = (float)$cls['area'];
$util_rate   = $total_rooms > 0 ? round($func_rooms / $total_rooms * 100, 1) : 0;
$area_per_student = $total_enroll > 0 ? round($total_area / $total_enroll, 2) : 0;

// ── KPI 5: Seat Sufficiency ──────────────────────────────────
$q = $pdo->prepare("
  SELECT COALESCE(SUM(s.available_seats),0) 
  FROM seats_data s
  JOIN grade_levels gl ON gl.id = s.grade_level_id
  WHERE s.school_year=? AND $level_type_clause
");
$q->execute([$selected_sy]); $total_seats = (int)$q->fetchColumn();
$seat_ratio = $total_enroll > 0 ? round($total_seats / $total_enroll * 100, 1) : 0;

// ── KPI 6 & 7: Teacher ratios ────────────────────────────────
$q = $pdo->prepare("
  SELECT COALESCE(SUM(t.teacher_count),0) 
  FROM teachers_per_grade t
  JOIN grade_levels gl ON gl.id = t.grade_level_id
  WHERE t.school_year=? AND $level_type_clause
");
$q->execute([$selected_sy]); $jhs_teachers = (int)$q->fetchColumn();

$jhs_enroll = 0;
foreach($enroll_by_grade as $r) if(in_array($r['level_type'], ['Kindergarten', 'Elementary', 'Junior High'])) $jhs_enroll += $r['enroll'];

// SHS enrollment: 1st Sem only
$shs_q = $pdo->prepare("
  SELECT COALESCE(SUM(e.bosy_enrollment),0)
  FROM enrollment_data e
  JOIN grade_levels gl ON gl.id=e.grade_level_id
  WHERE gl.level_type='Senior High' AND e.semester='1st Sem' AND e.school_year=?
");
$shs_q->execute([$selected_sy]);
$shs_enroll = (int)$shs_q->fetchColumn();

$jhs_ratio = $jhs_teachers > 0 ? round($jhs_enroll / $jhs_teachers, 1) : 0;

$q = $pdo->prepare("SELECT COALESCE(SUM(teacher_count),0) FROM teachers_per_area WHERE level_type='Senior High' AND school_year=?");
$q->execute([$selected_sy]); $shs_teachers = (int)$q->fetchColumn();
$shs_ratio = $shs_teachers > 0 ? round($shs_enroll / $shs_teachers, 1) : 0;

$total_teachers = $jhs_teachers + $shs_teachers;
$combined_ratio = $total_teachers > 0 ? round($total_enroll / $total_teachers, 1) : 0;

// â”€â”€ Repeaters & Dropouts per grade â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
$q = $pdo->prepare("
  SELECT gl.grade_name,
    (SELECT COALESCE(SUM(r.repeaters_count),0) FROM repeaters_data r WHERE r.grade_level_id=gl.id AND r.school_year=?) AS rep,
    (SELECT COALESCE(SUM(d.dropouts_count),0) FROM dropouts_data d WHERE d.grade_level_id=gl.id AND d.school_year=?) AS drop_
  FROM grade_levels gl
  WHERE $level_type_clause
  ORDER BY gl.id
");
$q->execute([$selected_sy,$selected_sy]);
$perf_matrix = $q->fetchAll();

// â”€â”€ Teachers per learning area â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
$allowed_ta_levels = [];
if (has_kinder() || has_elementary() || has_jhs()) $allowed_ta_levels[] = 'Junior High';
if (has_shs()) $allowed_ta_levels[] = 'Senior High';
if (empty($allowed_ta_levels)) $allowed_ta_levels = ['Junior High', 'Senior High'];
$ta_clause = "level_type IN ('" . implode("','", $allowed_ta_levels) . "')";

$q = $pdo->prepare("SELECT learning_area, teacher_count, level_type FROM teachers_per_area WHERE school_year=? AND $ta_clause ORDER BY teacher_count DESC");
$q->execute([$selected_sy]); $teacher_areas = $q->fetchAll();
foreach ($teacher_areas as &$ta) {
    if ($ta['learning_area'] === 'Araling Panlipunan') $ta['learning_area'] = 'Social Studies (Araling Panlipunan)';
    if ($ta['learning_area'] === 'ESP/Values') $ta['learning_area'] = 'Values Education (EsP)';
}
unset($ta);

// â”€â”€ Enrollment trend (last 5 SY) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
$trend_q = $pdo->prepare("
  SELECT e.school_year, 
    COALESCE(SUM(
      CASE
        WHEN gl.level_type='Senior High' THEN (CASE WHEN e.semester='1st Sem' THEN e.bosy_enrollment ELSE 0 END)
        ELSE e.bosy_enrollment
      END
    ),0) as total
  FROM enrollment_data e
  JOIN grade_levels gl ON gl.id = e.grade_level_id
  GROUP BY e.school_year ORDER BY e.school_year ASC LIMIT 5
");
$trend_q->execute(); $enroll_trend = $trend_q->fetchAll();

// â”€â”€ Detail data for KPI modals â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
$classrooms_detail = $pdo->query("SELECT * FROM classrooms ORDER BY is_functional DESC, room_code")->fetchAll();
$seats_modal_q = $pdo->prepare("
  SELECT sd.*, gl.grade_name, gl.level_type, st.strand_code
  FROM seats_data sd
  JOIN grade_levels gl ON gl.id=sd.grade_level_id
  LEFT JOIN strands st ON st.id=sd.strand_id
  WHERE sd.school_year=? AND $level_type_clause ORDER BY gl.id
");
$seats_modal_q->execute([$selected_sy]);
$seats_detail = $seats_modal_q->fetchAll();

include 'includes/header.php';

if ($_SESSION['user_role'] === 'Student'):
    $student_strands = $pdo->query("SELECT * FROM strands ORDER BY track, strand_name")->fetchAll();
    $student_announcements = $pdo->query("SELECT * FROM announcements WHERE is_active = 1 AND category != 'suspension' ORDER BY created_at DESC LIMIT 5")->fetchAll();
?>
<!-- Premium Student Portal View -->
<style>
  .student-hero-banner {
    background: linear-gradient(135deg, rgba(27, 42, 107, 0.42) 0%, rgba(46, 63, 143, 0.45) 50%, rgba(15, 76, 129, 0.48) 100%), url('assets/img/school-bg.jpg') no-repeat center center;
    background-size: cover;
    border-radius: 20px;
    padding: 3rem 2.5rem;
    color: white;
    position: relative;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(27, 42, 107, 0.15);
    margin-bottom: 2rem;
  }
  .student-hero-banner::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 400px;
    height: 400px;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.12) 0%, transparent 70%);
    pointer-events: none;
  }
  .student-badge {
    background: rgba(255, 255, 255, 0.18);
    backdrop-filter: blur(4px);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: #ffffff;
    font-weight: 600;
    font-size: 0.8rem;
    padding: 6px 14px;
    border-radius: 50px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  .student-title {
    font-size: 2.5rem;
    font-weight: 700;
    line-height: 1.25;
    margin-top: 1rem;
    margin-bottom: 0.5rem;
    text-shadow: 0 2px 12px rgba(0, 0, 0, 0.75);
  }
  .student-subtitle {
    font-size: 1.1rem;
    opacity: 0.95;
    font-weight: 400;
    max-width: 650px;
    text-shadow: 0 2px 8px rgba(0, 0, 0, 0.75);
  }
  .portal-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 16px;
    box-shadow: var(--shadow);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    height: 100%;
    overflow: hidden;
  }
  .portal-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-md), 0 8px 24px rgba(27, 42, 107, 0.04);
    border-color: rgba(27, 42, 107, 0.15);
  }
  .portal-card-header {
    padding: 1.5rem;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .portal-card-title {
    font-size: 1.1rem;
    font-weight: 700;
    color: var(--text-dark);
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .strand-badge-type {
    font-size: 0.7rem;
    font-weight: 700;
    padding: 4px 10px;
    border-radius: 8px;
    text-transform: uppercase;
    letter-spacing: 0.3px;
  }
  .badge-tvl {
    background-color: rgba(201, 162, 39, 0.12);
    color: #A07D0F;
  }
  .badge-academic {
    background-color: rgba(27, 42, 107, 0.1);
    color: #1B2A6B;
  }
  [data-theme="dark"] .badge-academic {
    background-color: rgba(107, 155, 232, 0.15);
    color: #6B9BE8;
  }
  .strand-item {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 1.25rem;
    margin-bottom: 1rem;
    transition: all 0.2s ease;
    cursor: pointer;
  }
  .strand-item:hover {
    background: var(--surface);
    border-color: var(--primary);
    transform: scale(1.01);
  }
  .announcement-timeline {
    position: relative;
    padding-left: 1.5rem;
  }
  .announcement-timeline::before {
    content: '';
    position: absolute;
    left: 4px;
    top: 6px;
    bottom: 6px;
    width: 2px;
    background: var(--border);
  }
  .announcement-item {
    position: relative;
    margin-bottom: 1.5rem;
  }
  .announcement-item::before {
    content: '';
    position: absolute;
    left: -23px;
    top: 6px;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background-color: var(--primary);
    border: 2px solid var(--surface);
    box-shadow: 0 0 0 3px rgba(27, 42, 107, 0.1);
  }
  .announcement-item.suspension::before {
    background-color: #dc2626;
    box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.15);
  }
  .announcement-item:last-child {
    margin-bottom: 0;
  }
</style>

<div class="container-fluid py-2">
  <!-- Active Class Suspension Warning Banner -->
  <?php if (!empty($suspension_alerts)): ?>
  <div class="row g-3 mb-4">
    <div class="col-12">
      <?php foreach($suspension_alerts as $alert): ?>
      <div class="urgent-suspension-banner mb-2">
        <div class="d-flex align-items-center gap-3">
          <div class="pulse-icon-banner">
            <i class="bi bi-exclamation-triangle-fill"></i>
          </div>
          <div class="flex-grow-1">
            <h5 class="mb-1 text-white fw-700"><?= htmlspecialchars($alert['title']) ?></h5>
            <p class="mb-0 text-white-50 small"><?= htmlspecialchars($alert['content']) ?></p>
          </div>
          <button class="banner-close-btn" onclick="this.parentElement.parentElement.remove()">
            <i class="bi bi-x-lg"></i>
          </button>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Premium Hero Welcome Banner -->
  <div class="student-hero-banner">
    <span class="student-badge"><i class="bi bi-shield-check"></i> Active Student Portal</span>
    <h1 class="student-title">Welcome Back, <?= htmlspecialchars($_SESSION['full_name']) ?>!</h1>
    <p class="student-subtitle">Here is your student gateway for <?= htmlspecialchars($settings_data['school_name'] ?? 'our school') ?>. Check announcements<?php if(has_shs()): ?>, explore senior high academic tracks<?php endif; ?>, and access learning resources.</p>
  </div>

  <!-- Vibrant Glassmorphic Stats Row -->
  <div class="row g-3 mb-4">
    <div class="<?= has_shs() ? 'col-md-4' : 'col-md-6' ?>">
      <div class="kpi-card kpi-info shadow-sm" style="border-radius: 16px;">
        <div class="d-flex align-items-center gap-3">
          <div class="kpi-icon navy"><i class="bi bi-people-fill"></i></div>
          <div>
            <div class="kpi-label">Active Campus Population</div>
            <div class="kpi-value text-dark"><?= number_format($total_enroll) ?></div>
            <div class="kpi-sub">Enrolled classmates this S.Y.</div>
          </div>
        </div>
      </div>
    </div>
    <div class="<?= has_shs() ? 'col-md-4' : 'col-md-6' ?>">
      <div class="kpi-card kpi-info shadow-sm" style="border-radius: 16px;">
        <div class="d-flex align-items-center gap-3">
          <div class="kpi-icon teal"><i class="bi bi-building"></i></div>
          <div>
            <div class="kpi-label">Functional Classrooms</div>
            <div class="kpi-value text-dark"><?= $func_rooms ?> Rooms</div>
            <div class="kpi-sub">Fully active learning facilities</div>
          </div>
        </div>
      </div>
    </div>
    <?php if (has_shs()): ?>
    <div class="col-md-4">
      <div class="kpi-card kpi-info shadow-sm" style="border-radius: 16px;">
        <div class="d-flex align-items-center gap-3">
          <div class="kpi-icon gold"><i class="bi bi-journal-bookmark-fill"></i></div>
          <div>
            <div class="kpi-label">Senior High Strands</div>
            <div class="kpi-value text-dark"><?= count($student_strands) ?> Curriculums</div>
            <div class="kpi-sub">Specialized courses offered</div>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Main Grid Content -->
  <div class="row g-4 mb-4">
    <!-- Left: Senior High School Tracks & Strands Explorer -->
    <?php if (has_shs()): ?>
    <div class="col-lg-7">
      <div class="portal-card">
        <div class="portal-card-header">
          <h5 class="portal-card-title"><i class="bi bi-mortarboard-fill text-primary-nhs"></i>Senior High School Track Explorer</h5>
          <span class="badge bg-primary-subtle text-primary fw-600 strand-badge-type">Curriculum Offerings</span>
        </div>
        <div class="p-4">
          <p class="text-muted small mb-4">Click on any strand to see full descriptions, focus subjects, and career alignments. Take control of your academic future!</p>
          
          <div class="strands-list">
            <?php foreach($student_strands as $st): 
              $is_tvl = ($st['track'] === 'TVL');
            ?>
            <div class="strand-item" onclick="showStrandInfo('<?= htmlspecialchars($st['strand_code']) ?>', '<?= htmlspecialchars($st['strand_name']) ?>', '<?= htmlspecialchars($st['track']) ?>', '<?= htmlspecialchars($st['applicable_grades']) ?>')">
              <div class="d-flex align-items-center justify-content-between mb-2">
                <h6 class="fw-700 mb-0 text-dark"><?= htmlspecialchars($st['strand_code']) ?></h6>
                <span class="strand-badge-type <?= $is_tvl ? 'badge-tvl' : 'badge-academic' ?>"><?= htmlspecialchars($st['track']) ?> Track</span>
              </div>
              <div class="fw-500 text-muted small"><?= htmlspecialchars($st['strand_name']) ?></div>
              <div class="text-muted small mt-2"><i class="bi bi-tags me-1"></i>Covered Grades: <strong>G<?= htmlspecialchars($st['applicable_grades']) ?></strong></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- Right: Announcements Timeline & School Philosophy -->
    <div class="<?= has_shs() ? 'col-lg-5' : 'col-12' ?>">
      <div class="row g-4">
        <!-- Announcements Timeline Card -->
        <div class="col-12">
          <div class="portal-card">
            <div class="portal-card-header">
              <h5 class="portal-card-title"><i class="bi bi-megaphone-fill text-primary-nhs"></i>Latest Announcements</h5>
              <span class="badge bg-warning text-dark fw-600 strand-badge-type">School Board</span>
            </div>
            <div class="p-4" style="max-height: 480px; overflow-y: auto;">
              <?php if(empty($student_announcements)): ?>
                <div class="p-4 text-center text-muted">
                  <div style="font-size: 2.5rem;" class="mb-2">ðŸ“¢</div>
                  <h6 class="fw-700 text-dark mb-0">No Announcements</h6>
                  <p class="mb-0 small text-muted">Everything is calm. Check back later for updates!</p>
                </div>
              <?php else: ?>
                <div class="announcement-timeline">
                  <?php foreach($student_announcements as $ann): ?>
                  <div class="announcement-item">
                    <div class="d-flex align-items-center justify-content-between mb-1">
                      <span class="fw-700 text-dark" style="font-size: 0.95rem;"><?= htmlspecialchars($ann['title']) ?></span>
                      <span class="text-muted small" style="font-size:0.75rem;"><i class="bi bi-clock me-1"></i><?= date('M d', strtotime($ann['created_at'])) ?></span>
                    </div>
                    <p class="mb-0 text-muted small" style="line-height: 1.5;"><?= htmlspecialchars($ann['content']) ?></p>
                  </div>
                  <?php endforeach; ?>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <!-- School Mantra Card -->
        <div class="col-12">
          <div class="portal-card text-center" style="background: linear-gradient(135deg, rgba(201, 162, 39, 0.05) 0%, rgba(27, 42, 107, 0.02) 100%);">
            <div class="p-4">
              <div style="font-size: 2.5rem;" class="mb-2">ðŸ†</div>
              <h5 class="fw-700 text-primary-nhs mb-2">Our School Mantra</h5>
              <h6 class="fw-800 text-warning mb-2" style="letter-spacing: 0.5px;">#BEHEALTHYINMIND,BODY,ANDSPIRIT</h6>
              <p class="text-muted small mb-0">Natividad High School: Nurturing students to become holistic individuals with bright futures.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  function showStrandInfo(code, name, track, grades) {
    let description = '';
    let careers = [];
    
    if (code === 'STEM') {
        description = 'The Science, Technology, Engineering, and Mathematics (STEM) strand focuses on equipping students with deep analytical, mathematical, and inquiry skills required in science and technology fields.';
        careers = ['Engineering', 'Medicine & Nursing', 'Information Technology', 'Software Developer', 'Architecture', 'Data Analyst'];
    } else if (code === 'ABM') {
        description = 'The Accountancy, Business, and Management (ABM) strand centers on foundational concepts in corporate finance, business management, marketing operations, and double-entry accounting.';
        careers = ['Accountant', 'Business Owner / Manager', 'Marketing Specialist', 'Financial Analyst', 'HR Administrator'];
    } else if (code === 'HUMSS') {
        description = 'The Humanities and Social Sciences (HUMSS) strand focuses on studying human behavior, social dynamics, literature, civic duties, and creative communication skills.';
        careers = ['Journalist', 'Lawyer', 'Teacher', 'Social Worker', 'Psychologist', 'Public Servant'];
    } else if (code === 'GAS') {
        description = 'The General Academic Strand (GAS) is designed for students who are exploring multiple college courses. It offers a highly flexible subject combination across disciplines.';
        careers = ['College Education Degrees', 'Public Relations', 'Liberal Arts Majors', 'Social Studies Education'];
    } else if (code.startsWith('TVL')) {
        description = 'The Technical-Vocational-Livelihood (TVL) track provides hands-on, industry-aligned training designed to equip students with TESDA NC II certifications for direct employment or business ventures.';
        if (code.includes('ANIMATION')) {
            careers = ['FBS Attendant (Hotel & Restaurant)', '2D/3D Animator', 'Graphic Illustrator', 'Bartender', 'Service Staff'];
        } else if (code.includes('COOKERY')) {
            careers = ['Professional Chef / Cook', 'Catering Manager', 'Restaurant Consultant', 'Food Stylist'];
        } else {
            careers = ['Hospitality Associate', 'Bartending Specialist', 'Barista', 'Event Services Assistant'];
        }
    } else {
        description = 'Specialized strand curriculum focusing on standard academic tracks and career-readiness competencies.';
        careers = ['General Degree Programs', 'Direct Workplace Entry', 'Vocational Trades'];
    }

    Swal.fire({
      title: `<strong>${code} Strand Details</strong>`,
      icon: 'info',
      html: `
        <div style="text-align: left; line-height: 1.6; font-family: 'Outfit', sans-serif; font-size: 0.95rem;">
          <p><strong>Full Name:</strong> ${name}</p>
          <p><strong>Track Category:</strong> <span class="badge bg-primary-subtle text-primary">${track} Track</span></p>
          <hr>
          <p class="text-muted" style="font-size:0.9rem;">${description}</p>
          <hr>
          <p class="mb-1"><strong>ðŸŽ“ Potential Career Pathways:</strong></p>
          <div class="d-flex flex-wrap gap-1.5 mt-2">
            ${careers.map(c => `<span class="badge bg-secondary-subtle text-secondary-emphasis" style="font-size: 0.75rem; padding: 5px 10px; border-radius: 8px;">${c}</span>`).join(' ')}
          </div>
        </div>
      `,
      confirmButtonText: 'Great, Thank You!',
      confirmButtonColor: '#1B2A6B',
      background: document.documentElement.getAttribute('data-theme') === 'dark' ? '#252A44' : '#ffffff',
      color: document.documentElement.getAttribute('data-theme') === 'dark' ? '#DCE2F4' : '#1A1A2E'
    });
  }
</script>

<?php 
    include 'includes/footer.php';
    exit;
endif;
?>
<style>
/* Urgent class suspension banner style */
.urgent-suspension-banner {
  background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%);
  border: 1px solid rgba(220, 38, 38, 0.4);
  border-radius: 16px;
  padding: 18px 24px;
  box-shadow: 0 8px 32px rgba(220, 38, 38, 0.25);
  animation: slideInDown 0.5s ease-out;
  position: relative;
  overflow: hidden;
}
.urgent-suspension-banner::before {
  content: '';
  position: absolute;
  top: -50%;
  right: -20%;
  width: 300px;
  height: 300px;
  background: radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 70%);
  pointer-events: none;
}
.pulse-icon-banner {
  background: rgba(255, 255, 255, 0.2);
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  font-size: 1.35rem;
  animation: pulse-alert 2s infinite;
}
.banner-close-btn {
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  font-size: 1.2rem;
  transition: color 0.2s ease;
  cursor: pointer;
}
.banner-close-btn:hover {
  color: #ffffff;
}
@keyframes pulse-alert {
  0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.4); }
  70% { transform: scale(1.08); box-shadow: 0 0 0 10px rgba(255, 255, 255, 0); }
  100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(255, 255, 255, 0); }
}
@keyframes slideInDown {
  from { transform: translateY(-20px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}
</style>
<div id="dashboardExport">

<?php if (!empty($suspension_alerts)): ?>
<div class="row g-3 mb-4">
  <div class="col-12">
    <?php foreach($suspension_alerts as $alert): ?>
    <div class="urgent-suspension-banner mb-2">
      <div class="d-flex align-items-center gap-3">
        <div class="pulse-icon-banner">
          <i class="bi bi-exclamation-triangle-fill"></i>
        </div>
        <div class="flex-grow-1">
          <h5 class="mb-1 text-white fw-700"><?= htmlspecialchars($alert['title']) ?></h5>
          <p class="mb-0 text-white-50 small"><?= htmlspecialchars($alert['content']) ?></p>
        </div>
        <button class="banner-close-btn" onclick="this.parentElement.parentElement.remove()">
          <i class="bi bi-x-lg"></i>
        </button>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>
<!-- â”€â”€ Section Header â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ -->
<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
  <div class="section-header mb-0">
    <h1 class="section-title"><i class="bi bi-speedometer2 me-2 text-primary-nhs"></i>Performance Dashboard</h1>
    <p class="section-sub">School Year: <strong><?= htmlspecialchars($selected_sy) ?></strong> â€” Real-time KPI Overview</p>
  </div>
  <div class="d-flex gap-2 align-items-center flex-wrap">
    <button type="button" class="btn-outline-nhs" id="commandCenterLauncher" style="display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: .5rem 1.25rem; font-size: .85rem; height: 38px; border-radius: 10px;">
      <i class="bi bi-search"></i> <span>Search Dashboard (Ctrl + K)</span>
    </button>
    <a href="summary_report.php?sy=<?= urlencode($selected_sy) ?>" class="btn-primary-nhs text-white text-decoration-none" style="display: inline-flex; align-items: center; justify-content: center; height: 38px; border-radius: 10px;">
      <i class="bi bi-file-earmark-pdf"></i> Export Summary Report
    </a>
  </div>
</div>

<!-- â”€â”€ KPI ROW 1 â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ -->
<div class="row g-3 mb-4">
  <!-- Total Enrollment -->
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card kpi-info kpi-clickable" data-bs-toggle="modal" data-bs-target="#kpiEnrollModal">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon navy"><i class="bi bi-people-fill"></i></div>
        <div>
          <div class="kpi-label">Total BOSY Enrollment</div>
          <div class="kpi-value text-primary-nhs"><?= number_format($total_enroll) ?></div>
          <div class="kpi-sub">All grade levels</div>
        </div>
      </div>
      <div class="kpi-view-hint"><i class="bi bi-table me-2"></i>View Enrollment by Grade</div>
    </div>
  </div>
  <!-- Repeater Rate -->
  <?php
    $rep_class = $repeater_rate <= 3 ? 'kpi-good' : ($repeater_rate <= 8 ? 'kpi-warn' : 'kpi-danger');
    $rep_color = $repeater_rate <= 3 ? 'green' : ($repeater_rate <= 8 ? 'yellow' : 'red');
    $rep_badge = $repeater_rate <= 3 ? 'badge-good' : ($repeater_rate <= 8 ? 'badge-warn' : 'badge-danger');
    $rep_status = $repeater_rate <= 3 ? 'ðŸŸ¢ Good' : ($repeater_rate <= 8 ? 'ðŸŸ¡ Monitor' : 'ðŸ”´ Critical');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $rep_class ?> kpi-clickable" data-bs-toggle="modal" data-bs-target="#kpiRepeaterModal">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $rep_color ?>"><i class="bi bi-arrow-repeat"></i></div>
        <div>
          <div class="kpi-label">Repeater Rate</div>
          <div class="kpi-value"><?= $repeater_rate ?>%</div>
          <div class="kpi-sub"><?= number_format($total_repeaters) ?> repeaters
            <span class="kpi-badge <?= $rep_badge ?> ms-1"><?= $rep_status ?></span>
          </div>
        </div>
      </div>
      <div class="kpi-view-hint"><i class="bi bi-table me-2"></i>View Repeaters by Grade</div>
    </div>
  </div>
  <!-- Dropout Rate -->
  <?php
    $do_class = $dropout_rate <= 5 ? 'kpi-good' : ($dropout_rate <= 10 ? 'kpi-warn' : 'kpi-danger');
    $do_color = $dropout_rate <= 5 ? 'green' : ($dropout_rate <= 10 ? 'yellow' : 'red');
    $do_badge = $dropout_rate <= 5 ? 'badge-good' : ($dropout_rate <= 10 ? 'badge-warn' : 'badge-danger');
    $do_status= $dropout_rate <= 5 ? 'ðŸŸ¢ Good' : ($dropout_rate <= 10 ? 'ðŸŸ¡ Monitor' : 'ðŸ”´ Critical');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $do_class ?> kpi-clickable" data-bs-toggle="modal" data-bs-target="#kpiDropoutModal">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $do_color ?>"><i class="bi bi-person-dash-fill"></i></div>
        <div>
          <div class="kpi-label">Dropout Rate</div>
          <div class="kpi-value"><?= $dropout_rate ?>%</div>
          <div class="kpi-sub">Retention: <strong><?= $retention_rate ?>%</strong>
            <span class="kpi-badge <?= $do_badge ?> ms-1"><?= $do_status ?></span>
          </div>
        </div>
      </div>
      <div class="kpi-view-hint"><i class="bi bi-table me-2"></i>View Dropouts by Grade</div>
    </div>
  </div>
  <!-- Retention Rate -->
  <?php $ret_class = $retention_rate >= 95 ? 'kpi-good' : ($retention_rate >= 90 ? 'kpi-warn' : 'kpi-danger'); ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $ret_class ?> kpi-clickable" data-bs-toggle="modal" data-bs-target="#kpiRetentionModal">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon green"><i class="bi bi-person-check-fill"></i></div>
        <div>
          <div class="kpi-label">Retention Rate</div>
          <div class="kpi-value text-success"><?= $retention_rate ?>%</div>
          <div class="kpi-sub">Students staying enrolled</div>
        </div>
      </div>
      <div class="kpi-view-hint"><i class="bi bi-table me-2"></i>View Retention by Grade</div>
    </div>
  </div>
</div>

<!-- â”€â”€ KPI ROW 2 â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ -->
<div class="row g-3 mb-4">
  <!-- Classroom Utilization -->
  <?php
    $util_class = $util_rate >= 90 ? 'kpi-good' : ($util_rate >= 70 ? 'kpi-warn' : 'kpi-danger');
    $util_color = $util_rate >= 90 ? 'green' : ($util_rate >= 70 ? 'yellow' : 'red');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $util_class ?> kpi-clickable" data-bs-toggle="modal" data-bs-target="#kpiClassroomModal">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $util_color ?>"><i class="bi bi-building-fill"></i></div>
        <div>
          <div class="kpi-label">Classroom Utilization</div>
          <div class="kpi-value"><?= $util_rate ?>%</div>
          <div class="kpi-sub"><?= $func_rooms ?>/<?= $total_rooms ?> functional &middot; <?= number_format($total_area,0) ?> sqm</div>
        </div>
      </div>
      <div class="kpi-view-hint"><i class="bi bi-building me-2"></i>View Classroom Inventory</div>
    </div>
  </div>
  <!-- Floor Area per Student -->
  <?php
    $area_class = $area_per_student >= 1.4 ? 'kpi-good' : ($area_per_student >= 1.0 ? 'kpi-warn' : 'kpi-danger');
    $area_color = $area_per_student >= 1.4 ? 'green' : ($area_per_student >= 1.0 ? 'yellow' : 'red');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $area_class ?> kpi-clickable" data-bs-toggle="modal" data-bs-target="#kpiAreaModal">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $area_color ?>"><i class="bi bi-grid-3x3"></i></div>
        <div>
          <div class="kpi-label">Floor Area / Student</div>
          <div class="kpi-value"><?= $area_per_student ?> <small class="fs-6">sqm</small></div>
          <div class="kpi-sub">DepEd Standard: 1.4 sqm</div>
        </div>
      </div>
      <div class="kpi-view-hint"><i class="bi bi-grid me-2"></i>View Floor Area Details</div>
    </div>
  </div>
  <!-- Seat Sufficiency -->
  <?php
    $seat_class = $seat_ratio >= 100 ? 'kpi-good' : ($seat_ratio >= 90 ? 'kpi-warn' : 'kpi-danger');
    $seat_color = $seat_ratio >= 100 ? 'green' : ($seat_ratio >= 90 ? 'yellow' : 'red');
    $seat_label = $seat_ratio >= 100 ? 'Sufficient' : ($seat_ratio >= 90 ? 'Near Shortage' : 'Overcrowded');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $seat_class ?> kpi-clickable" data-bs-toggle="modal" data-bs-target="#kpiSeatsModal">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $seat_color ?>"><i class="bi bi-person-workspace"></i></div>
        <div>
          <div class="kpi-label">Seat Sufficiency</div>
          <div class="kpi-value"><?= $seat_ratio ?>%</div>
          <div class="kpi-sub"><?= number_format($total_seats) ?> seats / <?= number_format($total_enroll) ?> students &middot; <em><?= $seat_label ?></em></div>
        </div>
      </div>
      <div class="kpi-view-hint"><i class="bi bi-chair me-2"></i>View Seats by Grade</div>
    </div>
  </div>
  <!-- Teacher Ratio -->
  <?php
    $has_basic = has_jhs() || has_kinder() || has_elementary();
    $teacher_ratio_label = 'Teacher Ratio';
    if ($has_basic && has_shs()) {
      if (has_kinder() || has_elementary()) {
        $teacher_ratio_label = 'Teacher Ratio (K-JHS & SHS)';
      } else {
        $teacher_ratio_label = 'Teacher Ratio (JHS & SHS)';
      }
    } elseif ($has_basic) {
      $teacher_ratio_label = 'Teacher Ratio (Basic Ed)';
    } elseif (has_shs()) {
      $teacher_ratio_label = 'Teacher Ratio (SHS)';
    }

    $combined_rclass = $combined_ratio <= 35 ? 'kpi-good' : ($combined_ratio <= 45 ? 'kpi-warn' : 'kpi-danger');
    $combined_rcolor = $combined_ratio <= 35 ? 'green' : ($combined_ratio <= 45 ? 'yellow' : 'red');
  ?>
  <div class="col-sm-6 col-xl-3">
    <div class="kpi-card <?= $combined_rclass ?> kpi-clickable" data-bs-toggle="modal" data-bs-target="#kpiTeacherModal">
      <div class="d-flex align-items-center gap-3">
        <div class="kpi-icon <?= $combined_rcolor ?>"><i class="bi bi-person-video3"></i></div>
        <div>
          <div class="kpi-label"><?= $teacher_ratio_label ?></div>
          <div class="kpi-value">1 : <?= $combined_ratio ?></div>
          <div class="kpi-sub"><?= $total_teachers ?> teachers &middot; Standard: 1:35</div>
        </div>
      </div>
      <div class="kpi-view-hint"><i class="bi bi-person-badge me-2"></i>View Teacher Distribution</div>
    </div>
  </div>
</div>

<!-- â”€â”€ CHARTS ROW â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ -->
<div class="row g-3 mb-4">
  <!-- Enrollment Trend -->
  <div class="col-xl-8">
    <div class="chart-card">
      <div class="chart-card-title"><i class="bi bi-bar-chart-fill me-2 text-primary-nhs"></i>Enrollment by Grade Level</div>
      <div class="chart-card-sub">BOSY Enrollment distribution â€” S.Y. <?= htmlspecialchars($selected_sy) ?></div>
      <div class="chart-wrapper" style="height:280px">
        <canvas id="enrollChart"></canvas>
      </div>
    </div>
  </div>
  <!-- Facility Status -->
  <div class="col-xl-4">
    <div class="chart-card">
      <div class="chart-card-title"><i class="bi bi-building me-2 text-primary-nhs"></i>Facility Status</div>
      <div class="chart-card-sub">Functional vs. Non-Functional Classrooms</div>
      <div class="chart-wrapper" style="height:280px">
        <canvas id="facilityChart"></canvas>
      </div>
    </div>
  </div>
</div>

<div class="row g-3 mb-4">
  <!-- Performance Health Matrix -->
  <div class="col-xl-7">
    <div class="chart-card">
      <div class="chart-card-title"><i class="bi bi-activity me-2 text-primary-nhs"></i>Performance Health Matrix</div>
      <div class="chart-card-sub">Repeaters vs. Dropouts per Grade Level</div>
      <div class="chart-wrapper" style="height:280px">
        <canvas id="perfChart"></canvas>
      </div>
    </div>
  </div>
  <!-- Resource Allocation -->
  <div class="col-xl-5">
    <div class="chart-card">
      <div class="chart-card-title"><i class="bi bi-person-badge me-2 text-primary-nhs"></i>Teachers per Learning Area</div>
      <div class="chart-card-sub">Workforce distribution â€” <?= htmlspecialchars($selected_sy) ?></div>
      <div class="chart-wrapper" style="height:280px">
        <canvas id="teacherChart"></canvas>
      </div>
    </div>
  </div>
</div>

<!-- â”€â”€ Enrollment Trend Line â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ -->
<div class="row g-3 mb-4">
  <div class="col-12">
    <div class="chart-card">
      <div class="chart-card-title"><i class="bi bi-graph-up-arrow me-2 text-primary-nhs"></i>Enrollment Trend (5-Year)</div>
      <div class="chart-card-sub">Historical total enrollment across all grade levels</div>
      <div class="chart-wrapper" style="height:240px">
        <canvas id="trendChart"></canvas>
      </div>
    </div>
  </div>
</div>

<!-- ── Junior High School / Basic Ed Summary ──────────────── -->
<?php if (has_jhs() || has_kinder() || has_elementary()): 
  $basic_title = "Junior High School Summary";
  if (!has_jhs() && (has_kinder() || has_elementary())) {
    $basic_title = "Basic Education Summary";
  } else if (has_jhs() && (has_kinder() || has_elementary())) {
    $basic_title = "Kinder, Elementary & JHS Summary";
  }
?>
<div class="data-card mb-4">
  <div class="data-card-header">
    <span class="data-card-title"><i class="bi bi-table me-2"></i><?= $basic_title ?></span>
    <?php if(!defined('FEATURE_DATA_ENTRY') || FEATURE_DATA_ENTRY): ?>
    <a href="enrollment.php?sy=<?= urlencode($selected_sy) ?>" class="btn-outline-nhs">
      <i class="bi bi-arrow-right"></i> Manage Data
    </a>
    <?php endif; ?>
  </div>
  <div class="table-responsive">
    <table class="nhs-table">
      <thead>
        <tr>
          <th>Grade Level</th><th>Type</th><th>Enrollment</th>
          <th>Repeaters</th><th>Dropouts</th><th>Rep. Rate</th><th>Drop. Rate</th><th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($perf_matrix as $i => $row):
          $ltype = $enroll_by_grade[$i]['level_type'] ?? '';
          if ($ltype === 'Senior High') continue;
          if ($ltype === 'Kindergarten' && !has_kinder()) continue;
          if ($ltype === 'Elementary' && !has_elementary()) continue;
          if ($ltype === 'Junior High' && !has_jhs()) continue;
          $enroll_g = $enroll_by_grade[$i]['enroll'] ?? 0;
          $r_rate   = $enroll_g > 0 ? round($row['rep']/$enroll_g*100,1) : 0;
          $d_rate   = $enroll_g > 0 ? round($row['drop_']/$enroll_g*100,1) : 0;
          $status   = ($r_rate == 0 && $d_rate == 0) ? 'badge-good' : (($d_rate > 10 || $r_rate > 8) ? 'badge-danger' : 'badge-warn');
          $status_t = ($r_rate == 0 && $d_rate == 0) ? '🎉 Excellent' : (($d_rate > 10 || $r_rate > 8) ? '🔴 Critical' : '🟡 Monitor');
        ?>
        <tr>
          <td class="fw-600"><?= htmlspecialchars($row['grade_name']) ?></td>
          <td><span class="kpi-badge badge-info"><?= $ltype ?></span></td>
          <td><?= number_format($enroll_g) ?></td>
          <td><?= number_format($row['rep']) ?></td>
          <td><?= number_format($row['drop_']) ?></td>
          <td><?= $r_rate ?>%</td>
          <td><?= $d_rate ?>%</td>
          <td><span class="kpi-badge <?= $status ?>"><?= $status_t ?></span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- ── Senior High School Summary ────────────────────────── -->
<?php if (has_shs()): ?>
<div class="data-card mb-4">
  <div class="data-card-header">
    <span class="data-card-title"><i class="bi bi-table me-2"></i>Senior High School Summary</span>
    <?php if(!defined('FEATURE_DATA_ENTRY') || FEATURE_DATA_ENTRY): ?>
    <a href="enrollment.php?sy=<?= urlencode($selected_sy) ?>" class="btn-outline-nhs">
      <i class="bi bi-arrow-right"></i> Manage Data
    </a>
    <?php endif; ?>
  </div>
  <div class="table-responsive">
    <table class="nhs-table">
      <thead>
        <tr>
          <th>Grade Level</th><th>Type</th><th>Enrollment</th>
          <th>Repeater</th><th>Dropouts</th><th>Rep. Rate</th><th>Drop. Rate</th><th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($perf_matrix as $i => $row):
          if (($enroll_by_grade[$i]['level_type'] ?? '') !== 'Senior High') continue;
          $enroll_g = $enroll_by_grade[$i]['enroll'] ?? 0;
          $r_rate   = $enroll_g > 0 ? round($row['rep']/$enroll_g*100,1) : 0;
          $d_rate   = $enroll_g > 0 ? round($row['drop_']/$enroll_g*100,1) : 0;
          $status   = ($r_rate == 0 && $d_rate == 0) ? 'badge-good' : (($d_rate > 10 || $r_rate > 8) ? 'badge-danger' : 'badge-warn');
          $status_t = ($r_rate == 0 && $d_rate == 0) ? '🎉 Excellent' : (($d_rate > 10 || $r_rate > 8) ? '🔴 Critical' : '🟡 Monitor');
        ?>
        <tr>
          <td class="fw-600"><?= htmlspecialchars($row['grade_name']) ?></td>
          <td><span class="kpi-badge badge-primary"><?= $enroll_by_grade[$i]['level_type'] ?? '' ?></span></td>
          <td><?= number_format($enroll_g) ?></td>
          <td><?= number_format($row['rep']) ?></td>
          <td><?= number_format($row['drop_']) ?></td>
          <td><?= $r_rate ?>%</td>
          <td><?= $d_rate ?>%</td>
          <td><span class="kpi-badge <?= $status ?>"><?= $status_t ?></span></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>
</div><!-- end #dashboardExport -->

<!-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
     KPI DETAIL MODALS
â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• -->

<!-- 1. Enrollment Modal -->
<div class="modal fade" id="kpiEnrollModal" tabindex="-1" aria-labelledby="kpiEnrollLabel">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="kpiEnrollLabel"><i class="bi bi-people-fill me-2"></i>Enrollment by Grade Level</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0">
        <div class="kpi-modal-summary">
          <div><div class="kms-label">Total Enrollment</div><div class="kms-val"><?= number_format($total_enroll) ?></div></div>
          <div><div class="kms-label">School Year</div><div class="kms-val" style="font-size:1.1rem"><?= htmlspecialchars($selected_sy) ?></div></div>
          <div><div class="kms-label">Grade Levels</div><div class="kms-val"><?= count($enroll_by_grade) ?></div></div>
          <div><div class="kms-label">JHS Enrollment</div><div class="kms-val" style="font-size:1.1rem"><?= number_format($jhs_enroll) ?></div></div>
          <div><div class="kms-label">SHS Enrollment <small style="font-size:.7rem;opacity:.7">(1st Sem)</small></div><div class="kms-val" style="font-size:1.1rem"><?= number_format($shs_enroll) ?></div></div>
        </div>
        <div class="table-responsive">
          <table class="nhs-table">
            <thead><tr><th>#</th><th>Grade Level</th><th>Type</th><th>BOSY Enrollment</th><th>% of Total</th></tr></thead>
            <tbody>
              <?php foreach($enroll_by_grade as $i=>$r):
                $pct_e = $total_enroll > 0 ? round($r['enroll']/$total_enroll*100,1) : 0;
              ?>
              <tr>
                <td class="text-muted"><?= $i+1 ?></td>
                <td class="fw-600"><?= htmlspecialchars($r['grade_name']) ?></td>
                <td><span class="kpi-badge badge-info"><?= $r['level_type'] ?></span></td>
                <td class="fw-700"><?= number_format($r['enroll']) ?></td>
                <td>
                  <div class="d-flex align-items-center gap-2">
                    <div class="progress flex-grow-1" style="height:6px;min-width:70px">
                      <div class="progress-bar" style="width:<?= $pct_e ?>%;background:var(--primary)"></div>
                    </div>
                    <span class="small"><?= $pct_e ?>%</span>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td colspan="3">TOTAL</td><td><?= number_format($total_enroll) ?></td><td>100%</td></tr></tfoot>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- 2. Repeater Modal -->
<div class="modal fade" id="kpiRepeaterModal" tabindex="-1" aria-labelledby="kpiRepeaterLabel">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="kpiRepeaterLabel"><i class="bi bi-arrow-repeat me-2"></i>Repeater Rate by Grade</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0">
        <div class="kpi-modal-summary">
          <div><div class="kms-label">Total Repeaters</div><div class="kms-val gold"><?= number_format($total_repeaters) ?></div></div>
          <div><div class="kms-label">Overall Rate</div><div class="kms-val gold"><?= $repeater_rate ?>%</div></div>
          <div><div class="kms-label">School Year</div><div class="kms-val" style="font-size:1.1rem"><?= htmlspecialchars($selected_sy) ?></div></div>
          <div><div class="kms-label">DepEd Threshold</div><div class="kms-val" style="font-size:1.1rem">&le; 3%</div></div>
        </div>
        <div class="table-responsive">
          <table class="nhs-table">
            <thead><tr><th>Grade Level</th><th>Type</th><th>Enrollment</th><th>Repeaters</th><th>Rate</th><th>Status</th></tr></thead>
            <tbody>
              <?php foreach($perf_matrix as $i=>$row):
                $enroll_g = $enroll_by_grade[$i]['enroll'] ?? 0;
                $r_rate   = $enroll_g > 0 ? round($row['rep']/$enroll_g*100,1) : 0;
                $r_bdg    = $r_rate <= 3 ? 'badge-good' : ($r_rate <= 8 ? 'badge-warn' : 'badge-danger');
                $r_lbl    = $r_rate <= 3 ? 'ðŸŸ¢ Good'    : ($r_rate <= 8 ? 'ðŸŸ¡ Monitor' : 'ðŸ”´ Critical');
              ?>
              <tr>
                <td class="fw-600"><?= htmlspecialchars($row['grade_name']) ?></td>
                <td><span class="kpi-badge badge-info"><?= $enroll_by_grade[$i]['level_type'] ?></span></td>
                <td><?= number_format($enroll_g) ?></td>
                <td class="fw-700"><?= number_format($row['rep']) ?></td>
                <td><?= $r_rate ?>%</td>
                <td><span class="kpi-badge <?= $r_bdg ?>"><?= $r_lbl ?></span></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td colspan="3">TOTAL</td><td><?= number_format($total_repeaters) ?></td><td><?= $repeater_rate ?>%</td><td></td></tr></tfoot>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- 3. Dropout Modal -->
<div class="modal fade" id="kpiDropoutModal" tabindex="-1" aria-labelledby="kpiDropoutLabel">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="kpiDropoutLabel"><i class="bi bi-person-dash-fill me-2"></i>Dropout Rate by Grade</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0">
        <div class="kpi-modal-summary">
          <div><div class="kms-label">Total Dropouts</div><div class="kms-val red"><?= number_format($total_dropouts) ?></div></div>
          <div><div class="kms-label">Dropout Rate</div><div class="kms-val red"><?= $dropout_rate ?>%</div></div>
          <div><div class="kms-label">Retention Rate</div><div class="kms-val green"><?= $retention_rate ?>%</div></div>
          <div><div class="kms-label">School Year</div><div class="kms-val" style="font-size:1.1rem"><?= htmlspecialchars($selected_sy) ?></div></div>
        </div>
        <div class="table-responsive">
          <table class="nhs-table">
            <thead><tr><th>Grade Level</th><th>Type</th><th>Enrollment</th><th>Dropouts</th><th>Rate</th><th>Status</th></tr></thead>
            <tbody>
              <?php foreach($perf_matrix as $i=>$row):
                $enroll_g = $enroll_by_grade[$i]['enroll'] ?? 0;
                $d_rate   = $enroll_g > 0 ? round($row['drop_']/$enroll_g*100,1) : 0;
                $d_bdg    = $d_rate <= 5 ? 'badge-good' : ($d_rate <= 10 ? 'badge-warn' : 'badge-danger');
                $d_lbl    = $d_rate <= 5 ? 'ðŸŸ¢ Good'    : ($d_rate <= 10 ? 'ðŸŸ¡ Monitor' : 'ðŸ”´ Critical');
              ?>
              <tr>
                <td class="fw-600"><?= htmlspecialchars($row['grade_name']) ?></td>
                <td><span class="kpi-badge badge-info"><?= $enroll_by_grade[$i]['level_type'] ?></span></td>
                <td><?= number_format($enroll_g) ?></td>
                <td class="fw-700"><?= number_format($row['drop_']) ?></td>
                <td><?= $d_rate ?>%</td>
                <td><span class="kpi-badge <?= $d_bdg ?>"><?= $d_lbl ?></span></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td colspan="3">TOTAL</td><td><?= number_format($total_dropouts) ?></td><td><?= $dropout_rate ?>%</td><td></td></tr></tfoot>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- 4. Retention Modal -->
<div class="modal fade" id="kpiRetentionModal" tabindex="-1" aria-labelledby="kpiRetentionLabel">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="kpiRetentionLabel"><i class="bi bi-person-check-fill me-2"></i>Retention Rate by Grade</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0">
        <div class="kpi-modal-summary">
          <div><div class="kms-label">Overall Retention</div><div class="kms-val green"><?= $retention_rate ?>%</div></div>
          <div><div class="kms-label">Total Enrolled</div><div class="kms-val"><?= number_format($total_enroll) ?></div></div>
          <div><div class="kms-label">Retained Students</div><div class="kms-val green"><?= number_format($total_enroll - $total_dropouts) ?></div></div>
          <div><div class="kms-label">Dropouts</div><div class="kms-val red"><?= number_format($total_dropouts) ?></div></div>
        </div>
        <div class="table-responsive">
          <table class="nhs-table">
            <thead><tr><th>Grade Level</th><th>Type</th><th>Enrollment</th><th>Dropouts</th><th>Retained</th><th>Retention Rate</th></tr></thead>
            <tbody>
              <?php foreach($perf_matrix as $i=>$row):
                $enroll_g  = $enroll_by_grade[$i]['enroll'] ?? 0;
                $d_rate    = $enroll_g > 0 ? round($row['drop_']/$enroll_g*100,1) : 0;
                $ret_r     = round(100 - $d_rate, 1);
                $retained  = $enroll_g - $row['drop_'];
                $ret_bdg   = $ret_r >= 95 ? 'badge-good' : ($ret_r >= 90 ? 'badge-warn' : 'badge-danger');
              ?>
              <tr>
                <td class="fw-600"><?= htmlspecialchars($row['grade_name']) ?></td>
                <td><span class="kpi-badge badge-info"><?= $enroll_by_grade[$i]['level_type'] ?></span></td>
                <td><?= number_format($enroll_g) ?></td>
                <td><?= number_format($row['drop_']) ?></td>
                <td class="fw-700"><?= number_format($retained) ?></td>
                <td><span class="kpi-badge <?= $ret_bdg ?>"><?= $ret_r ?>%</span></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td colspan="4">TOTAL RETAINED</td><td><?= number_format($total_enroll - $total_dropouts) ?></td><td><?= $retention_rate ?>%</td></tr></tfoot>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- 5. Classroom Utilization Modal -->
<div class="modal fade" id="kpiClassroomModal" tabindex="-1" aria-labelledby="kpiClassroomLabel">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="kpiClassroomLabel"><i class="bi bi-building-fill me-2"></i>Classroom Inventory</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0">
        <div class="kpi-modal-summary">
          <div><div class="kms-label">Total Rooms</div><div class="kms-val"><?= $total_rooms ?></div></div>
          <div><div class="kms-label">Functional</div><div class="kms-val green"><?= $func_rooms ?></div></div>
          <div><div class="kms-label">Non-Functional</div><div class="kms-val red"><?= $total_rooms - $func_rooms ?></div></div>
          <div><div class="kms-label">Utilization Rate</div><div class="kms-val"><?= $util_rate ?>%</div></div>
          <div><div class="kms-label">Total Area</div><div class="kms-val" style="font-size:1.1rem"><?= number_format($total_area,0) ?> sqm</div></div>
        </div>
        <div class="table-responsive">
          <table class="nhs-table">
            <thead><tr><th>#</th><th>Room Code</th><th>Length (m)</th><th>Width (m)</th><th>Area (sqm)</th><th>Status</th><th>Notes</th></tr></thead>
            <tbody>
              <?php foreach($classrooms_detail as $i=>$r): ?>
              <tr>
                <td class="text-muted"><?= $i+1 ?></td>
                <td class="fw-600"><?= htmlspecialchars($r['room_code']) ?></td>
                <td><?= $r['length_m'] ?></td>
                <td><?= $r['width_m'] ?></td>
                <td class="fw-700"><?= number_format($r['total_area'],2) ?></td>
                <td><?php if($r['is_functional']): ?><span class="kpi-badge badge-good">âœ… Functional</span><?php else: ?><span class="kpi-badge badge-danger">âŒ Non-Functional</span><?php endif; ?></td>
                <td class="text-muted small"><?= htmlspecialchars($r['notes']??'') ?></td>
              </tr>
              <?php endforeach; ?>
              <?php if(empty($classrooms_detail)): ?>
              <tr><td colspan="7" class="text-center text-muted py-4"><i class="bi bi-inbox me-2"></i>No classroom data found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
        <div class="p-3 border-top text-end">
          <a href="facilities.php" class="btn-outline-nhs"><i class="bi bi-arrow-right me-1"></i>Manage Facilities</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- 6. Floor Area Modal -->
<div class="modal fade" id="kpiAreaModal" tabindex="-1" aria-labelledby="kpiAreaLabel">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="kpiAreaLabel"><i class="bi bi-grid-3x3 me-2"></i>Floor Area Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0">
        <div class="kpi-modal-summary">
          <div><div class="kms-label">Total Functional Area</div><div class="kms-val"><?= number_format($total_area,0) ?> sqm</div></div>
          <div><div class="kms-label">Area per Student</div><div class="kms-val <?= $area_per_student >= 1.4 ? 'green' : ($area_per_student >= 1.0 ? 'gold' : 'red') ?>"><?= $area_per_student ?> sqm</div></div>
          <div><div class="kms-label">DepEd Standard</div><div class="kms-val" style="font-size:1.1rem">&ge; 1.4 sqm</div></div>
          <div><div class="kms-label">Total Students</div><div class="kms-val" style="font-size:1.1rem"><?= number_format($total_enroll) ?></div></div>
        </div>
        <div class="table-responsive">
          <table class="nhs-table">
            <thead><tr><th>#</th><th>Room Code</th><th>Area (sqm)</th><th>Status</th><th>% of Total Area</th></tr></thead>
            <tbody>
              <?php foreach($classrooms_detail as $i=>$r):
                $a_contrib = $total_area > 0 ? round($r['total_area']/$total_area*100,1) : 0;
              ?>
              <tr>
                <td class="text-muted"><?= $i+1 ?></td>
                <td class="fw-600"><?= htmlspecialchars($r['room_code']) ?></td>
                <td class="fw-700"><?= number_format($r['total_area'],2) ?></td>
                <td><?php if($r['is_functional']): ?><span class="kpi-badge badge-good">âœ… Functional</span><?php else: ?><span class="kpi-badge badge-danger">âŒ Non-Functional</span><?php endif; ?></td>
                <td>
                  <div class="d-flex align-items-center gap-2">
                    <div class="progress flex-grow-1" style="height:6px;min-width:70px">
                      <div class="progress-bar" style="width:<?= $a_contrib ?>%;background:var(--accent)"></div>
                    </div>
                    <span class="small"><?= $a_contrib ?>%</span>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td colspan="2">TOTAL</td><td><?= number_format($total_area,2) ?> sqm</td><td></td><td>100%</td></tr></tfoot>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- 7. Seat Sufficiency Modal -->
<div class="modal fade" id="kpiSeatsModal" tabindex="-1" aria-labelledby="kpiSeatsLabel">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="kpiSeatsLabel"><i class="bi bi-person-workspace me-2"></i>Seat Sufficiency by Grade</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0">
        <div class="kpi-modal-summary">
          <div><div class="kms-label">Available Seats</div><div class="kms-val"><?= number_format($total_seats) ?></div></div>
          <div><div class="kms-label">Total Students</div><div class="kms-val"><?= number_format($total_enroll) ?></div></div>
          <div><div class="kms-label">Seat Ratio</div><div class="kms-val <?= $seat_ratio >= 100 ? 'green' : ($seat_ratio >= 90 ? 'gold' : 'red') ?>"><?= $seat_ratio ?>%</div></div>
          <div><div class="kms-label">Status</div><div class="kms-val" style="font-size:1rem"><?= $seat_label ?></div></div>
        </div>
        <div class="table-responsive">
          <table class="nhs-table">
            <thead><tr><th>#</th><th>Grade Level</th><th>Type</th><th>Strand</th><th>Available Seats</th><th>School Year</th></tr></thead>
            <tbody>
              <?php foreach($seats_detail as $i=>$r): ?>
              <tr>
                <td class="text-muted"><?= $i+1 ?></td>
                <td class="fw-600"><?= htmlspecialchars($r['grade_name']) ?></td>
                <td><span class="kpi-badge badge-info"><?= $r['level_type'] ?></span></td>
                <td><?= htmlspecialchars($r['strand_code']??'â€”') ?></td>
                <td class="fw-700"><?= number_format($r['available_seats']) ?></td>
                <td><?= htmlspecialchars($r['school_year']) ?></td>
              </tr>
              <?php endforeach; ?>
              <?php if(empty($seats_detail)): ?>
              <tr><td colspan="6" class="text-center text-muted py-4"><i class="bi bi-inbox me-2"></i>No seat data for <?= htmlspecialchars($selected_sy) ?>.</td></tr>
              <?php endif; ?>
            </tbody>
            <tfoot><tr><td colspan="4">TOTAL SEATS</td><td><?= number_format($total_seats) ?></td><td></td></tr></tfoot>
          </table>
        </div>
        <div class="p-3 border-top text-end">
          <a href="facilities.php" class="btn-outline-nhs"><i class="bi bi-arrow-right me-1"></i>Manage Seats</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- 8. Teacher Distribution Modal -->
<div class="modal fade" id="kpiTeacherModal" tabindex="-1" aria-labelledby="kpiTeacherLabel">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="kpiTeacherLabel"><i class="bi bi-person-badge me-2"></i>Teacher Distribution</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-0">
        <div class="kpi-modal-summary">
          <?php if (has_jhs() || has_kinder() || has_elementary()): 
            $basic_teacher_lbl = "JHS Teachers";
            $basic_ratio_lbl = "JHS Ratio";
            if (!has_jhs() && (has_kinder() || has_elementary())) {
              $basic_teacher_lbl = "Basic Ed Teachers";
              $basic_ratio_lbl = "Basic Ed Ratio";
            } else if (has_jhs() && (has_kinder() || has_elementary())) {
              $basic_teacher_lbl = "K-JHS Teachers";
              $basic_ratio_lbl = "K-JHS Ratio";
            }
          ?>
          <div><div class="kms-label"><?= $basic_teacher_lbl ?></div><div class="kms-val"><?= $jhs_teachers ?></div></div>
          <div><div class="kms-label"><?= $basic_ratio_lbl ?></div><div class="kms-val <?= $jhs_ratio <= 35 ? 'green' : ($jhs_ratio <= 45 ? 'gold' : 'red') ?>">1 : <?= $jhs_ratio ?></div></div>
          <?php endif; ?>
          <?php if (has_shs()): ?>
          <div><div class="kms-label">SHS Teachers</div><div class="kms-val"><?= $shs_teachers ?></div></div>
          <div><div class="kms-label">SHS Ratio</div><div class="kms-val <?= $shs_ratio <= 35 ? 'green' : ($shs_ratio <= 45 ? 'gold' : 'red') ?>">1 : <?= $shs_ratio ?></div></div>
          <?php endif; ?>
          <div><div class="kms-label">DepEd Standard</div><div class="kms-val" style="font-size:1rem">1 : 35</div></div>
        </div>
        <div class="table-responsive">
          <table class="nhs-table">
            <thead><tr><th>#</th><th>Learning Area</th><th>Level</th><th>Teachers</th><th>Distribution</th></tr></thead>
            <tbody>
              <?php
                $total_t = array_sum(array_column($teacher_areas,'teacher_count'));
                foreach($teacher_areas as $i=>$r):
                  $t_pct = $total_t > 0 ? round($r['teacher_count']/$total_t*100,1) : 0;
              ?>
              <tr>
                <td class="text-muted"><?= $i+1 ?></td>
                <td class="fw-600"><?= htmlspecialchars($r['learning_area']) ?></td>
                <td><span class="kpi-badge badge-info"><?= $r['level_type'] ?></span></td>
                <td class="fw-700"><?= $r['teacher_count'] ?></td>
                <td>
                  <div class="d-flex align-items-center gap-2">
                    <div class="progress flex-grow-1" style="height:6px;min-width:70px">
                      <div class="progress-bar" style="width:<?= $t_pct ?>%;background:var(--accent)"></div>
                    </div>
                    <span class="small"><?= $t_pct ?>%</span>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if(empty($teacher_areas)): ?>
              <tr><td colspan="5" class="text-center text-muted py-4"><i class="bi bi-inbox me-2"></i>No teacher data for <?= htmlspecialchars($selected_sy) ?>.</td></tr>
              <?php endif; ?>
            </tbody>
            <tfoot><tr><td colspan="3">TOTAL</td><td><?= $total_t ?? 0 ?></td><td>100%</td></tr></tfoot>
          </table>
        </div>
        <div class="p-3 border-top text-end">
          <a href="human_resources.php" class="btn-outline-nhs"><i class="bi bi-arrow-right me-1"></i>Manage HR Data</a>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
// â”€â”€ Chart data from PHP â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const enrollLabels = <?= json_encode(array_column($enroll_by_grade,'grade_name')) ?>;
const enrollData   = <?= json_encode(array_column($enroll_by_grade,'enroll')) ?>;
const perfLabels   = <?= json_encode(array_column($perf_matrix,'grade_name')) ?>;
const perfRep      = <?= json_encode(array_column($perf_matrix,'rep')) ?>;
const perfDrop     = <?= json_encode(array_column($perf_matrix,'drop_')) ?>;
const funcRooms    = <?= $func_rooms ?>;
const nonFuncRooms = <?= $total_rooms - $func_rooms ?>;
const taLabels     = <?= json_encode(array_column($teacher_areas,'learning_area')) ?>;
const taData       = <?= json_encode(array_column($teacher_areas,'teacher_count')) ?>;
const trendLabels  = <?= json_encode(array_column($enroll_trend,'school_year')) ?>;
const trendData    = <?= json_encode(array_column($enroll_trend,'total')) ?>;

// --- âš¡ Proper Contrast & Theme Settings for Highly Readable NHS Charts ---
const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
const textColor = isDark ? '#F1F4FD' : '#1A1A2E'; // Bold, crisp text for ultimate legibility
const gridColor = isDark ? 'rgba(61, 70, 112, 0.4)' : '#E2E8F0'; // Soft readable grids

// Bold and clear fonts for high readability/accessibility
Chart.defaults.font.family = "'Poppins', sans-serif";
Chart.defaults.font.size   = 12;
Chart.defaults.font.weight = '600'; // Global semi-bold text inside charts
Chart.defaults.color       = textColor;

// Dynamic High-Contrast Semantic Colors
const chartNavy  = isDark ? '#6B9BE8' : '#1B2A6B';
const chartGold  = isDark ? '#F0CA76' : '#C9A227';
const chartRed   = isDark ? '#F5A0A0' : '#8B1A1A';
const chartGreen = isDark ? '#7DD9A3' : '#16a34a';

// Grades-demarcated high-contrast palette for Enrollment bar chart
const themePalette = isDark ? [
  '#6B9BE8', '#F0CA76', '#F5A0A0', '#56C1FF', '#FFBD80', '#A5D6A7'
] : [
  '#1B2A6B', '#C9A227', '#8B1A1A', '#2E3F8F', '#A07D0F', '#B02020'
];

// 1. Enrollment Bar Chart (Solid Distinct Colors per Grade)
const enrollCtx = document.getElementById('enrollChart').getContext('2d');
new Chart(enrollCtx, {
  type: 'bar',
  data: {
    labels: enrollLabels,
    datasets: [{
      label: 'BOSY Enrollment',
      data: enrollData,
      backgroundColor: themePalette,
      borderRadius: 6,
      borderSkipped: false,
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { 
      legend: { display: false }, 
      tooltip: { 
        backgroundColor: isDark ? '#252A44' : '#ffffff',
        titleColor: isDark ? '#ffffff' : '#1A1A2E',
        titleFont: { family: 'Poppins', weight: '700', size: 13 },
        bodyColor: textColor,
        bodyFont: { family: 'Poppins', weight: '600', size: 12 },
        borderColor: isDark ? '#3D4670' : '#cbd5e1',
        borderWidth: 1,
        callbacks: { label: ctx => ' ' + ctx.parsed.y.toLocaleString() + ' students' } 
      } 
    },
    scales: {
      y: { 
        grid: { color: gridColor }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 }, 
          callback: v => v.toLocaleString() 
        } 
      },
      x: { 
        grid: { display: false }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 } 
        } 
      }
    }
  }
});

// 2. Facility Status (Solid Green/Red)
const facilityCtx = document.getElementById('facilityChart').getContext('2d');
new Chart(facilityCtx, {
  type: 'doughnut',
  data: {
    labels: ['Functional', 'Non-Functional'],
    datasets: [{ 
      data: [funcRooms, nonFuncRooms], 
      backgroundColor: [chartGreen, chartRed], 
      borderWidth: isDark ? 2 : 1, 
      borderColor: isDark ? '#20253E' : '#ffffff',
      hoverOffset: 8 
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: {
      legend: { 
        position: 'bottom', 
        labels: { 
          padding: 16, 
          usePointStyle: true, 
          color: textColor, 
          font: { weight: '600', size: 12 } 
        } 
      },
      tooltip: { 
        backgroundColor: isDark ? '#252A44' : '#ffffff',
        titleColor: isDark ? '#ffffff' : '#1A1A2E',
        titleFont: { family: 'Poppins', weight: '700', size: 13 },
        bodyColor: textColor,
        bodyFont: { family: 'Poppins', weight: '600', size: 12 },
        borderColor: isDark ? '#3D4670' : '#cbd5e1',
        borderWidth: 1,
        callbacks: { label: ctx => ` ${ctx.label}: ${ctx.parsed} rooms` } 
      }
    },
    cutout: '68%'
  }
});

// 3. Performance Health Matrix (Solid Gold/Red)
const perfCtx = document.getElementById('perfChart').getContext('2d');
new Chart(perfCtx, {
  type: 'bar',
  data: {
    labels: perfLabels,
    datasets: [
      { 
        label: 'Repeaters', 
        data: perfRep,  
        backgroundColor: chartGold, 
        borderRadius: 5 
      },
      { 
        label: 'Dropouts',  
        data: perfDrop, 
        backgroundColor: chartRed, 
        borderRadius: 5 
      }
    ]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { 
      legend: { 
        position: 'bottom',
        labels: { 
          color: textColor, 
          boxWidth: 12, 
          padding: 12, 
          font: { weight: '600', size: 12 } 
        }
      },
      tooltip: {
        backgroundColor: isDark ? '#252A44' : '#ffffff',
        titleColor: isDark ? '#ffffff' : '#1A1A2E',
        titleFont: { family: 'Poppins', weight: '700', size: 13 },
        bodyColor: textColor,
        bodyFont: { family: 'Poppins', weight: '600', size: 12 },
        borderColor: isDark ? '#3D4670' : '#cbd5e1',
        borderWidth: 1
      }
    },
    scales: {
      y: { 
        grid: { color: gridColor }, 
        beginAtZero: true, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 } 
        } 
      },
      x: { 
        grid: { display: false }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 } 
        } 
      }
    }
  }
});

// 4. Teacher Resource Horizontal Bar (Solid Navy)
const teacherCtx = document.getElementById('teacherChart').getContext('2d');
new Chart(teacherCtx, {
  type: 'bar',
  data: {
    labels: taLabels,
    datasets: [{ 
      label: 'Teachers', 
      data: taData, 
      backgroundColor: chartNavy, 
      borderRadius: 5 
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false, indexAxis: 'y',
    plugins: { 
      legend: { display: false },
      tooltip: {
        backgroundColor: isDark ? '#252A44' : '#ffffff',
        titleColor: isDark ? '#ffffff' : '#1A1A2E',
        titleFont: { family: 'Poppins', weight: '700', size: 13 },
        bodyColor: textColor,
        bodyFont: { family: 'Poppins', weight: '600', size: 12 },
        borderColor: isDark ? '#3D4670' : '#cbd5e1',
        borderWidth: 1
      }
    },
    scales: {
      x: { 
        grid: { color: gridColor }, 
        beginAtZero: true, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 }, 
          stepSize: 1 
        } 
      },
      y: { 
        grid: { display: false }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 11 } 
        } 
      }
    }
  }
});

// 5. Enrollment Trend Line (Solid Navy with Soft Fill Glow)
const trendCtx = document.getElementById('trendChart').getContext('2d');
const trendGrad = trendCtx.createLinearGradient(0, 0, 0, 240);
trendGrad.addColorStop(0, isDark ? 'rgba(107, 155, 232, 0.25)' : 'rgba(27, 42, 107, 0.15)');
trendGrad.addColorStop(1, 'rgba(27, 42, 107, 0.0)');

new Chart(trendCtx, {
  type: 'line',
  data: {
    labels: trendLabels,
    datasets: [{
      label: 'Total Enrollment',
      data: trendData,
      borderColor: chartNavy,
      backgroundColor: trendGrad,
      fill: true,
      tension: 0.4,
      pointBackgroundColor: chartGold,
      pointBorderColor: chartNavy,
      pointBorderWidth: 2,
      pointRadius: 5,
      pointHoverRadius: 8
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { 
      legend: { display: false },
      tooltip: {
        backgroundColor: isDark ? '#252A44' : '#ffffff',
        titleColor: isDark ? '#ffffff' : '#1A1A2E',
        titleFont: { family: 'Poppins', weight: '700', size: 13 },
        bodyColor: textColor,
        bodyFont: { family: 'Poppins', weight: '600', size: 12 },
        borderColor: isDark ? '#3D4670' : '#cbd5e1',
        borderWidth: 1
      }
    },
    scales: {
      y: { 
        grid: { color: gridColor }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 }, 
          callback: v => v.toLocaleString() 
        } 
      },
      x: { 
        grid: { display: false }, 
        ticks: { 
          color: textColor, 
          font: { weight: '600', size: 12 } 
        } 
      }
    }
  }
});
});
</script>

<!-- â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
     âš¡ COMMAND CENTER SEARCH PALETTE (CTRL + K)
     â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â• -->
<div id="commandCenterModal" class="command-modal-overlay">
  <div class="command-modal-dialog">
    <!-- Search Input Wrapper -->
    <div class="command-modal-search-wrapper">
      <i class="bi bi-search command-search-icon"></i>
      <input type="text" id="commandSearchInput" placeholder="Type to search (e.g. seats, dropout, Grade 7)..." autocomplete="off">
      <span class="command-esc-badge">ESC</span>
    </div>
    
    <!-- Suggestions Panel (Shown when input is empty) -->
    <div id="commandSuggestionsPanel" class="command-panel">
      <div class="command-panel-title">Suggested Searches</div>
      <div class="command-suggestions-list">
        <div class="command-suggestion-item" data-search="Grade 7">
          <i class="bi bi-arrow-right-short text-accent"></i> <span>Grade 7 enrollment and performance</span>
        </div>
        <div class="command-suggestion-item" data-search="seats">
          <i class="bi bi-arrow-right-short text-accent"></i> <span>Seat sufficiency and details</span>
        </div>
        <div class="command-suggestion-item" data-search="dropout">
          <i class="bi bi-arrow-right-short text-accent"></i> <span>Dropout rate and retention status</span>
        </div>
        <div class="command-suggestion-item" data-search="classrooms">
          <i class="bi bi-arrow-right-short text-accent"></i> <span>Classroom inventory and utilization</span>
        </div>
        <div class="command-suggestion-item" data-search="teacher ratio">
          <i class="bi bi-arrow-right-short text-accent"></i> <span>Student-to-Teacher workload ratios</span>
        </div>
      </div>
    </div>
    
    <!-- Results Panel (Shown when searching) -->
    <div id="commandResultsPanel" class="command-panel" style="display: none;">
      <div class="command-panel-title" id="commandResultsTitle">Matching Results</div>
      <div id="commandResultsList" class="command-results-list">
        <!-- Search results injected here dynamically -->
      </div>
    </div>
    
    <!-- Keyboard Navigation Guide Footer -->
    <div class="command-modal-footer-nav">
      <span><kbd>â†‘â†“</kbd> Navigate</span>
      <span><kbd>Enter</kbd> Select</span>
      <span><kbd>Esc</kbd> Close</span>
    </div>
  </div>
</div>

<style>
/* â”€â”€ Command Center Custom Overlay Styling â”€â”€ */
.command-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(15, 23, 42, 0.45);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  z-index: 9999;
  display: none;
  align-items: flex-start;
  justify-content: center;
  padding-top: 10vh;
  animation: commandFadeIn 0.2s ease-out;
}

@keyframes commandFadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.command-modal-dialog {
  width: 90%;
  max-width: 600px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 16px;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.15), 0 10px 10px -5px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  animation: commandSlideDown 0.25s cubic-bezier(0.16, 1, 0.3, 1);
}

@keyframes commandSlideDown {
  from { transform: translateY(-20px) scale(0.98); opacity: 0; }
  to { transform: translateY(0) scale(1); opacity: 1; }
}

.command-modal-search-wrapper {
  display: flex;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid var(--border);
  gap: 14px;
  background: rgba(255, 255, 255, 0.02);
}

.command-search-icon {
  font-size: 1.3rem;
  color: var(--text-muted);
  flex-shrink: 0;
}

#commandSearchInput {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  font-size: 1.05rem;
  color: var(--text);
  font-family: 'Poppins', sans-serif;
  padding: 0;
}

#commandSearchInput::placeholder {
  color: var(--text-muted);
  opacity: 0.7;
}

.command-esc-badge {
  font-size: 0.68rem;
  font-weight: 700;
  color: var(--text-muted);
  background: var(--bg);
  border: 1.5px solid var(--border);
  padding: 2px 6px;
  border-radius: 6px;
  letter-spacing: 0.5px;
  flex-shrink: 0;
}

.command-panel {
  padding: 16px 20px;
  max-height: 380px;
  overflow-y: auto;
  border-bottom: 1px solid var(--border);
}

.command-panel-title {
  font-size: 0.72rem;
  font-weight: 700;
  color: var(--accent-dark);
  text-transform: uppercase;
  letter-spacing: 0.8px;
  margin-bottom: 12px;
}

.command-suggestions-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.command-suggestion-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px;
  border-radius: 10px;
  font-size: 0.85rem;
  color: var(--text);
  cursor: pointer;
  transition: all 0.15s ease;
  background: var(--bg);
}

.command-suggestion-item:hover {
  background: var(--border);
  color: var(--accent-dark);
  transform: translateX(4px);
}

[data-theme="dark"] .command-suggestion-item:hover {
  color: var(--accent);
}

.command-results-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.command-result-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 14px;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.15s ease;
  border: 1.5px solid transparent;
  background: transparent;
  text-decoration: none;
}

.command-result-item:hover,
.command-result-item.focused {
  background: var(--bg);
  border-color: var(--accent);
  outline: none;
}

.command-result-left {
  display: flex;
  align-items: center;
  gap: 14px;
}

.command-result-icon-wrapper {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.05rem;
  flex-shrink: 0;
}

/* Category Specific Backgrounds */
.command-result-icon-wrapper.enrollment { background: rgba(27, 42, 107, 0.1); color: #1B2A6B; }
.command-result-icon-wrapper.retention { background: rgba(22, 163, 74, 0.1); color: #16a34a; }
.command-result-icon-wrapper.facilities { background: rgba(46, 107, 158, 0.1); color: #2E6B9E; }
.command-result-icon-wrapper.teachers { background: rgba(201, 162, 39, 0.15); color: #C9A227; }
.command-result-icon-wrapper.navigation { background: rgba(139, 26, 26, 0.1); color: #8B1A1A; }

[data-theme="dark"] .command-result-icon-wrapper.enrollment { background: rgba(107, 155, 232, 0.18); color: #6B9BE8; }
[data-theme="dark"] .command-result-icon-wrapper.retention { background: rgba(125, 217, 163, 0.18); color: #7DD9A3; }
[data-theme="dark"] .command-result-icon-wrapper.facilities { background: rgba(125, 207, 245, 0.18); color: #7DCFF5; }
[data-theme="dark"] .command-result-icon-wrapper.teachers { background: rgba(240, 202, 118, 0.18); color: #F0CA76; }
[data-theme="dark"] .command-result-icon-wrapper.navigation { background: rgba(245, 160, 160, 0.18); color: #F5A0A0; }

.command-result-info {
  display: flex;
  flex-direction: column;
  text-align: left;
}

.command-result-title {
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--text);
  line-height: 1.3;
}

.command-result-category {
  font-size: 0.7rem;
  color: var(--text-muted);
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.3px;
  margin-top: 1px;
}

.command-result-value-badge {
  font-size: 0.8rem;
  font-weight: 700;
  padding: 4px 10px;
  border-radius: 20px;
  letter-spacing: 0.2px;
  background: var(--border);
  color: var(--text);
}

.command-result-item:hover .command-result-value-badge,
.command-result-item.focused .command-result-value-badge {
  background: var(--primary);
  color: #fff;
}

[data-theme="dark"] .command-result-item:hover .command-result-value-badge,
[data-theme="dark"] .command-result-item.focused .command-result-value-badge {
  background: var(--accent);
  color: var(--primary-dark);
}

.command-no-results {
  text-align: center;
  padding: 28px 0;
  color: var(--text-muted);
  font-size: 0.85rem;
}

.command-modal-footer-nav {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 10px 20px;
  background: var(--bg);
  font-size: 0.68rem;
  color: var(--text-muted);
  font-weight: 600;
  border-top: 1px solid var(--border);
}

.command-modal-footer-nav kbd {
  font-family: inherit;
  background: var(--surface);
  border: 1px solid var(--border);
  color: var(--text);
  padding: 1px 4px;
  border-radius: 4px;
  box-shadow: 0 1px 0 rgba(0,0,0,0.1);
  margin-right: 2px;
}

[data-theme="dark"] .command-modal-overlay {
  background: rgba(8, 12, 23, 0.65);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const modal = document.getElementById('commandCenterModal');
  const input = document.getElementById('commandSearchInput');
  const suggestionsPanel = document.getElementById('commandSuggestionsPanel');
  const resultsPanel = document.getElementById('commandResultsPanel');
  const resultsList = document.getElementById('commandResultsList');
  const launcherBtn = document.getElementById('commandCenterLauncher');
  
  // â”€â”€ Database compilation from PHP variables â”€â”€
  const searchDb = [
    // Core KPIs
    { title: 'Total BOSY Enrollment', category: 'enrollment', icon: 'bi-people-fill', value: '<?= number_format($total_enroll) ?>', keywords: 'enrollment total population students enrollee bosy all grade levels', action: () => openKpiModal('#kpiEnrollModal') },
    { title: 'Repeater Rate', category: 'retention', icon: 'bi-arrow-repeat', value: '<?= $repeater_rate ?>%', keywords: 'repeater rate repeaters repeat academic failure monitor', action: () => openKpiModal('#kpiRepeaterModal') },
    { title: 'Dropout Rate', category: 'retention', icon: 'bi-person-dash-fill', value: '<?= $dropout_rate ?>%', keywords: 'dropout rate dropouts drop leaving sardo school abandonment critical', action: () => openKpiModal('#kpiDropoutModal') },
    { title: 'Retention Rate', category: 'retention', icon: 'bi-person-check-fill', value: '<?= $retention_rate ?>%', keywords: 'retention rate student stay survival continuous staying school', action: () => openKpiModal('#kpiRetentionModal') },
    { title: 'Classroom Utilization', category: 'facilities', icon: 'bi-building-fill', value: '<?= $util_rate ?>%', keywords: 'classroom utilization rooms classrooms functional capacity square area', action: () => openKpiModal('#kpiClassroomModal') },
    { title: 'Floor Area per Student', category: 'facilities', icon: 'bi-grid-3x3', value: '<?= $area_per_student ?> sqm', keywords: 'floor area student classroom space density square meter standard deped', action: () => openKpiModal('#kpiAreaModal') },
    { title: 'Seat Sufficiency', category: 'facilities', icon: 'bi-person-workspace', value: '<?= $seat_ratio ?>%', keywords: 'seat sufficiency seats chairs armchairs shortage capacity standard', action: () => openKpiModal('#kpiSeatsModal') },
    <?php if (has_jhs() || has_kinder() || has_elementary()): 
      $ratio_title = "Teacher Ratio (JHS)";
      $ratio_keywords = "teacher ratio jhs junior high workload plantilla teacher count standard";
      if (!has_jhs() && (has_kinder() || has_elementary())) {
        $ratio_title = "Teacher Ratio (Basic Ed)";
        $ratio_keywords = "teacher ratio basic education elementary kinder workload plantilla teacher count standard";
      } else if (has_jhs() && (has_kinder() || has_elementary())) {
        $ratio_title = "Teacher Ratio (K-JHS)";
        $ratio_keywords = "teacher ratio kinder elementary junior high workload plantilla teacher count standard";
      }
    ?>
    { title: '<?= $ratio_title ?>', category: 'teachers', icon: 'bi-person-video3', value: '1 : <?= $jhs_ratio ?>', keywords: '<?= $ratio_keywords ?>', action: () => openKpiModal('#kpiTeacherModal') },
    <?php endif; ?>
    <?php if (has_shs()): ?>
    { title: 'Teacher Ratio (SHS)', category: 'teachers', icon: 'bi-person-video3', value: '1 : <?= $shs_ratio ?>', keywords: 'teacher ratio shs senior high workload plantilla teacher count standard', action: () => openKpiModal('#kpiTeacherModal') },
    <?php endif; ?>

    // Grade Level Breakdown loops from PHP arrays safely
    <?php foreach($perf_matrix as $i => $row):
      $g_name = $row['grade_name'];
      $l_type = $enroll_by_grade[$i]['level_type'];
      $enroll_val = $enroll_by_grade[$i]['enroll'] ?? 0;
      $rep_val = $row['rep'];
      $drop_val = $row['drop_'];
      $category_icon = strtolower($l_type) === 'senior high' ? 'shs' : 'jhs';
    ?>
    { 
      title: <?= json_encode($g_name . ' Total Enrollment') ?>, 
      category: 'enrollment', 
      icon: 'bi-people', 
      value: <?= json_encode(number_format($enroll_val) . ' students') ?>, 
      keywords: <?= json_encode(strtolower($g_name) . ' enrollees enrollment total population ' . strtolower($l_type)) ?>, 
      action: () => openKpiModal('#kpiEnrollModal') 
    },
    { 
      title: <?= json_encode($g_name . ' Repeaters') ?>, 
      category: 'retention', 
      icon: 'bi-arrow-repeat', 
      value: <?= json_encode(number_format($rep_val) . ' repeaters') ?>, 
      keywords: <?= json_encode(strtolower($g_name) . ' repeaters repeat academic failure ' . strtolower($l_type)) ?>, 
      action: () => openKpiModal('#kpiRepeaterModal') 
    },
    { 
      title: <?= json_encode($g_name . ' Dropouts') ?>, 
      category: 'retention', 
      icon: 'bi-person-dash', 
      value: <?= json_encode(number_format($drop_val) . ' dropouts') ?>, 
      keywords: <?= json_encode(strtolower($g_name) . ' dropouts dropout sardo left school ' . strtolower($l_type)) ?>, 
      action: () => openKpiModal('#kpiDropoutModal') 
    },
    <?php endforeach; ?>

    // Navigation Shortcuts
    { title: 'Go to Data Entry', category: 'navigation', icon: 'bi-pencil-square', value: 'Enter Data âž¡ï¸', keywords: 'go to data entry input write register record', action: () => { window.location.href = 'data_entry.php'; } },
    { title: 'Go to Enrollment Trends', category: 'navigation', icon: 'bi-person-lines-fill', value: 'Enrollment âž¡ï¸', keywords: 'go to enrollment trends enrollees details database shs jhs', action: () => { window.location.href = 'enrollment.php'; } },
    { title: 'Go to Facilities & Inventory', category: 'navigation', icon: 'bi-building', value: 'Facilities âž¡ï¸', keywords: 'go to facilities classroom seat chairs total area inventory', action: () => { window.location.href = 'facilities.php'; } },
    { title: 'Go to Human Resources', category: 'navigation', icon: 'bi-people-fill', value: 'Teachers âž¡ï¸', keywords: 'go to human resources teachers workload staffing list', action: () => { window.location.href = 'human_resources.php'; } },
    { title: 'Go to Management Insights', category: 'navigation', icon: 'bi-lightbulb-fill', value: 'AI Insights âž¡ï¸', keywords: 'go to insights ai recommendations forecasting advisory early warning ews sardo', action: () => { window.location.href = 'insights.php'; } },
    { title: 'Go to Activity Logs', category: 'navigation', icon: 'bi-clock-history', value: 'Logs âž¡ï¸', keywords: 'go to activity logs history audit trail encoders changes admin', action: () => { window.location.href = 'activity_logs.php'; } }
  ];

  let focusedIndex = -1;

  // â”€â”€ Open / Close Controllers â”€â”€
  function openCommandCenter() {
    modal.style.display = 'flex';
    input.value = '';
    suggestionsPanel.style.display = 'block';
    resultsPanel.style.display = 'none';
    focusedIndex = -1;
    setTimeout(() => input.focus(), 50);
  }

  function closeCommandCenter() {
    modal.style.display = 'none';
  }

  function openKpiModal(selector) {
    closeCommandCenter();
    const modalEl = document.querySelector(selector);
    if (modalEl) {
      const m = bootstrap.Modal.getOrCreateInstance(modalEl);
      m.show();
    }
  }

  // â”€â”€ Actions â”€â”€
  if (launcherBtn) {
    launcherBtn.addEventListener('click', openCommandCenter);
  }

  // Global Ctrl + K listener
  window.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      if (modal.style.display === 'flex') {
        closeCommandCenter();
      } else {
        openCommandCenter();
      }
    }
  });

  // â”€â”€ Input & Search Handler â”€â”€
  input.addEventListener('input', function() {
    const query = this.value.trim().toLowerCase();
    
    if (query.length === 0) {
      suggestionsPanel.style.display = 'block';
      resultsPanel.style.display = 'none';
      focusedIndex = -1;
      return;
    }
    
    suggestionsPanel.style.display = 'none';
    resultsPanel.style.display = 'block';
    
    // Simple filter matching title, category or keywords
    const matches = searchDb.filter(item => 
      item.title.toLowerCase().includes(query) || 
      item.category.toLowerCase().includes(query) || 
      item.keywords.toLowerCase().includes(query)
    );
    
    renderResults(matches);
  });

  // â”€â”€ Render Search Matches â”€â”€
  function renderResults(matches) {
    resultsList.innerHTML = '';
    focusedIndex = -1;
    
    if (matches.length === 0) {
      resultsList.innerHTML = `
        <div class="command-no-results">
          <i class="bi bi-question-circle fs-4 d-block mb-2 text-muted"></i>
          No results found for "<strong>${escapeHtml(input.value)}</strong>".
        </div>
      `;
      return;
    }
    
    matches.forEach((item, index) => {
      const el = document.createElement('div');
      el.className = 'command-result-item';
      el.dataset.index = index;
      
      el.innerHTML = `
        <div class="command-result-left">
          <div class="command-result-icon-wrapper ${item.category}">
            <i class="bi ${item.icon}"></i>
          </div>
          <div class="command-result-info">
            <span class="command-result-title">${item.title}</span>
            <span class="command-result-category">${item.category === 'teachers' ? 'HR / Staffing' : item.category}</span>
          </div>
        </div>
        <span class="command-result-value-badge">${item.value}</span>
      `;
      
      // Bind click event
      el.addEventListener('click', function() {
        item.action();
      });
      
      resultsList.appendChild(el);
    });
  }

  // â”€â”€ Keyboard Navigation within Search Bar â”€â”€
  input.addEventListener('keydown', function(e) {
    const items = resultsList.querySelectorAll('.command-result-item');
    
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (items.length === 0) return;
      focusedIndex = (focusedIndex + 1) % items.length;
      updateFocusedItem(items);
    } 
    else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (items.length === 0) return;
      focusedIndex = (focusedIndex - 1 + items.length) % items.length;
      updateFocusedItem(items);
    } 
    else if (e.key === 'Enter') {
      e.preventDefault();
      if (focusedIndex >= 0 && items[focusedIndex]) {
        items[focusedIndex].click();
      } else if (items.length > 0) {
        // Trigger the first result if nothing is specifically highlighted
        items[0].click();
      }
    } 
    else if (e.key === 'Escape') {
      e.preventDefault();
      closeCommandCenter();
    }
  });

  // Global Escape handler
  window.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && modal.style.display === 'flex') {
      closeCommandCenter();
    }
  });

  // Click outside to close
  modal.addEventListener('click', function(e) {
    if (e.target === modal) {
      closeCommandCenter();
    }
  });

  // Suggestions clicking
  const suggestionItems = document.querySelectorAll('.command-suggestion-item');
  suggestionItems.forEach(item => {
    item.addEventListener('click', function() {
      const searchVal = this.dataset.search;
      input.value = searchVal;
      // Trigger search programmatically
      input.dispatchEvent(new Event('input'));
      input.focus();
    });
  });

  // Helper function to focus an item
  function updateFocusedItem(items) {
    items.forEach((item, index) => {
      if (index === focusedIndex) {
        item.classList.add('focused');
        item.scrollIntoView({ block: 'nearest' });
      } else {
        item.classList.remove('focused');
      }
    });
  }

  // Escape HTML helper
  function escapeHtml(text) {
    return text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
});
</script>

<?php include 'includes/footer.php'; ?>
