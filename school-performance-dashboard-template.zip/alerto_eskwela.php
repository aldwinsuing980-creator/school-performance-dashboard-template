<?php
// alerto_eskwela.php
require_once __DIR__ . '/config/session.php';
require_login();

$page_title = 'Alerto Eskwela';
$breadcrumb = 'Alerto Eskwela';

include 'includes/header.php';
?>

<div class="container-fluid py-4" id="alertPageExport">
  <!-- Header Title -->
  <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
    <div class="section-header mb-0">
      <h1 class="section-title text-danger"><i class="bi bi-shield-fill-exclamation me-2 text-danger"></i>Alerto Eskwela — Emergency & PAGASA Storm Warning Portal</h1>
      <p class="section-sub">Real-time weather response, class status monitor, and emergency protocols for Natividad NHS.</p>
    </div>
    <button class="btn btn-outline-danger btn-sm fw-600 no-print" onclick="window.print()">
      <i class="bi bi-printer me-1"></i> I-print ang Alerto
    </button>
  </div>

  <!-- Interactive Simulator Control (Admin/User Selector) -->
  <div class="card border shadow-sm p-3 mb-4 bg-white no-print" style="border-radius: 16px;">
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
      <div class="d-flex align-items-center gap-2">
        <span class="badge bg-danger p-2" style="font-size: 0.75rem;"><i class="bi bi-sliders me-1"></i> SIMULATOR</span>
        <span class="fw-600 text-dark small">Subukan ang PAGASA Storm Signal Levels upang makita ang pagbabago sa Dashboard:</span>
      </div>
      <div class="btn-group" role="group" aria-label="Storm Signal Selector">
        <button type="button" class="btn btn-outline-success btn-sm fw-600 active" onclick="setStormSignal(0, this)">🟢 Clear / No Signal</button>
        <button type="button" class="btn btn-outline-warning btn-sm fw-600" onclick="setStormSignal(1, this)">🟡 Signal No. 1</button>
        <button type="button" class="btn btn-outline-warning btn-sm fw-600" style="color: #ea580c; border-color: #ea580c;" onclick="setStormSignal(2, this)">🟠 Signal No. 2</button>
        <button type="button" class="btn btn-outline-danger btn-sm fw-600" onclick="setStormSignal(3, this)">🔴 Signal No. 3 / 4</button>
      </div>
    </div>
  </div>

  <!-- DYNAMIC STORM BANNER (Changes color, icons, and glow animation dynamically) -->
  <div class="alert-banner-custom mb-4" id="stormBanner">
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
      <div class="d-flex align-items-center gap-3">
        <div class="banner-icon-wrap" id="bannerIcon">
          <i class="bi bi-sun-fill text-success" style="font-size: 2.2rem;"></i>
        </div>
        <div>
          <h2 class="fw-800 mb-1" id="bannerTitle" style="letter-spacing: -0.5px;">🟢 WALANG BAGYO (CLEAR SKIES)</h2>
          <p class="mb-0 fw-500 text-white-opacity" id="bannerSubtitle">Regular na klase at operasyon sa Natividad National High School.</p>
        </div>
      </div>
      <div class="banner-status-badge" id="bannerBadge">
        🟢 REGULAR CLASSES
      </div>
    </div>
  </div>

  <div class="row g-4">
    <!-- Left Column: DepEd Pacing & Flexible Learning Protocol -->
    <div class="col-12 col-xl-8">
      <div class="card border shadow-sm p-4 mb-4 bg-white" style="border-radius: 16px; min-height: 250px;">
        <h5 class="fw-700 text-dark border-bottom pb-2 mb-3">
          <i class="bi bi-mortarboard-fill me-2 text-danger"></i>Gabay ng Guro at Pamunuan (DepEd Class Guide)
        </h5>
        
        <div id="protocolGuideline">
          <!-- Dynamic class guidelines injected here -->
          <div class="d-flex gap-3 align-items-start mb-3">
            <span class="p-2 bg-success-subtle text-success rounded-circle" style="font-size: 1.2rem;"><i class="bi bi-check-circle-fill"></i></span>
            <div>
              <h6 class="fw-700 text-dark mb-1">Normal na Operasyon at Pag-aaral</h6>
              <p class="text-muted small">Lahat ng klase sa Junior High School (JHS) at Senior High School (SHS) ay magpapatuloy sa face-to-face na pamamaraan. Siguraduhin ang 100% attendance at pagsunod sa lesson logs.</p>
            </div>
          </div>
          <div class="d-flex gap-3 align-items-start mb-3">
            <span class="p-2 bg-light text-muted rounded-circle" style="font-size: 1.2rem;"><i class="bi bi-clock-history"></i></span>
            <div>
              <h6 class="fw-700 text-dark mb-1">Daily Safety Monitoring</h6>
              <p class="text-muted small">Ugaliing makinig sa anunsyo ng lokal na pamahalaan ng Natividad o Pangasinan at DepEd Division Office tuwing umaga bago pumasok sa paaralan.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Evacuation & Disaster Preparedness Checklist -->
      <div class="card border shadow-sm p-4 bg-white" style="border-radius: 16px;">
        <h5 class="fw-700 text-dark border-bottom pb-2 mb-3">
          <i class="bi bi-shield-fill-check me-2 text-success"></i>Disaster Preparedness & Evacuation Checklist
        </h5>
        
        <div class="row g-3">
          <div class="col-12 col-md-6">
            <div class="p-3 border rounded-3 bg-light-subtle h-100">
              <h6 class="fw-700 text-dark mb-2"><i class="bi bi-1-circle-fill text-danger me-2"></i>Lindol at Flash Floods</h6>
              <ul class="mb-0 small text-muted ps-3" style="line-height: 1.6;">
                <li>Magsagawa ng regular na <strong>Duck, Cover, and Hold</strong> drill sa bawat classroom.</li>
                <li>I-clear ang evacuation pathways mula sa mga building patungo sa Open Plaza / School Oval.</li>
                <li>Tiyakin na gumagana ang emergency megaphones at alarm sirens.</li>
              </ul>
            </div>
          </div>
          <div class="col-12 col-md-6">
            <div class="p-3 border rounded-3 bg-light-subtle h-100">
              <h6 class="fw-700 text-dark mb-2"><i class="bi bi-2-circle-fill text-warning me-2"></i>First Aid & Logistics</h6>
              <ul class="mb-0 small text-muted ps-3" style="line-height: 1.6;">
                <li>Ihanda ang School Clinic First Aid Kits na kumpleto sa gamot at splints.</li>
                <li>Siguraduhing may sapat na stock ng maiinom na tubig at flashlights.</li>
                <li>Panatilihing naka-charge ang emergency power banks at radyo.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Right Column: Emergency Hotlines & Contacts -->
    <div class="col-12 col-xl-4">
      <div class="card border shadow-sm p-4 bg-white h-100" style="border-radius: 16px;">
        <h5 class="fw-700 text-dark border-bottom pb-2 mb-3">
          <i class="bi bi-telephone-outbound-fill me-2 text-danger"></i>Lokal na Emergency Hotlines
        </h5>
        <p class="text-muted small mb-4">I-tap ang button sa mobile upang direktang tawagan ang mga lokal na katuwang sa kaligtasan sa bayan ng Natividad.</p>

        <div class="d-flex flex-column gap-3">
          <!-- MDRRMO -->
          <div class="hotline-card p-3 border rounded-3">
            <div class="d-flex align-items-center justify-content-between mb-2">
              <span class="badge bg-danger-subtle text-danger fw-700" style="font-size: 0.65rem;">MDRRMO NATIVIDAD</span>
              <span class="badge bg-success text-white px-2 py-1" style="font-size: 0.6rem;">ACTIVE 24/7</span>
            </div>
            <h6 class="fw-700 text-dark mb-1">Disaster Management Hotline</h6>
            <p class="text-muted small mb-2"><i class="bi bi-telephone-fill me-1 text-danger"></i> 0917-888-DRRM</p>
            <a href="tel:09178883776" class="btn btn-danger btn-sm w-100 fw-600 py-1" onclick="toastCopied('MDRRMO')">
              <i class="bi bi-telephone me-1"></i> Tawagan Ngayon
            </a>
          </div>

          <!-- BFP -->
          <div class="hotline-card p-3 border rounded-3">
            <div class="d-flex align-items-center justify-content-between mb-2">
              <span class="badge bg-danger-subtle text-danger fw-700" style="font-size: 0.65rem;">BFP NATIVIDAD</span>
              <span class="badge bg-success text-white px-2 py-1" style="font-size: 0.6rem;">READY</span>
            </div>
            <h6 class="fw-700 text-dark mb-1">Bumbero Rescue Team</h6>
            <p class="text-muted small mb-2"><i class="bi bi-telephone-fill me-1 text-danger"></i> (075) 555-FIRE</p>
            <a href="tel:0755553473" class="btn btn-danger btn-sm w-100 fw-600 py-1" onclick="toastCopied('BFP')">
              <i class="bi bi-telephone me-1"></i> Tawagan Ngayon
            </a>
          </div>

          <!-- Barangay Poblacion -->
          <div class="hotline-card p-3 border rounded-3">
            <div class="d-flex align-items-center justify-content-between mb-2">
              <span class="badge bg-primary-subtle text-primary fw-700" style="font-size: 0.65rem;">BARANGAY PATROL</span>
              <span class="badge bg-secondary text-white px-2 py-1" style="font-size: 0.6rem;">LOCAL RESCUE</span>
            </div>
            <h6 class="fw-700 text-dark mb-1">Poblacion Emergency responders</h6>
            <p class="text-muted small mb-2"><i class="bi bi-telephone-fill me-1 text-danger"></i> 0920-123-RESC</p>
            <a href="tel:09201237372" class="btn btn-secondary btn-sm w-100 fw-600 py-1" onclick="toastCopied('Barangay')">
              <i class="bi bi-telephone me-1"></i> Tawagan Ngayon
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
/* Elegant custom alert banner with gradients */
.alert-banner-custom {
    padding: 2.25rem;
    border-radius: 16px;
    color: #fff;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    transition: all 0.4s ease;
    background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
    border: 1px solid rgba(22, 163, 74, 0.2);
}

.banner-icon-wrap {
    background: #fff;
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 6px rgba(0,0,0,0.06);
    transition: all 0.3s ease;
}

.banner-status-badge {
    background: rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(4px);
    border: 1px solid rgba(255, 255, 255, 0.3);
    padding: 6px 14px;
    border-radius: 30px;
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 0.5px;
    text-transform: uppercase;
}

.text-white-opacity {
    color: rgba(255, 255, 255, 0.9);
}

.hotline-card {
    background: #f8fafc;
    transition: all 0.22s;
}
.hotline-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 10px rgba(0,0,0,0.04);
}

/* Pulsing alert glow animation for high warning signals */
.pulsing-banner-glow {
    animation: pulse-glow-banner 2s infinite ease-in-out;
}

@keyframes pulse-glow-banner {
    0% { box-shadow: 0 0 15px rgba(220, 38, 38, 0.2); border-color: rgba(220, 38, 38, 0.3); }
    50% { box-shadow: 0 0 25px rgba(220, 38, 38, 0.5); border-color: rgba(220, 38, 38, 0.6); }
    100% { box-shadow: 0 0 15px rgba(220, 38, 38, 0.2); border-color: rgba(220, 38, 38, 0.3); }
}

@media print {
    .no-print {
        display: none !important;
    }
    .alert-banner-custom {
        border: 2px solid #000 !important;
        background: none !important;
        color: #000 !important;
    }
    .banner-icon-wrap {
        border: 1px solid #000 !important;
    }
    .text-white-opacity {
        color: #333 !important;
    }
}
</style>

<script>
// Storm Signal simulation datasets
const signalData = {
    0: {
        title: "🟢 WALANG BAGYO (CLEAR SKIES)",
        subtitle: "Regular na klase at operasyon sa Natividad National High School.",
        badge: "🟢 REGULAR CLASSES",
        gradient: "linear-gradient(135deg, #16a34a 0%, #15803d 100%)",
        border: "1px solid rgba(22, 163, 74, 0.2)",
        icon: '<i class="bi bi-sun-fill text-success" style="font-size: 2.2rem;"></i>',
        pulse: false,
        guidelines: `
          <div class="d-flex gap-3 align-items-start mb-3">
            <span class="p-2 bg-success-subtle text-success rounded-circle" style="font-size: 1.2rem;"><i class="bi bi-check-circle-fill"></i></span>
            <div>
              <h6 class="fw-700 text-dark mb-1">Normal na Operasyon at Pag-aaral</h6>
              <p class="text-muted small">Lahat ng klase sa Junior High School (JHS) at Senior High School (SHS) ay magpapatuloy sa face-to-face na pamamaraan. Siguraduhin ang 100% attendance at pagsunod sa lesson logs.</p>
            </div>
          </div>
          <div class="d-flex gap-3 align-items-start mb-3">
            <span class="p-2 bg-light text-muted rounded-circle" style="font-size: 1.2rem;"><i class="bi bi-clock-history"></i></span>
            <div>
              <h6 class="fw-700 text-dark mb-1">Daily Safety Monitoring</h6>
              <p class="text-muted small">Ugaliing makinig sa anunsyo ng lokal na pamahalaan ng Natividad o Pangasinan at DepEd Division Office tuwing umaga bago pumasok sa paaralan.</p>
            </div>
          </div>
        `
    },
    1: {
        title: "🟡 PAGASA STORM SIGNAL NO. 1",
        subtitle: "I-monitor ang balita; Paghahanda para sa Guro at mga Magulang.",
        badge: "🟡 STANDBY ALERT",
        gradient: "linear-gradient(135deg, #ca8a04 0%, #a16207 100%)",
        border: "1px solid rgba(202, 138, 4, 0.2)",
        icon: '<i class="bi bi-cloud-wind text-warning" style="font-size: 2.2rem;"></i>',
        pulse: false,
        guidelines: `
          <div class="d-flex gap-3 align-items-start mb-3">
            <span class="p-2 bg-warning-subtle text-warning rounded-circle" style="font-size: 1.2rem;"><i class="bi bi-exclamation-triangle-fill"></i></span>
            <div>
              <h6 class="fw-700 text-dark mb-1">Paghahanda para sa mga Baitang (Kinder to JHS)</h6>
              <p class="text-muted small">Kahit tuloy ang klase, pinapahintulutan ang mga magulang na huwag papasukin ang kanilang mga anak kung mapanganib ang daan patungong paaralan.</p>
            </div>
          </div>
          <div class="d-flex gap-3 align-items-start mb-3">
            <span class="p-2 bg-light text-muted rounded-circle" style="font-size: 1.2rem;"><i class="bi bi-journal-check"></i></span>
            <div>
              <h6 class="fw-700 text-dark mb-1">Advisory para sa SHS Students</h5>
              <p class="text-muted small">Maging alerto at ihanda ang mga portable gadgets/learning packs sakaling itaas ang antas ng babala.</p>
            </div>
          </div>
        `
    },
    2: {
        title: "🟠 PAGASA STORM SIGNAL NO. 2",
        subtitle: "Suspendido ang Junior High School. Ang Senior High School ay i-monitor nang mabuti.",
        badge: "🟠 JHS SUSPENDED",
        gradient: "linear-gradient(135deg, #ea580c 0%, #c2410c 100%)",
        border: "1px solid rgba(234, 88, 12, 0.2)",
        icon: '<i class="bi bi-cloud-rain-heavy-fill" style="color: #ea580c; font-size: 2.2rem;"></i>',
        pulse: false,
        guidelines: `
          <div class="d-flex gap-3 align-items-start mb-3">
            <span class="p-2 bg-warning-subtle text-warning rounded-circle" style="font-size: 1.2rem;"><i class="bi bi-slash-circle-fill"></i></span>
            <div>
              <h6 class="fw-700 text-dark mb-1">Junior High School: SUSPENDIDO LAHAT NG KLASE</h6>
              <p class="text-muted small">Awtomatikong walang face-to-face na klase ang JHS. Lilipat agad ang mga mag-aaral sa Flexible Learning Option (Modular Home-Based Study).</p>
            </div>
          </div>
          <div class="d-flex gap-3 align-items-start mb-3">
            <span class="p-2 bg-info-subtle text-info rounded-circle" style="font-size: 1.2rem;"><i class="bi bi-exclamation-circle-fill"></i></span>
            <div>
              <h6 class="fw-700 text-dark mb-1">Senior High School Advisory</h6>
              <p class="text-muted small">I-monitor ang anunsyo ng LGU Natividad. Kung patuloy ang malakas na ulan, inirerekomenda ng Principal ang voluntary shift sa modular classes para sa SHS.</p>
            </div>
          </div>
        `
    },
    3: {
        title: "🔴 PAGASA STORM SIGNAL NO. 3 / 4",
        subtitle: "Awtomatikong Suspendido ang Lahat ng Antas (JHS & SHS). I-activate ang Modular FLO!",
        badge: "🔴 ALL CLASSES SUSPENDED",
        gradient: "linear-gradient(135deg, #dc2626 0%, #991b1b 100%)",
        border: "1px solid rgba(220, 38, 38, 0.2)",
        icon: '<i class="bi bi-lightning-charge-fill text-danger" style="font-size: 2.2rem;"></i>',
        pulse: true,
        guidelines: `
          <div class="d-flex gap-3 align-items-start mb-3">
            <span class="p-2 bg-danger-subtle text-danger rounded-circle" style="font-size: 1.2rem;"><i class="bi bi-x-octagon-fill"></i></span>
            <div>
              <h6 class="fw-700 text-dark mb-1">Awtomatikong Klaseng Suspendido (Lahat ng Baitang)</h6>
              <p class="text-muted small">Lahat ng klase sa JHS at SHS ay pormal na suspendido. Ang mga guro ay hindi rin kinakailangang pumasok sa paaralan para sa kanilang kaligtasan.</p>
            </div>
          </div>
          <div class="d-flex gap-3 align-items-start mb-3">
            <span class="p-2 bg-danger-subtle text-danger rounded-circle" style="font-size: 1.2rem;"><i class="bi bi-arrow-left-right"></i></span>
            <div>
              <h6 class="fw-700 text-dark mb-1">Pagpapatupad ng Flexible Learning Option (FLO)</h6>
              <p class="text-muted small">Awtomatikong lilipat sa modular learning mode. Ang pagsusumite ng performance tasks at written outputs ay palalawigin ang deadline ng isang linggo.</p>
            </div>
          </div>
          <div class="d-flex gap-3 align-items-start mb-3">
            <span class="p-2 bg-info-subtle text-info rounded-circle" style="font-size: 1.2rem;"><i class="bi bi-megaphone-fill"></i></span>
            <div>
              <h6 class="fw-700 text-dark mb-1">PTA and Adviser Coordination</h6>
              <p class="text-muted small">Magsagawa ng mabilisang check-in sa pamamagitan ng GC (Messenger) upang masigurong ligtas ang mga pamilya ng bawat estudyante.</p>
            </div>
          </div>
        `
    }
};

function setStormSignal(level, btn) {
    // Update active button styling
    const buttons = btn.parentElement.querySelectorAll('.btn');
    buttons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const data = signalData[level];
    const banner = document.getElementById('stormBanner');
    
    // Apply new classes and styling with smooth transition
    banner.style.background = data.gradient;
    banner.style.borderColor = data.border;
    
    if (data.pulse) {
        banner.classList.add('pulsing-banner-glow');
    } else {
        banner.classList.remove('pulsing-banner-glow');
    }

    document.getElementById('bannerTitle').innerText = data.title;
    document.getElementById('bannerSubtitle').innerText = data.subtitle;
    
    const badge = document.getElementById('bannerBadge');
    badge.innerText = data.badge;
    
    // Badge color dynamic adjustment
    if (level === 0) {
        badge.style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
    } else if (level === 1) {
        badge.style.backgroundColor = 'rgba(254, 240, 138, 0.25)';
    } else if (level === 2) {
        badge.style.backgroundColor = 'rgba(255, 237, 213, 0.25)';
    } else {
        badge.style.backgroundColor = 'rgba(254, 226, 226, 0.25)';
    }

    document.getElementById('bannerIcon').innerHTML = data.icon;
    document.getElementById('protocolGuideline').innerHTML = data.guidelines;
}

function toastCopied(name) {
    Swal.fire({
        icon: 'info',
        title: 'Emergency Call Triggered',
        text: 'Naisagawa ang virtual call sa ' + name + ' hotline.',
        timer: 1500,
        showConfirmButton: false
    });
}
</script>

<?php include 'includes/footer.php'; ?>
