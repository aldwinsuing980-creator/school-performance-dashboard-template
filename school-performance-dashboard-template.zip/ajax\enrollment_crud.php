<?php
require_once __DIR__ . '/../config/session.php';
require_login();
if(!has_role('Admin')) { json_response(['success'=>false,'message'=>'Access denied.'],403); }

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';

/**
 * Safe upsert: delete matching record then insert fresh.
 * Avoids issues with missing UNIQUE keys on these tables.
 */
function repDropUpsert(PDO $pdo, string $table, int $grade_id, ?int $strand_id, string $semester, string $sy, string $countField, int $countVal): void {
    $strandSql = $strand_id === null ? "strand_id IS NULL" : "strand_id = ?";
    $params     = $strand_id === null
        ? [$grade_id, $semester, $sy]
        : [$grade_id, $strand_id, $semester, $sy];
    $pdo->prepare("DELETE FROM `{$table}` WHERE grade_level_id = ? AND {$strandSql} AND semester = ? AND school_year = ?")
        ->execute($params);
    $pdo->prepare("INSERT INTO `{$table}` (grade_level_id, strand_id, semester, `{$countField}`, school_year) VALUES (?, ?, ?, ?, ?)")
        ->execute([$grade_id, $strand_id, $semester, $countVal, $sy]);
}

try {
    if($action === 'add'){
        $sy        = trim($data['school_year'] ?? '');
        if($sy === 'new') $sy = trim($data['new_sy'] ?? '');

        $grade_id  = (int)($data['grade_level_id'] ?? 0);
        $strand_id = (isset($data['strand_id']) && $data['strand_id'] !== '') ? (int)$data['strand_id'] : null;
        $semester  = clean($data['semester'] ?? 'Full Year');

        // Insert enrollment record
        $stmt = $pdo->prepare("INSERT INTO enrollment_data (grade_level_id,strand_id,semester,bosy_enrollment,school_year) VALUES(?,?,?,?,?)");
        $stmt->execute([$grade_id, $strand_id, $semester, (int)($data['bosy_enrollment'] ?? 0), $sy]);
        $eid = $pdo->lastInsertId();

        // Upsert repeaters with proper semester key
        if(isset($data['repeaters_count'])){
            repDropUpsert($pdo, 'repeaters_data', $grade_id, $strand_id, $semester, $sy, 'repeaters_count', (int)$data['repeaters_count']);
        }
        // Upsert dropouts with proper semester key
        if(isset($data['dropouts_count'])){
            repDropUpsert($pdo, 'dropouts_data', $grade_id, $strand_id, $semester, $sy, 'dropouts_count', (int)$data['dropouts_count']);
        }

        log_activity($pdo, current_user_id(), "Added enrollment record (ID:{$eid}) for S.Y. {$sy}", 'Enrollment');
        json_response(['success'=>true,'message'=>'Enrollment record added successfully.']);

    } elseif($action === 'edit'){
        $id        = (int)($data['id'] ?? 0);
        if(!$id) json_response(['success'=>false,'message'=>'Invalid record ID.'],400);

        $grade_id  = (int)($data['grade_level_id'] ?? 0);
        $strand_id = (isset($data['strand_id']) && $data['strand_id'] !== '') ? (int)$data['strand_id'] : null;
        $semester  = clean($data['semester'] ?? 'Full Year');
        $sy        = clean($data['school_year'] ?? '');

        // Update enrollment
        $stmt = $pdo->prepare("UPDATE enrollment_data SET grade_level_id=?,strand_id=?,semester=?,bosy_enrollment=?,school_year=? WHERE id=?");
        $stmt->execute([$grade_id, $strand_id, $semester, (int)($data['bosy_enrollment'] ?? 0), $sy, $id]);

        // Also update repeaters / dropouts for this grade+strand+semester
        if(isset($data['repeaters_count'])){
            repDropUpsert($pdo, 'repeaters_data', $grade_id, $strand_id, $semester, $sy, 'repeaters_count', (int)$data['repeaters_count']);
        }
        if(isset($data['dropouts_count'])){
            repDropUpsert($pdo, 'dropouts_data', $grade_id, $strand_id, $semester, $sy, 'dropouts_count', (int)$data['dropouts_count']);
        }

        log_activity($pdo, current_user_id(), "Updated enrollment record ID:{$id}", 'Enrollment');
        json_response(['success'=>true,'message'=>'Record updated successfully.']);

    } else {
        json_response(['success'=>false,'message'=>'Unknown action.'],400);
    }
} catch(PDOException $e){
    json_response(['success'=>false,'message'=>'DB error: '.$e->getMessage()],500);
}
