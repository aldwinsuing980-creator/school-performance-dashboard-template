// assets/js/main.js — Natividad High School Dashboard

document.addEventListener('DOMContentLoaded', () => {

  /* ── Sidebar toggle ─────────────────────────── */
  const sidebar = document.getElementById('sidebar');
  const mainContent = document.getElementById('mainContent');
  const toggleBtn = document.getElementById('sidebarToggle');
  const isMobile = () => window.innerWidth <= 992;

  // Create overlay for mobile
  const overlay = document.createElement('div');
  overlay.className = 'sidebar-overlay';
  overlay.id = 'sidebarOverlay';
  document.body.appendChild(overlay);

  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      if (isMobile()) {
        sidebar.classList.toggle('open');
        overlay.style.display = sidebar.classList.contains('open') ? 'block' : 'none';
      } else {
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('expanded');
      }
    });
  }

  overlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.style.display = 'none';
  });

  /* ── Bootstrap tooltips ─────────────────────── */
  document.querySelectorAll('[data-bs-toggle="tooltip"]')
    .forEach(el => new bootstrap.Tooltip(el, { trigger: 'hover' }));

  /* ── Active link highlight ──────────────────── */
  const links = document.querySelectorAll('.sidebar-link');
  links.forEach(link => {
    if (link.href === window.location.href) link.classList.add('active');
  });
});

/* ── AJAX Helper ────────────────────────────────────────────── */
function ajaxGet(url, params, callback) {
  const qs = new URLSearchParams(params).toString();
  fetch(`${url}?${qs}`)
    .then(r => r.json())
    .then(data => callback(null, data))
    .catch(err => callback(err, null));
}

function ajaxPost(url, data, callback) {
  fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
    .then(r => r.json())
    .then(data => callback(null, data))
    .catch(err => callback(err, null));
}

/* ── Spinner helpers ────────────────────────────────────────── */
function showSpinner() {
  let s = document.getElementById('globalSpinner');
  if (!s) {
    s = document.createElement('div');
    s.id = 'globalSpinner';
    s.className = 'spinner-overlay';
    s.innerHTML = '<div class="spinner-nhs"></div>';
    document.body.appendChild(s);
  }
  s.style.display = 'flex';
}
function hideSpinner() {
  const s = document.getElementById('globalSpinner');
  if (s) s.style.display = 'none';
}

/* ── SweetAlert2 helpers ────────────────────────────────────── */
const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
});
function toastSuccess(msg) { Toast.fire({ icon: 'success', title: msg }); }
function toastError(msg) { Toast.fire({ icon: 'error', title: msg }); }
function toastInfo(msg) { Toast.fire({ icon: 'info', title: msg }); }

function confirmAction(msg = 'Are you sure? This will affect historical reports.', title = 'Confirm Action') {
  return Swal.fire({
    title, html: msg, icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc2626',
    cancelButtonColor: '#6b7280',
    confirmButtonText: '<i class="bi bi-check-lg me-1"></i> Yes, proceed',
    cancelButtonText: 'Cancel',
    customClass: { popup: 'rounded-3' }
  });
}

/* ── Chart color palette (defined globally in header.php as CHART_PALETTE) ── */
const NHS_COLORS = {
  navy: '#1B2A6B',
  navyLight: '#2E3F8F',
  gold: '#C9A227',
  goldDark: '#A07D0F',
  red: '#8B1A1A',
  green: '#16a34a',
  teal: '#2E6B9E',
  gray: '#6B6880',
};

/* ── PDF Export ─────────────────────────────────────────────── */
async function exportToPDF(elementId, filename = 'NHS_Report.pdf') {
  showSpinner();
  try {
    const el = document.getElementById(elementId) || document.body;
    const canvas = await html2canvas(el, { scale: 2, useCORS: true });
    const imgData = canvas.toDataURL('image/png');
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF({ orientation: 'landscape', unit: 'px', format: 'a4' });
    const pw = pdf.internal.pageSize.getWidth();
    const ph = pdf.internal.pageSize.getHeight();
    const ratio = Math.min(pw / canvas.width, ph / canvas.height);
    const w = canvas.width * ratio;
    const h = canvas.height * ratio;
    pdf.addImage(imgData, 'PNG', (pw - w) / 2, (ph - h) / 2, w, h);
    pdf.save(filename);
    toastSuccess('PDF exported successfully!');
  } catch (e) {
    toastError('Export failed: ' + e.message);
  } finally {
    hideSpinner();
  }
}

/* ── Utility: number format ─────────────────────────────────── */
function fmt(n) { return Number(n).toLocaleString(); }
function pct(n) { return Number(n).toFixed(1) + '%'; }

/* ── Real-time Numeric Input Validation (Whole Positive Numbers Only) ── */
document.addEventListener('keydown', function(e) {
  const el = e.target;
  if (el.tagName === 'INPUT' && el.type === 'number') {
    // Block: letters (e, E), signs (+, -), and decimals (.)
    if (['e', 'E', '+', '-', '.'].includes(e.key)) {
      e.preventDefault();
      // Show SweetAlert warning toast
      const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 1500,
        timerProgressBar: false
      });
      Toast.fire({
        icon: 'warning',
        title: 'Maling Input! Mga numero lamang po (whole numbers).'
      });
    }
  }
});

document.addEventListener('input', function(e) {
  const el = e.target;
  if (el.tagName === 'INPUT' && el.type === 'number') {
    // Failsafe for copy-paste or other entry methods
    if (el.value !== '') {
      const cleaned = el.value.replace(/[^0-9]/g, '');
      if (el.value !== cleaned) {
        el.value = cleaned;
        Swal.fire({
          toast: true,
          position: 'top-end',
          icon: 'error',
          title: 'May titik o simbolo! Bawal po ito.',
          showConfirmButton: false,
          timer: 1500
        });
      }
    }
  }
});

