<?php
require_once __DIR__ . '/../config/session.php';
require_login();
if(!has_role('Admin')) { json_response(['success'=>false,'message'=>'Only Admins can delete records.'],403); }

$data  = json_decode(file_get_contents('php://input'), true);
$id    = (int)($data['id'] ?? 0);
$table = preg_replace('/[^a-z_]/', '', strtolower($data['table'] ?? ''));

$allowed = ['enrollment_data','repeaters_data','dropouts_data','classrooms','seats_data','teachers_per_grade','teachers_per_area'];
if(!$id || !in_array($table, $allowed)){
    json_response(['success'=>false,'message'=>'Invalid request.'], 400);
}

try {
    $stmt = $pdo->prepare("DELETE FROM `{$table}` WHERE id=?");
    $stmt->execute([$id]);
    log_activity($pdo, current_user_id(), "Deleted record ID:{$id} from {$table}", 'CRUD');
    json_response(['success'=>true,'message'=>'Record deleted successfully.']);
} catch(PDOException $e){
    json_response(['success'=>false,'message'=>'DB error: '.$e->getMessage()], 500);
}
