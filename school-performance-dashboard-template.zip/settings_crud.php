<?php
require_once __DIR__ . '/../config/session.php';
require_login();

// Strictly restricted to Admins only
if (!has_role('Admin')) {
    json_response(['success' => false, 'message' => 'Access denied. Administrator privileges required.'], 403);
}

// Since file uploads are multipart/form-data, we use $_POST and $_FILES instead of php://input
$action = $_POST['action'] ?? '';

try {
    if ($action === 'save_settings') {
        $school_name = clean($_POST['school_name'] ?? '');

        if (empty($school_name)) {
            json_response(['success' => false, 'message' => 'School name cannot be empty.'], 400);
        }

        // Update school name setting in database
        $stmt = $pdo->prepare("
            INSERT INTO system_settings (setting_key, setting_value) 
            VALUES ('school_name', ?) 
            ON DUPLICATE KEY UPDATE setting_value = ?
        ");
        $stmt->execute([$school_name, $school_name]);

        $logo_uploaded = false;
        $logo_path = '';

        // Handle logo file upload securely if provided
        if (isset($_FILES['school_logo']) && $_FILES['school_logo']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['school_logo'];
            $file_name = $file['name'];
            $file_tmp  = $file['tmp_name'];
            $file_size = $file['size'];
            
            // 1. Validate file extension & mime type
            $allowed_exts = ['png', 'jpg', 'jpeg'];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime_type = finfo_file($finfo, $file_tmp);
            finfo_close($finfo);
            
            $allowed_mimes = ['image/png', 'image/jpeg', 'image/pjpeg'];
            
            if (!in_array($file_ext, $allowed_exts) || !in_array($mime_type, $allowed_mimes)) {
                json_response(['success' => false, 'message' => 'Invalid file format. Only PNG, JPG, and JPEG are allowed.'], 400);
            }

            // 2. Validate file size (limit to 2MB)
            if ($file_size > 2 * 1024 * 1024) {
                json_response(['success' => false, 'message' => 'File size exceeds 2MB limit.'], 400);
            }

            // 3. Ensure uploads folder exists in workspace
            $upload_dir = __DIR__ . '/../uploads';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            // 4. Generate a unique secure name to prevent filename conflicts and directory traversal attacks
            $new_filename = 'logo_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $file_ext;
            $destination = $upload_dir . '/' . $new_filename;

            // 5. Move uploaded file
            if (move_uploaded_file($file_tmp, $destination)) {
                $logo_path = 'uploads/' . $new_filename;
                
                // Update school logo setting in database
                $stmt = $pdo->prepare("
                    INSERT INTO system_settings (setting_key, setting_value) 
                    VALUES ('school_logo', ?) 
                    ON DUPLICATE KEY UPDATE setting_value = ?
                ");
                $stmt->execute([$logo_path, $logo_path]);
                $logo_uploaded = true;
            } else {
                json_response(['success' => false, 'message' => 'Failed to save uploaded file.'], 500);
            }
        }

        $msg = 'System settings saved successfully.';
        if ($logo_uploaded) {
            $msg = 'Branding profile and school logo successfully updated.';
        }

        log_activity($pdo, current_user_id(), "Updated system settings (School Name: '{$school_name}')", 'Settings');
        json_response(['success' => true, 'message' => $msg, 'school_name' => $school_name, 'school_logo' => $logo_path]);

    } else {
        json_response(['success' => false, 'message' => 'Unknown action request.'], 400);
    }
} catch (Exception $e) {
    json_response(['success' => false, 'message' => 'Operation failed: ' . $e->getMessage()], 500);
}
?>
