<?php
require_once __DIR__ . '/config/session.php';
require_login();
if(!has_role('Admin')){
    // Show access denied message instead of silent redirect
    $page_title = 'Access Denied';
    $breadcrumb = 'Data Entry';
    include 'includes/header.php';
    echo '<div class="d-flex align-items-center justify-content-center" style="min-height:50vh;">
      <div class="text-center">
        <div style="font-size:4rem;margin-bottom:1rem;">🔒</div>
        <h2 class="fw-700 text-dark mb-2">Access Denied</h2>
        <p class="text-muted mb-3">You need <strong>Admin</strong> role to access Data Entry.<br>Your current role: <strong>' . htmlspecialchars($_SESSION['user_role'] ?? 'Unknown') . '</strong></p>
        <a href="index.php" class="btn-primary-nhs"><i class="bi bi-arrow-left me-1"></i> Back to Dashboard</a>
      </div>
    </div>';
    include 'includes/footer.php';
    exit;
}

if (defined('FEATURE_DATA_ENTRY') && !FEATURE_DATA_ENTRY) {
    http_response_code(403);
    die('Data entry feature is currently disabled.');
}

$page_title = 'Data Entry Wizard';
$breadcrumb = 'Data Entry';

$sy_rows = $pdo->query("SELECT DISTINCT school_year FROM enrollment_data ORDER BY school_year DESC")->fetchAll();
$sy_list = array_column($sy_rows,'school_year');
$sel_sy  = $_GET['sy'] ?? ($sy_list[0] ?? '2025-2026');
if ($sel_sy === 'new_sy') {
    $sel_sy = $sy_list[0] ?? '2025-2026';
}

// Calculate the next consecutive school year based on the latest year in database or current selection
$latest_db_sy = $sy_list[0] ?? '2025-2026';
$latest_sy = $latest_db_sy;
if (preg_match('/^(\d+)-(\d+)$/', $sel_sy) && preg_match('/^(\d+)-(\d+)$/', $latest_db_sy)) {
    $sel_year = (int)explode('-', $sel_sy)[0];
    $db_year = (int)explode('-', $latest_db_sy)[0];
    if ($sel_year > $db_year) {
        $latest_sy = $sel_sy;
    }
}
$next_sy = '2026-2027';
if (preg_match('/^(\d+)-(\d+)$/', $latest_sy, $matches)) {
    $next_sy = ((int)$matches[1] + 1) . '-' . ((int)$matches[2] + 1);
}

$grades_all  = $pdo->query("SELECT * FROM grade_levels ORDER BY id")->fetchAll();
$grades = array_filter($grades_all, function($g) {
    if ($g['level_type'] === 'Kindergarten') return has_kinder();
    if ($g['level_type'] === 'Elementary') return has_elementary();
    if ($g['level_type'] === 'Junior High') return has_jhs();
    if ($g['level_type'] === 'Senior High') return has_shs();
    return false;
});
$strands = $pdo->query("SELECT * FROM strands ORDER BY id")->fetchAll();

// Pre-load existing data for selected SY
function getExisting(PDO $pdo, string $table, string $sy): array {
    $q = $pdo->prepare("SELECT * FROM `$table` WHERE school_year=?");
    $q->execute([$sy]);
    return $q->fetchAll();
}
$exist_enroll  = getExisting($pdo,'enrollment_data',$sel_sy);
$exist_rep     = getExisting($pdo,'repeaters_data',$sel_sy);
$exist_drop    = getExisting($pdo,'dropouts_data',$sel_sy);
$exist_seats   = getExisting($pdo,'seats_data',$sel_sy);
$exist_tg      = getExisting($pdo,'teachers_per_grade',$sel_sy);
$exist_ta      = getExisting($pdo,'teachers_per_area',$sel_sy);

// Helper: find value in existing rows
function findVal(array $rows, string $field, int $grade_id, ?int $strand_id=null, string $sem='Full Year'): int {
    foreach($rows as $r){
        if((int)$r['grade_level_id']===$grade_id){
            if($strand_id!==null && (int)($r['strand_id']??0)!==$strand_id) continue;
            if(isset($r['semester']) && $r['semester']!==$sem) continue;
            return (int)$r[$field];
        }
    }
    return 0;
}
function findTeacherGrade(array $rows, int $grade_id): int {
    foreach($rows as $r) if((int)$r['grade_level_id']===$grade_id) return (int)$r['teacher_count'];
    return 0;
}
function findTeacherArea(array $rows, string $area, string $type): string {
    foreach($rows as $r) if($r['learning_area']===$area && $r['level_type']===$type) return (string)$r['teacher_count'];
    return '';
}

$basic_grades = array_filter($grades, fn($g)=>in_array($g['level_type'], ['Kindergarten', 'Elementary', 'Junior High']));
$shs          = array_filter($grades, fn($g)=>$g['level_type']==='Senior High');

// Default learning areas
$jhs_areas = ['Mathematics','Science','English','Filipino','Araling Panlipunan','MAPEH','TLE/EPP','ESP/Values'];
$shs_areas = ['Core Subjects','ABM Subjects','HUMSS Subjects','STEM Subjects','TVL Subjects','GAS Subjects'];

$show_basic = !empty($basic_grades);
$show_shs   = has_shs();

include 'includes/header.php';
?>

<style>
.wizard-tabs .nav-link{border-radius:10px 10px 0 0;font-size:.85rem;font-weight:500;padding:10px 20px;}
.wizard-tabs .nav-link.active{background:var(--primary);color:#fff;}
.entry-table th{background:#f0f4f8;font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.4px;padding:8px 10px;color:var(--text-muted);white-space:nowrap;}
.entry-table td{padding:7px 8px;vertical-align:middle;}
.entry-table input[type=number]{width:72px;border:1.5px solid #dee2e6;border-radius:8px;padding:4px 6px;font-family:'Poppins',sans-serif;font-size:.82rem;text-align:center;transition:.2s;}
.entry-table input[type=number]:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(15,76,129,.12);outline:none;}
.entry-table input.input-male{border-color:#93c5fd;background:#eff6ff;}
.entry-table input.input-female{border-color:#f9a8d4;background:#fdf2f8;}
.entry-table .total-cell{font-weight:700;font-size:.85rem;color:var(--primary);min-width:52px;text-align:center;}
.th-group{text-align:center;border-bottom:2px solid #cbd5e1;padding-bottom:4px;}
.th-male{color:#1d4ed8;}
.th-female{color:#be185d;}
.grade-badge{display:inline-block;padding:3px 12px;border-radius:20px;background:#e0f0ff;color:#0F4C81;font-size:.78rem;font-weight:600;}
.strand-badge{display:inline-block;padding:3px 10px;border-radius:20px;background:#f0fff4;color:#16a34a;font-size:.75rem;font-weight:600;}
.step-indicator{display:flex;gap:0;margin-bottom:0;}
.step-indicator .step{flex:1;text-align:center;padding:12px 4px;font-size:.75rem;font-weight:600;color:var(--text-muted);border-bottom:3px solid #e2e8f0;cursor:pointer;transition:.2s;}
.step-indicator .step.active{color:var(--primary);border-bottom-color:var(--primary);}
.step-indicator .step.done{color:var(--success);border-bottom-color:var(--success);}
</style>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-3">
  <div class="section-header mb-0">
    <h1 class="section-title"><i class="bi bi-pencil-square me-2 text-primary-nhs"></i>Data Entry Wizard</h1>
    <p class="section-sub">Enter or update all school data for S.Y. <strong><?=htmlspecialchars($sel_sy)?></strong></p>
  </div>
</div>

<!-- Step Indicator -->
<div class="chart-card mb-0" style="border-radius:14px 14px 0 0;border-bottom:none;padding:0;">
  <div class="step-indicator" id="stepIndicator">
    <?php if ($show_basic): ?>
    <div class="step active" onclick="goStep(0)" id="indStep0"><i class="bi bi-people me-1"></i>Basic Ed Enrollment</div>
    <?php endif; ?>
    <?php if ($show_shs): ?>
    <div class="step <?= !$show_basic ? 'active' : '' ?>" onclick="goStep(1)" id="indStep1"><i class="bi bi-mortarboard me-1"></i>SHS Enrollment</div>
    <?php endif; ?>
    <div class="step" onclick="goStep(2)" id="indStep2"><i class="bi bi-person-video3 me-1"></i>Teachers</div>
    <div class="step" onclick="goStep(3)" id="indStep3"><i class="bi bi-building me-1"></i>Seats</div>
    <div class="step" onclick="goStep(4)" id="indStep4"><i class="bi bi-check-circle me-1"></i>Review & Save</div>
  </div>
</div>

<form id="dataEntryForm" onsubmit="submitAll(event)">
<input type="hidden" name="school_year" value="<?=htmlspecialchars($sel_sy)?>">

<!-- ═══════════════════ STEP 0: Basic Education Enrollment ═══════════════ -->
<div class="chart-card step-panel <?= !$show_basic ? 'd-none' : '' ?>" id="step0" style="border-radius:0 0 14px 14px;padding-top:24px;">
  <div class="d-flex align-items-center justify-content-between mb-3">
    <div>
      <div class="chart-card-title"><i class="bi bi-people-fill me-2 text-primary-nhs"></i>Basic Education — Enrollment, Repeaters & Dropouts</div>
      <div class="chart-card-sub">Kinder, Elementary & JHS · Seats auto-equal to enrollment</div>
    </div>
  </div>
  <div class="table-responsive">
    <table class="entry-table w-100">
      <thead>
        <tr>
          <th rowspan="2">Grade Level</th>
          <th colspan="3" class="th-group text-center">BOSY Enrollment</th>
          <th colspan="3" class="th-group text-center">Repeaters</th>
          <th colspan="3" class="th-group text-center">Dropouts</th>
        </tr>
        <tr>
          <th class="text-center th-male">♂ Male</th><th class="text-center th-female">♀ Female</th><th class="text-center">Total</th>
          <th class="text-center th-male">♂ Male</th><th class="text-center th-female">♀ Female</th><th class="text-center">Total</th>
          <th class="text-center th-male">♂ Male</th><th class="text-center th-female">♀ Female</th><th class="text-center">Total</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($basic_grades as $g):
          // Load existing gender values
          $em=0;$ef=0;$rm=0;$rf=0;$dm=0;$df=0;
          foreach($exist_enroll as $r) if((int)$r['grade_level_id']===(int)$g['id']&&!$r['strand_id']){ $em=$r['male_count']??0; $ef=$r['female_count']??0; break; }
          foreach($exist_rep   as $r) if((int)$r['grade_level_id']===(int)$g['id']&&!$r['strand_id']){ $rm=$r['male_count']??0; $rf=$r['female_count']??0; break; }
          foreach($exist_drop  as $r) if((int)$r['grade_level_id']===(int)$g['id']&&!$r['strand_id']){ $dm=$r['male_count']??0; $df=$r['female_count']??0; break; }
        ?>
        <tr>
          <td><span class="grade-badge"><?=htmlspecialchars($g['grade_name'])?></span></td>
          <!-- Enrollment -->
          <td><input type="number" name="jhs[<?=$g['id']?>][enroll_m]" min="0" value="<?=$em?>" placeholder="0" class="input-male jhs-m" data-gid="<?=$g['id']?>"></td>
          <td><input type="number" name="jhs[<?=$g['id']?>][enroll_f]" min="0" value="<?=$ef?>" placeholder="0" class="input-female jhs-f" data-gid="<?=$g['id']?>"></td>
          <td class="total-cell" id="et_<?=$g['id']?>"><?=($em+$ef)?></td>
          <!-- Irregulars / Repeaters -->
          <td><input type="number" name="jhs[<?=$g['id']?>][rep_m]" min="0" value="<?=$rm?>" placeholder="0" class="input-male jhs-rm" data-gid="<?=$g['id']?>"></td>
          <td><input type="number" name="jhs[<?=$g['id']?>][rep_f]" min="0" value="<?=$rf?>" placeholder="0" class="input-female jhs-rf" data-gid="<?=$g['id']?>"></td>
          <td class="total-cell" id="rt_<?=$g['id']?>"><?=($rm+$rf)?></td>
          <!-- Dropouts -->
          <td><input type="number" name="jhs[<?=$g['id']?>][drop_m]" min="0" value="<?=$dm?>" placeholder="0" class="input-male jhs-dm" data-gid="<?=$g['id']?>"></td>
          <td><input type="number" name="jhs[<?=$g['id']?>][drop_f]" min="0" value="<?=$df?>" placeholder="0" class="input-female jhs-df" data-gid="<?=$g['id']?>"></td>
          <td class="total-cell" id="dt_<?=$g['id']?>"><?=($dm+$df)?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="d-flex justify-content-end mt-3">
    <button type="button" class="btn-primary-nhs" onclick="goStep(<?= $show_shs ? 1 : 2 ?>)">Next: <?= $show_shs ? 'SHS Enrollment' : 'Teachers' ?> <i class="bi bi-arrow-right ms-1"></i></button>
  </div>
</div>

<!-- ═══════════════════ STEP 1: SHS Enrollment ═══════════════ -->
<style>
  .sem1-col, .sem2-col { display: none; }
  table.show-sem1 .sem1-col { display: table-cell; }
  table.show-sem2 .sem2-col { display: table-cell; }
</style>
<div class="chart-card step-panel <?= !$show_basic && $show_shs ? '' : 'd-none' ?>" id="step1" style="border-radius:0 0 14px 14px;padding-top:24px;">
  <div class="chart-card-title mb-1"><i class="bi bi-mortarboard-fill me-2 text-primary-nhs"></i>Senior High School — Enrollment per Strand & Semester</div>
  <div class="chart-card-sub mb-3">Grade 11 & Grade 12 · 1st and 2nd Semester</div>
  <?php foreach($shs as $g): 
    $rep_s1 = 0;
    $rep_s2 = 0;
    foreach($exist_rep as $r) {
      if((int)$r['grade_level_id']===(int)$g['id'] && !$r['strand_id']) {
        if($r['semester'] === '1st Sem') $rep_s1 = (int)$r['repeaters_count'];
        if($r['semester'] === '2nd Sem') $rep_s2 = (int)$r['repeaters_count'];
      }
    }
    $drop_s1 = 0;
    $drop_s2 = 0;
    foreach($exist_drop as $r) {
      if((int)$r['grade_level_id']===(int)$g['id'] && !$r['strand_id']) {
        if($r['semester'] === '1st Sem') $drop_s1 = (int)$r['dropouts_count'];
        if($r['semester'] === '2nd Sem') $drop_s2 = (int)$r['dropouts_count'];
      }
    }
  ?>
  <div class="mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3 mt-2">
      <div class="d-flex align-items-center gap-2">
        <div style="width:4px;height:28px;background:var(--primary);border-radius:4px"></div>
        <span class="fw-700 fs-6" style="color:var(--primary)"><?=htmlspecialchars($g['grade_name'])?></span>
        <span class="kpi-badge badge-info" style="font-size:.72rem">Senior High</span>
      </div>
      
      <!-- Semester Switch -->
      <div class="btn-group shadow-sm" role="group">
        <input type="radio" class="btn-check" name="sem_<?=$g['id']?>" id="sem1_<?=$g['id']?>" autocomplete="off" checked onchange="document.getElementById('table_<?=$g['id']?>').className='entry-table w-100 show-sem1'; document.getElementById('shs_annual_s1_<?=$g['id']?>').style.setProperty('display', 'flex', 'important'); document.getElementById('shs_annual_s2_<?=$g['id']?>').style.setProperty('display', 'none', 'important');">
        <label class="btn btn-outline-primary btn-sm px-4 fw-600" for="sem1_<?=$g['id']?>">1st Semester</label>

        <input type="radio" class="btn-check" name="sem_<?=$g['id']?>" id="sem2_<?=$g['id']?>" autocomplete="off" onchange="document.getElementById('table_<?=$g['id']?>').className='entry-table w-100 show-sem2'; document.getElementById('shs_annual_s1_<?=$g['id']?>').style.setProperty('display', 'none', 'important'); document.getElementById('shs_annual_s2_<?=$g['id']?>').style.setProperty('display', 'flex', 'important');">
        <label class="btn btn-outline-primary btn-sm px-4 fw-600" for="sem2_<?=$g['id']?>">2nd Semester</label>
      </div>
    </div>

    <!-- Semestral Grade Summary Row (Irregulars and Dropouts) -->
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-3 p-3 bg-light rounded-3 border">
      <div class="d-flex align-items-center gap-2">
        <i class="bi bi-info-circle-fill text-primary"></i>
        <div>
          <div class="fw-600 text-dark small">Semester Summary (Total)</div>
          <div class="text-muted small" style="font-size: 11px;">Input total Dropouts and Irregulars for the whole <?=htmlspecialchars($g['grade_name'])?>.</div>
        </div>
      </div>
      
      <!-- 1st Sem Summary Inputs -->
      <div class="d-flex gap-3" id="shs_annual_s1_<?=$g['id']?>">
        <div>
          <label class="form-label mb-1 fw-600 text-muted small"><i class="bi bi-arrow-repeat text-success me-1"></i>Irregulars (1st Sem)</label>
          <input type="number" name="shs_annual[<?=$g['id']?>][s1][rep]" min="0" value="<?=$rep_s1?>" placeholder="0" class="form-control form-control-sm" style="width:100px; border-color:#a5d6a7;">
        </div>
        <div>
          <label class="form-label mb-1 fw-600 text-muted small"><i class="bi bi-person-dash text-danger me-1"></i>Dropouts (1st Sem)</label>
          <input type="number" name="shs_annual[<?=$g['id']?>][s1][drop]" min="0" value="<?=$drop_s1?>" placeholder="0" class="form-control form-control-sm" style="width:100px; border-color:#ffcdd2;">
        </div>
      </div>

      <!-- 2nd Sem Summary Inputs -->
      <div class="d-flex gap-3" id="shs_annual_s2_<?=$g['id']?>" style="display: none !important;">
        <div>
          <label class="form-label mb-1 fw-600 text-muted small"><i class="bi bi-arrow-repeat text-success me-1"></i>Irregulars (2nd Sem)</label>
          <input type="number" name="shs_annual[<?=$g['id']?>][s2][rep]" min="0" value="<?=$rep_s2?>" placeholder="0" class="form-control form-control-sm" style="width:100px; border-color:#a5d6a7;">
        </div>
        <div>
          <label class="form-label mb-1 fw-600 text-muted small"><i class="bi bi-person-dash text-danger me-1"></i>Dropouts (2nd Sem)</label>
          <input type="number" name="shs_annual[<?=$g['id']?>][s2][drop]" min="0" value="<?=$drop_s2?>" placeholder="0" class="form-control form-control-sm" style="width:100px; border-color:#ffcdd2;">
        </div>
      </div>
    </div>

    <div class="table-responsive">
      <table id="table_<?=$g['id']?>" class="entry-table w-100 show-sem1">
        <thead>
          <tr>
            <th rowspan="2" style="min-width:250px">Strand / Track</th>
            <!-- 1st Sem Headers -->
            <th colspan="3" class="th-group text-center sem1-col" style="border-bottom-color:#0891b2">1st Sem Enrollment</th>
            <!-- 2nd Sem Headers -->
            <th colspan="3" class="th-group text-center sem2-col" style="border-bottom-color:#4f46e5">2nd Sem Enrollment</th>
          </tr>
          <tr>
            <!-- 1st Sem subheaders -->
            <th class="th-male sem1-col">♂ Male</th><th class="th-female sem1-col">♀ Female</th><th class="sem1-col">Total</th>
            <!-- 2nd Sem subheaders -->
            <th class="th-male sem2-col">♂ Male</th><th class="th-female sem2-col">♀ Female</th><th class="sem2-col">Total</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $any = false;
          foreach($strands as $st):
            $app = explode(',',$st['applicable_grades']??'');
            $gnum = substr($g['grade_name'],-2);
            if(!in_array(trim($gnum),$app)) continue;
            $any = true;
            // Find existing gender values
            $e1m=0;$e1f=0;$e2m=0;$e2f=0;
            foreach($exist_enroll as $r){
              if((int)$r['grade_level_id']===(int)$g['id']&&(int)($r['strand_id']??0)===(int)$st['id']){
                if($r['semester']==='1st Sem'){ $e1m=$r['male_count']??0; $e1f=$r['female_count']??0; }
                if($r['semester']==='2nd Sem'){ $e2m=$r['male_count']??0; $e2f=$r['female_count']??0; }
              }
            }
            $uid = $g['id'].'_'.$st['id'];
          ?>
          <tr>
            <td>
              <div class="d-flex align-items-center gap-2 flex-nowrap">
                <span class="strand-badge" style="white-space:nowrap"><?=htmlspecialchars($st['strand_code'])?></span>
                <span class="text-muted" style="font-size:.75rem"><?=htmlspecialchars($st['strand_name'])?></span>
              </div>
            </td>
            <!-- 1st Sem Enrollment -->
            <td class="sem1-col"><input type="number" class="input-male shs-input" name="shs[<?=$g['id']?>][<?=$st['id']?>][s1][enroll_m]" min="0" value="<?=$e1m?>" placeholder="0" data-cell="e1_<?=$uid?>"></td>
            <td class="sem1-col"><input type="number" class="input-female shs-input" name="shs[<?=$g['id']?>][<?=$st['id']?>][s1][enroll_f]" min="0" value="<?=$e1f?>" placeholder="0" data-cell="e1_<?=$uid?>"></td>
            <td class="sem1-col total-cell" id="e1_<?=$uid?>"><?=($e1m+$e1f)?></td>
            
            <!-- 2nd Sem Enrollment -->
            <td class="sem2-col"><input type="number" class="input-male shs-input" name="shs[<?=$g['id']?>][<?=$st['id']?>][s2][enroll_m]" min="0" value="<?=$e2m?>" placeholder="0" data-cell="e2_<?=$uid?>"></td>
            <td class="sem2-col"><input type="number" class="input-female shs-input" name="shs[<?=$g['id']?>][<?=$st['id']?>][s2][enroll_f]" min="0" value="<?=$e2f?>" placeholder="0" data-cell="e2_<?=$uid?>"></td>
            <td class="sem2-col total-cell" id="e2_<?=$uid?>"><?=($e2m+$e2f)?></td>
          </tr>
          <?php endforeach; ?>
          <?php if(!$any): ?>
          <tr><td colspan="6" class="text-muted text-center small py-2">No strands applicable for <?=htmlspecialchars($g['grade_name'])?>.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endforeach; ?>

  <div class="d-flex justify-content-between mt-3">
    <button type="button" class="btn-outline-nhs" onclick="goStep(0)"><i class="bi bi-arrow-left me-1"></i> Back</button>
    <button type="button" class="btn-primary-nhs" onclick="goStep(2)">Next: Teachers <i class="bi bi-arrow-right ms-1"></i></button>
  </div>
</div>

<!-- ═══════════════════ STEP 2: Teachers ════════════════════ -->
<div class="chart-card step-panel d-none" id="step2" style="border-radius:0 0 14px 14px;padding-top:24px;">
  <div class="chart-card-title mb-1"><i class="bi bi-person-video3 me-2 text-primary-nhs"></i>Teacher Count</div>
  <div class="chart-card-sub mb-3">JHS per Grade Level · SHS per Learning Area</div>
  <div class="row g-4">
    <!-- JHS/Basic Teachers -->
    <?php if ($show_basic): ?>
    <div class="col-md-5">
      <div class="fw-700 mb-2" style="color:var(--primary);font-size:.9rem">
        <i class="bi bi-mortarboard me-1"></i>Basic Ed — Per Grade Level
      </div>
      <table class="entry-table w-100">
        <thead><tr><th>Grade</th><th class="text-center">Teachers</th></tr></thead>
        <tbody>
          <?php foreach($basic_grades as $g): ?>
          <tr>
            <td><span class="grade-badge"><?=htmlspecialchars($g['grade_name'])?></span></td>
            <td class="text-center">
              <input type="number" name="tg[<?=$g['id']?>]" min="0"
                value="<?=findTeacherGrade($exist_tg,$g['id'])?>"
                placeholder="0">
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
    <!-- SHS / JHS Learning Areas -->
    <div class="<?= $show_basic ? 'col-md-7' : 'col-12' ?>">
      <?php if (has_jhs()): ?>
      <div class="fw-700 mb-2" style="color:#0891b2;font-size:.9rem">
        <i class="bi bi-book me-1"></i>JHS Learning Areas
      </div>
      <table class="entry-table w-100 mb-3">
        <thead><tr><th>Learning Area</th><th class="text-center">Teachers</th></tr></thead>
        <tbody>
          <?php foreach($jhs_areas as $area): ?>
          <tr>
            <td class="small fw-500"><?=htmlspecialchars($area)?></td>
            <td class="text-center">
              <input type="number" name="ta_jhs[<?=htmlspecialchars($area)?>]" min="0"
                value="<?=findTeacherArea($exist_ta,$area,'Junior High')?>"
                placeholder="0">
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
      
      <?php if (has_shs()): ?>
      <div class="fw-700 mb-2" style="color:#7c3aed;font-size:.9rem">
        <i class="bi bi-book-fill me-1"></i>SHS Learning Areas
      </div>
      <table class="entry-table w-100">
        <thead><tr><th>Learning Area</th><th class="text-center">Teachers</th></tr></thead>
        <tbody>
          <?php foreach($shs_areas as $area): ?>
          <tr>
            <td class="small fw-500"><?=htmlspecialchars($area)?></td>
            <td class="text-center">
              <input type="number" name="ta_shs[<?=htmlspecialchars($area)?>]" min="0"
                value="<?=findTeacherArea($exist_ta,$area,'Senior High')?>"
                placeholder="0">
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </div>
  <div class="d-flex justify-content-between mt-3">
    <button type="button" class="btn-outline-nhs" onclick="goStep(<?= $show_shs ? 1 : 0 ?>)"><i class="bi bi-arrow-left me-1"></i> Back</button>
    <button type="button" class="btn-primary-nhs" onclick="goStep(3)">Next: Seats <i class="bi bi-arrow-right ms-1"></i></button>
  </div>
</div>

<!-- ═══════════════════ STEP 3: Seats ═══════════════════════ -->
<div class="chart-card step-panel d-none" id="step3" style="border-radius:0 0 14px 14px;padding-top:24px;">
  <div class="chart-card-title mb-1"><i class="bi bi-person-workspace me-2 text-primary-nhs"></i>Available Seats per Grade Level</div>
  <div class="chart-card-sub mb-3">Seats = Number of students if using standard (auto-filled from enrollment above). Adjust if different.</div>
  <table class="entry-table w-100">
    <thead>
      <tr><th>Grade Level</th><th>Type</th><th class="text-center">Available Seats</th><th class="text-muted small" style="font-weight:400">Note</th></tr>
    </thead>
    <tbody>
      <?php foreach($grades as $g):
        $s_val=0;
        foreach($exist_seats as $r) if((int)$r['grade_level_id']===(int)$g['id']&&!$r['strand_id']){ $s_val=(int)$r['available_seats']; break; }
        
        $std = '45 students/class standard';
        if ($g['level_type'] === 'Kindergarten') $std = '25 students/class standard';
        elseif ($g['level_type'] === 'Elementary') $std = '35 students/class standard';
        elseif ($g['level_type'] === 'Senior High') $std = '40 students/class standard';
      ?>
      <tr>
        <td><span class="grade-badge"><?=htmlspecialchars($g['grade_name'])?></span></td>
        <td><span class="kpi-badge badge-info" style="font-size:.72rem"><?=$g['level_type']?></span></td>
        <td class="text-center">
          <input type="number" name="seats[<?=$g['id']?>]" min="0" value="<?=$s_val?>" placeholder="0"
            id="seat_<?=$g['id']?>">
        </td>
        <td class="text-muted small"><?=$std?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <div class="d-flex justify-content-between mt-3">
    <button type="button" class="btn-outline-nhs" onclick="goStep(2)"><i class="bi bi-arrow-left me-1"></i> Back</button>
    <button type="button" class="btn-primary-nhs" onclick="goStep(4)">Review & Save <i class="bi bi-arrow-right ms-1"></i></button>
  </div>
</div>

<!-- ═══════════════════ STEP 4: Review & Save ═══════════════ -->
<div class="chart-card step-panel d-none" id="step4" style="border-radius:0 0 14px 14px;padding-top:24px;">
  <div class="chart-card-title mb-1"><i class="bi bi-check-circle-fill text-success me-2"></i>Review & Save</div>
  <div class="chart-card-sub mb-4">All data will be saved for S.Y. <strong><?=htmlspecialchars($sel_sy)?></strong>. Existing records for this school year will be replaced.</div>

  <div class="insight-card success mb-3">
    <div class="d-flex gap-3">
      <span class="insight-icon">💾</span>
      <div>
        <div class="insight-title">What happens when you click Save?</div>
        <div class="insight-body mt-1">
          The system will safely <strong>update</strong> any existing records for S.Y. <?=htmlspecialchars($sel_sy)?>. Data you haven't modified will be left intact, and new data will be carefully merged without losing your previous entries.
        </div>
      </div>
    </div>
  </div>

  <div id="reviewSummary" class="mb-4">
    <div class="text-muted small text-center py-3"><i class="bi bi-hourglass-split me-1"></i>Click "Generate Preview" to see a summary before saving.</div>
  </div>

  <div class="d-flex justify-content-between gap-3 flex-wrap">
    <button type="button" class="btn-outline-nhs" onclick="goStep(3)"><i class="bi bi-arrow-left me-1"></i> Back</button>
    <div class="d-flex gap-2">
      <button type="button" class="btn-outline-nhs" onclick="generatePreview()"><i class="bi bi-eye me-1"></i>Generate Preview</button>
      <button type="submit" class="btn-primary-nhs" id="saveBtn">
        <i class="bi bi-save me-1"></i>Save All Data for S.Y. <?=htmlspecialchars($sel_sy)?>
      </button>
    </div>
  </div>
</div>

</form>

<script>
let currentStep = 0;
const totalSteps = 5;

// Auto-total: whenever Male or Female input changes, update Total cell
document.addEventListener('input', function(e){
  const el = e.target;

  // SHS auto-total (SHS inputs do not have data-gid, so process them first)
  if(el.classList.contains('shs-input')){
    const cellId = el.dataset.cell;
    if(cellId){
      const row = el.closest('tr');
      const pairs = row.querySelectorAll(`[data-cell="${cellId}"]`);
      let tot=0; pairs.forEach(i=>tot+=parseInt(i.value)||0);
      const cell = document.getElementById(cellId);
      if(cell) cell.textContent = tot;
    }
    return;
  }

  // JHS auto-total (JHS inputs require data-gid)
  const gid = el.dataset.gid;
  if(!gid) return;

  // Enrollment total
  if(el.classList.contains('jhs-m') || el.classList.contains('jhs-f')){
    const m = parseInt(document.querySelector(`.jhs-m[data-gid="${gid}"]`)?.value)||0;
    const f = parseInt(document.querySelector(`.jhs-f[data-gid="${gid}"]`)?.value)||0;
    const cell = document.getElementById('et_'+gid);
    if(cell) cell.textContent = m+f;
  }
  // Repeaters total
  if(el.classList.contains('jhs-rm') || el.classList.contains('jhs-rf')){
    const m = parseInt(document.querySelector(`.jhs-rm[data-gid="${gid}"]`)?.value)||0;
    const f = parseInt(document.querySelector(`.jhs-rf[data-gid="${gid}"]`)?.value)||0;
    const cell = document.getElementById('rt_'+gid);
    if(cell) cell.textContent = m+f;
  }
  // Dropouts total
  if(el.classList.contains('jhs-dm') || el.classList.contains('jhs-df')){
    const m = parseInt(document.querySelector(`.jhs-dm[data-gid="${gid}"]`)?.value)||0;
    const f = parseInt(document.querySelector(`.jhs-df[data-gid="${gid}"]`)?.value)||0;
    const cell = document.getElementById('dt_'+gid);
    if(cell) cell.textContent = m+f;
  }
});

function goStep(n){
  const showBasic = <?= $show_basic ? 'true' : 'false' ?>;
  const showSHS   = <?= $show_shs ? 'true' : 'false' ?>;
  
  if (n === 0 && !showBasic) { goStep(1); return; }
  if (n === 1 && !showSHS) { goStep(showBasic ? 2 : 1); return; }

  document.querySelectorAll('.step-panel').forEach((p)=>{
    p.classList.add('d-none');
  });
  
  const panel = document.getElementById('step' + n);
  if (panel) panel.classList.remove('d-none');
  
  document.querySelectorAll('.step-indicator .step').forEach((s)=>{
    s.classList.remove('active','done');
  });
  
  const activeInd = document.getElementById('indStep' + n);
  if (activeInd) activeInd.classList.add('active');
  
  for (let i = 0; i < n; i++) {
    const prevInd = document.getElementById('indStep' + i);
    if (prevInd) prevInd.classList.add('done');
  }
  
  currentStep = n;
  window.scrollTo({top:0,behavior:'smooth'});
}

// Initialise the correct starting step on page load
document.addEventListener('DOMContentLoaded', function(){
  const showBasic = <?= $show_basic ? 'true' : 'false' ?>;
  goStep(showBasic ? 0 : 1);
});

function generatePreview(){
  const fd = new FormData(document.getElementById('dataEntryForm'));
  let html = '<table class="nhs-table"><thead><tr><th>Section</th><th>Item</th><th class="text-center">Value</th></tr></thead><tbody>';
  let rows = [];
  for(let [k,v] of fd.entries()){
    if(v && v!=='0' && k!=='school_year') rows.push({k,v});
  }
  if(rows.length===0){ document.getElementById('reviewSummary').innerHTML='<div class="text-muted text-center py-3">No data entered yet.</div>'; return; }
  let count=0;
  rows.slice(0,15).forEach(r=>{
    const parts = r.k.replace(/\[/g,' ').replace(/\]/g,'').trim().split(' ');
    html+=`<tr><td class="text-muted small">${parts[0]}</td><td class="small">${r.k}</td><td class="text-center fw-600">${r.v}</td></tr>`;
    count++;
  });
  if(rows.length>15) html+=`<tr><td colspan="3" class="text-center text-muted small">... and ${rows.length-15} more fields</td></tr>`;
  html+='</tbody></table>';
  document.getElementById('reviewSummary').innerHTML=`<div class="small text-success fw-600 mb-2"><i class="bi bi-check me-1"></i>${rows.length} data fields ready to save</div>`+html;
}

async function submitAll(e){
  e.preventDefault();
  const confirm = await Swal.fire({
    title:'Save All Data?',
    html:`This will replace all existing records for <strong>S.Y. <?=htmlspecialchars($sel_sy)?></strong> with the values you entered.`,
    icon:'warning',
    showCancelButton:true,
    confirmButtonColor:'#0F4C81',
    cancelButtonColor:'#6b7280',
    confirmButtonText:'<i class="bi bi-save me-1"></i>Yes, Save All',
    cancelButtonText:'Cancel'
  });
  if(!confirm.isConfirmed) return;

  showSpinner();
  const fd = new FormData(document.getElementById('dataEntryForm'));
  const data = {};
  for(let [k,v] of fd.entries()) data[k]=v;

  try{
    const r = await fetch('ajax/bulk_save.php',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(data)
    });
    const text = await r.text();
    let res;
    try {
      res = JSON.parse(text);
    } catch(parseErr) {
      throw new Error("Raw Response: " + text.substring(0, 300) + " (Error: " + parseErr.message + ")");
    }
    hideSpinner();
    if(res.success){
      await Swal.fire({
        icon:'success',
        title:'Data Saved!',
        html:`<strong>${res.inserted}</strong> records saved for S.Y. <?=htmlspecialchars($sel_sy)?>.`,
        confirmButtonColor:'#0F4C81'
      });
      window.location.href='index.php?sy=<?=urlencode($sel_sy)?>';
    } else {
      toastError(res.message||'Save failed.');
    }
  } catch(err){
    hideSpinner();
    toastError('Request failed: '+err.message);
  }
}

// Handle new SY creation — must be a named function so the select's onchange can call it
// BEFORE the form submits (inline onchange fires synchronously; addEventListener fires after submit).
function handleSYChange(sel) {
  if (sel.value === 'new_sy') {
    // Prevent ANY form submission from happening
    Swal.fire({
      title: 'Add New School Year',
      input: 'text',
      inputLabel: 'School Year',
      inputValue: '<?= htmlspecialchars($next_sy) ?>',
      inputPlaceholder: 'YYYY-YYYY',
      confirmButtonColor: '#0F4C81',
      showCancelButton: true,
      inputValidator: (value) => {
        if (!value) return 'Please enter a school year!';
        if (!/^\d{4}-\d{4}$/.test(value)) return 'Format must be YYYY-YYYY (e.g. 2026-2027)';
        const parts = value.split('-');
        if (parseInt(parts[1]) !== parseInt(parts[0]) + 1) return 'The second year must be one after the first (e.g. 2026-2027).';
      }
    }).then(r => {
      if (r.isConfirmed && r.value) {
        // Navigate directly with the confirmed school year
        window.location.href = 'data_entry.php?sy=' + encodeURIComponent(r.value);
      } else {
        // User cancelled — restore previous selection
        sel.value = '<?= htmlspecialchars($sel_sy) ?>';
      }
    });
  } else {
    // Normal school year selected — submit the form
    sel.closest('form').submit();
  }
}
</script>

<?php include 'includes/footer.php'; ?>
