<?php
require_once __DIR__ . '/config/session.php';
require_login();

// Strictly restrict to Admins only
if (!has_role('Admin')) {
    http_response_code(403);
    die('Access denied. Administrator privileges required to access System Settings.');
}

$page_title = 'System Settings';
$breadcrumb = 'Configuration';

include 'includes/header.php';
?>
<style>
/* --- Color Palette Tokens --- */
:root {
  --glow-blue: 27, 42, 107;
  --glow-gold: 201, 162, 39;
  --text-rgb: 26, 26, 46;
}
[data-theme="dark"] {
  --glow-blue: 107, 155, 232;
  --glow-gold: 240, 202, 118;
  --text-rgb: 220, 226, 244;
}

/* --- Premium Layout Styles --- */
.glass-panel-settings {
  background: rgba(255, 255, 255, 0.55);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.4);
  border-radius: 16px;
  box-shadow: 0 8px 32px rgba(27, 42, 107, 0.05);
  transition: var(--transition);
}
[data-theme="dark"] .glass-panel-settings {
  background: rgba(37, 42, 68, 0.45);
  border: 1px solid rgba(255, 255, 255, 0.06);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.22);
}

.profile-card-header {
  position: relative;
  background: linear-gradient(135deg, var(--primary) 0%, rgba(var(--glow-blue), 0.8) 100%);
  border-radius: 14px 14px 0 0;
  padding: 40px 24px;
  color: #ffffff;
  overflow: hidden;
}
.profile-card-header::before {
  content: '';
  position: absolute;
  top: -50%;
  right: -10%;
  width: 250px;
  height: 250px;
  background: radial-gradient(circle, rgba(255,255,255,0.12) 0%, transparent 70%);
}

.branding-preview-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 30px;
  background: var(--bg);
  border: 2px dashed var(--border);
  border-radius: 14px;
  text-align: center;
  transition: var(--transition);
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.branding-preview-container:hover {
  border-color: var(--primary);
  background: rgba(var(--glow-blue), 0.02);
}
[data-theme="dark"] .branding-preview-container:hover {
  background: rgba(107, 155, 232, 0.03);
}

.logo-preview-frame {
  width: 140px;
  height: 140px;
  border-radius: 50%;
  background: #ffffff;
  box-shadow: var(--shadow-md);
  border: 4px solid var(--surface);
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  transition: var(--transition);
}
.logo-preview-frame img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.upload-overlay {
  position: absolute;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(var(--glow-blue), 0.4);
  backdrop-filter: blur(4px);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #ffffff;
  opacity: 0;
  transition: var(--transition);
  border-radius: 14px;
}
.branding-preview-container:hover .upload-overlay {
  opacity: 1;
}

.preview-label-name {
  font-size: 1.35rem;
  font-weight: 850;
  color: var(--text);
  letter-spacing: -0.5px;
}
</style>

<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
  <div class="section-header mb-0">
    <h1 class="section-title"><i class="bi bi-gear-fill me-2 text-primary-nhs"></i>System Settings</h1>
    <p class="section-sub">Configure school identity, branding, theme colors, and DepEd standards</p>
  </div>
</div>


<div class="row g-4">
  <!-- Left Side: Live Preview Panel -->
  <div class="col-lg-5">
    <div class="glass-panel-settings p-0 h-100" style="overflow: hidden; display: flex; flex-direction: column;">
      <div class="profile-card-header" id="previewHeader">
        <h4 class="fw-800 mb-1">Branding Preview</h4>
        <p class="mb-0 text-white-50 small">This is how your branding displays in headers and sidebars.</p>
      </div>
      <div class="p-4 d-flex flex-grow-1 flex-column align-items-center justify-content-center">
        <!-- Brand Logo Preview Container -->
        <div class="branding-preview-container w-100 mb-4" onclick="document.getElementById('logoFileInput').click()">
          <div class="logo-preview-frame mb-3">
            <img id="logoLivePreview" src="<?= htmlspecialchars(APP_LOGO) ?>" onerror="this.src='https://ui-avatars.com/api/?name=School&background=fff&color=0F4C81&size=120'">
          </div>
          <div class="upload-overlay">
            <i class="bi bi-camera-fill fs-2 mb-2"></i>
            <span class="fw-600 small">Upload New Logo</span>
          </div>
          <h5 class="preview-label-name mt-2 text-center" id="nameLivePreview"><?= htmlspecialchars(APP_NAME) ?></h5>
          <span class="text-muted small mt-1" id="divisionLivePreview"><?= htmlspecialchars(APP_SCHOOL_DIVISION ?: 'Analytics Profile') ?></span>
        </div>

        <!-- Color Preview Swatch -->
        <div class="w-100 mb-3 d-flex gap-2 align-items-center">
          <span class="text-muted small">Theme Color:</span>
          <div id="colorSwatchPreview" style="width:32px;height:32px;border-radius:8px;background:<?= APP_PRIMARY_COLOR ?>;border:2px solid var(--border);flex-shrink:0;"></div>
          <span id="colorHexPreview" class="small fw-600"><?= APP_PRIMARY_COLOR ?></span>
        </div>
        
        <div class="w-100 alert alert-info border-0 shadow-sm d-flex gap-3 px-3 py-3" style="border-radius: 12px; background: rgba(var(--primary-rgb), 0.05); color: var(--text);">
          <i class="bi bi-info-circle-fill text-primary fs-4"></i>
          <div class="small">
            <strong>Branding Tips:</strong>
            <ul class="mb-0 ps-3 mt-1 text-muted">
              <li>Use a square (1:1 aspect ratio) transparent PNG logo.</li>
              <li>Maximum file size is restricted to <strong>2MB</strong>.</li>
              <li>The name will automatically fit layout headers.</li>
              <li>Reload the page after saving to see color changes.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Right Side: Edit Form Configuration Panel -->
  <div class="col-lg-7">
    <div class="glass-panel-settings p-4 h-100">

      <!-- Section Tabs -->
      <ul class="nav nav-pills mb-4 gap-2" id="settingsTabs">
        <li class="nav-item">
          <button class="nav-link active" onclick="switchTab('profile')" id="tab-profile">
            <i class="bi bi-building me-1"></i>School Profile
          </button>
        </li>
        <li class="nav-item">
          <button class="nav-link" onclick="switchTab('branding')" id="tab-branding">
            <i class="bi bi-palette me-1"></i>Branding & Theme
          </button>
        </li>
        <li class="nav-item">
          <button class="nav-link" onclick="switchTab('deped')" id="tab-deped">
            <i class="bi bi-rulers me-1"></i>DepEd Standards
          </button>
        </li>
      </ul>

      <form id="settingsForm" onsubmit="submitSystemSettings(event)" enctype="multipart/form-data">
        <input type="hidden" name="action" value="save_settings">

        <!-- ══ TAB 1: School Profile ══ -->
        <div id="tab-content-profile">
          <div class="mb-3">
            <label class="form-label fw-750 text-muted small d-flex align-items-center gap-2 mb-1">
              <i class="bi bi-building"></i> School / Academy Name *
            </label>
            <input type="text" name="school_name" id="fSchoolName" class="form-control px-3" required
                   value="<?= htmlspecialchars(APP_NAME) ?>" placeholder="e.g. Juan Luna National High School"
                   style="height: 48px; border-radius: 12px;" oninput="updateNameLivePreview(this.value)">
          </div>
          <div class="mb-3">
            <label class="form-label fw-750 text-muted small d-flex align-items-center gap-2 mb-1">
              <i class="bi bi-quote"></i> School Tagline <span class="text-muted fw-400">(shown on login page)</span>
            </label>
            <input type="text" name="school_tagline" class="form-control px-3"
                   value="<?= htmlspecialchars(APP_TAGLINE) ?>" placeholder="e.g. Empowering students through excellence"
                   style="height: 48px; border-radius: 12px;">
          </div>
          <div class="mb-3">
            <label class="form-label fw-750 text-muted small d-flex align-items-center gap-2 mb-1">
              <i class="bi bi-map"></i> School Address
            </label>
            <input type="text" name="school_address" class="form-control px-3"
                   value="<?= htmlspecialchars(APP_SCHOOL_ADDRESS) ?>" placeholder="e.g. Brgy. Poblacion, Municipality, Province"
                   style="height: 48px; border-radius: 12px;">
          </div>
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label fw-750 text-muted small d-flex align-items-center gap-2 mb-1">
                <i class="bi bi-diagram-3"></i> DepEd Division
              </label>
              <input type="text" name="school_division" class="form-control px-3"
                     value="<?= htmlspecialchars(APP_SCHOOL_DIVISION) ?>" placeholder="e.g. Division of Pangasinan II"
                     style="height: 48px; border-radius: 12px;" oninput="updateDivisionPreview(this.value)">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-750 text-muted small d-flex align-items-center gap-2 mb-1">
                <i class="bi bi-hash"></i> BEIS School ID
              </label>
              <input type="text" name="school_id" class="form-control px-3"
                     value="<?= htmlspecialchars(APP_SCHOOL_ID) ?>" placeholder="e.g. 300123"
                     style="height: 48px; border-radius: 12px;">
            </div>
            <div class="col-12">
              <label class="form-label fw-750 text-muted small d-flex align-items-center gap-2 mb-1">
                <i class="bi bi-telephone"></i> Contact Number / Email
              </label>
              <input type="text" name="school_contact" class="form-control px-3"
                     value="<?= htmlspecialchars(APP_SCHOOL_CONTACT) ?>" placeholder="e.g. 09XX-XXX-XXXX"
                     style="height: 48px; border-radius: 12px;">
            </div>
            <div class="col-12 mt-3">
              <label class="form-label fw-750 text-muted small d-flex align-items-center gap-2 mb-1">
                <i class="bi bi-mortarboard-fill"></i> Academic Levels Offered *
              </label>
              <div class="d-flex flex-wrap gap-4 mt-2 p-3 rounded-3" style="background: var(--bg); border: 1px solid var(--border);">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="offered_levels[]" id="edit_level_kinder" value="kinder" <?= has_kinder() ? 'checked' : '' ?>>
                  <label class="form-check-label small fw-500" for="edit_level_kinder">Kindergarten</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="offered_levels[]" id="edit_level_elem" value="elem" <?= has_elementary() ? 'checked' : '' ?>>
                  <label class="form-check-label small fw-500" for="edit_level_elem">Elementary (G1-G6)</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="offered_levels[]" id="edit_level_jhs" value="jhs" <?= has_jhs() ? 'checked' : '' ?>>
                  <label class="form-check-label small fw-500" for="edit_level_jhs">Junior High (G7-G10)</label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="offered_levels[]" id="edit_level_shs" value="shs" <?= has_shs() ? 'checked' : '' ?>>
                  <label class="form-check-label small fw-500" for="edit_level_shs">Senior High (G11-G12)</label>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- ══ TAB 2: Branding & Theme ══ -->
        <div id="tab-content-branding" style="display:none;">
          <!-- School Logo -->
          <div class="mb-3">
            <label class="form-label fw-750 text-muted small d-flex align-items-center gap-2 mb-1">
              <i class="bi bi-card-image"></i> Brand Logo Image File
            </label>
            <div class="input-group">
              <input type="text" id="logoFileNameDisplay" class="form-control" placeholder="No file chosen" readonly style="height:48px; border-radius:12px 0 0 12px; background:var(--bg);">
              <button class="btn btn-outline-primary px-4 fw-600" type="button" onclick="document.getElementById('logoFileInput').click()" style="border-radius: 0 12px 12px 0; font-size: 0.85rem;">Browse...</button>
            </div>
            <input type="file" name="school_logo" id="logoFileInput" accept="image/png, image/jpeg, image/jpg" onchange="previewSelectedLogo(event)" class="d-none">
          </div>

          <!-- Primary Color Picker -->
          <div class="mb-3">
            <label class="form-label fw-750 text-muted small d-flex align-items-center gap-2 mb-1">
              <i class="bi bi-palette-fill"></i> Primary Theme Color <span class="text-muted fw-400">(sidebar, buttons, charts)</span>
            </label>
            <div class="d-flex gap-3 align-items-center">
              <input type="color" name="primary_color" id="fPrimaryColor"
                     value="<?= htmlspecialchars(APP_PRIMARY_COLOR) ?>"
                     style="width:56px;height:48px;border-radius:12px;border:1px solid var(--border);padding:4px;cursor:pointer;"
                     oninput="updateColorPreview(this.value)">
              <input type="text" id="fPrimaryColorHex" class="form-control px-3" style="height:48px;border-radius:12px;max-width:140px;font-family:monospace;"
                     value="<?= htmlspecialchars(APP_PRIMARY_COLOR) ?>" placeholder="#1B2A6B"
                     oninput="syncColorPicker(this.value)">
              <span class="text-muted small">Pick your school's primary color</span>
            </div>
          </div>

          <!-- Secondary Color Picker -->
          <div class="mb-3">
            <label class="form-label fw-750 text-muted small d-flex align-items-center gap-2 mb-1">
              <i class="bi bi-palette2"></i> Secondary / Accent Color <span class="text-muted fw-400">(highlights, badges)</span>
            </label>
            <div class="d-flex gap-3 align-items-center">
              <input type="color" name="secondary_color" id="fSecondaryColor"
                     value="<?= htmlspecialchars(APP_SECONDARY_COLOR) ?>"
                     style="width:56px;height:48px;border-radius:12px;border:1px solid var(--border);padding:4px;cursor:pointer;">
              <input type="text" id="fSecondaryColorHex" class="form-control px-3" style="height:48px;border-radius:12px;max-width:140px;font-family:monospace;"
                     value="<?= htmlspecialchars(APP_SECONDARY_COLOR) ?>" placeholder="#C9A227">
              <span class="text-muted small">Pick your school's accent color</span>
            </div>
          </div>

          <!-- Preset Color Swatches -->
          <div class="mb-3">
            <label class="form-label fw-750 text-muted small mb-2">Quick Presets</label>
            <div class="d-flex flex-wrap gap-2">
              <?php
              $presets = [
                ['#1B2A6B','#C9A227','Navy & Gold (Default)'],
                ['#0F4C81','#F59E0B','Royal Blue & Amber'],
                ['#065F46','#FCD34D','Forest Green & Yellow'],
                ['#7C3AED','#F472B6','Purple & Pink'],
                ['#B91C1C','#FCA5A5','Crimson & Rose'],
                ['#0E7490','#34D399','Teal & Emerald'],
              ];
              foreach ($presets as $p): ?>
              <button type="button" class="btn btn-sm d-flex align-items-center gap-2 px-3 py-2"
                style="border-radius:10px;border:1px solid var(--border);font-size:0.78rem;"
                onclick="applyPreset('<?= $p[0] ?>','<?= $p[1] ?>')">
                <span style="width:14px;height:14px;border-radius:4px;background:<?= $p[0] ?>;display:inline-block;"></span>
                <span style="width:14px;height:14px;border-radius:4px;background:<?= $p[1] ?>;display:inline-block;"></span>
                <?= $p[2] ?>
              </button>
              <?php endforeach; ?>
            </div>
          </div>
        </div>

        <!-- ══ TAB 3: DepEd Standards ══ -->
        <div id="tab-content-deped" style="display:none;">
          <p class="text-muted small mb-3">These values are used to calculate classroom sufficiency and teacher ratios across all reports. Adjust to match your division's current standards.</p>
          <div class="row g-3">
            <?php if (has_jhs()): ?>
            <div class="col-md-6">
              <label class="form-label fw-750 text-muted small mb-1"><i class="bi bi-people me-1"></i>JHS Class Size Standard</label>
              <input type="number" name="deped_jhs_class_size" class="form-control px-3" min="1" max="100"
                     value="<?= htmlspecialchars($settings_data['deped_jhs_class_size'] ?? DEPED_JHS_CLASS_SIZE) ?>"
                     style="height:48px;border-radius:12px;">
            </div>
            <?php endif; ?>
            <?php if (has_shs()): ?>
            <div class="col-md-6">
              <label class="form-label fw-750 text-muted small mb-1"><i class="bi bi-people me-1"></i>SHS Class Size Standard</label>
              <input type="number" name="deped_shs_class_size" class="form-control px-3" min="1" max="100"
                     value="<?= htmlspecialchars($settings_data['deped_shs_class_size'] ?? DEPED_SHS_CLASS_SIZE) ?>"
                     style="height:48px;border-radius:12px;">
            </div>
            <?php endif; ?>
            <?php if (has_jhs()): ?>
            <div class="col-md-6">
              <label class="form-label fw-750 text-muted small mb-1"><i class="bi bi-person-workspace me-1"></i>JHS Teacher Ratio</label>
              <input type="number" name="deped_jhs_teacher_ratio" class="form-control px-3" min="1" max="100"
                     value="<?= htmlspecialchars($settings_data['deped_jhs_teacher_ratio'] ?? DEPED_JHS_TEACHER_RATIO) ?>"
                     style="height:48px;border-radius:12px;">
            </div>
            <?php endif; ?>
            <?php if (has_shs()): ?>
            <div class="col-md-6">
              <label class="form-label fw-750 text-muted small mb-1"><i class="bi bi-person-workspace me-1"></i>SHS Teacher Ratio</label>
              <input type="number" name="deped_shs_teacher_ratio" class="form-control px-3" min="1" max="100"
                     value="<?= htmlspecialchars($settings_data['deped_shs_teacher_ratio'] ?? DEPED_SHS_TEACHER_RATIO) ?>"
                     style="height:48px;border-radius:12px;">
            </div>
            <?php endif; ?>
          </div>
        </div>

        <hr class="my-4 border-light border-opacity-10">
        <div class="d-flex gap-2 justify-content-end">
          <button type="button" class="btn btn-secondary px-4 py-2" style="border-radius: 12px; font-weight:600;" onclick="resetForm()">Reset Changes</button>
          <button type="submit" class="btn-primary-nhs px-4 py-2" style="border-radius: 12px; height: auto;"><i class="bi bi-check2-all me-1"></i>Save Settings</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
const defaultAppName    = <?= json_encode(APP_NAME) ?>;
const defaultAppLogo    = <?= json_encode(APP_LOGO) ?>;
const defaultPrimary    = <?= json_encode(APP_PRIMARY_COLOR) ?>;
const defaultSecondary  = <?= json_encode(APP_SECONDARY_COLOR) ?>;

// ── Tab Switching ─────────────────────────────────────────
function switchTab(tab) {
  ['profile','branding','deped'].forEach(t => {
    document.getElementById('tab-content-' + t).style.display = t === tab ? '' : 'none';
    document.getElementById('tab-' + t).classList.toggle('active', t === tab);
  });
}

// ── Live Preview Helpers ───────────────────────────────────
function updateNameLivePreview(val) {
  const el = document.getElementById('nameLivePreview');
  if (el) el.innerText = val.trim() !== '' ? val : defaultAppName;
}

function updateDivisionPreview(val) {
  const el = document.getElementById('divisionLivePreview');
  if (el) el.innerText = val.trim() !== '' ? val : 'Analytics Profile';
}

function updateColorPreview(hex) {
  document.getElementById('colorSwatchPreview').style.background = hex;
  document.getElementById('colorHexPreview').innerText = hex;
  document.getElementById('fPrimaryColorHex').value = hex;
  document.getElementById('previewHeader').style.background = 'linear-gradient(135deg,' + hex + ', ' + hex + 'aa)';
}

function syncColorPicker(hex) {
  if (/^#[0-9A-Fa-f]{6}$/.test(hex)) {
    document.getElementById('fPrimaryColor').value = hex;
    updateColorPreview(hex);
  }
}

function applyPreset(primary, secondary) {
  document.getElementById('fPrimaryColor').value = primary;
  document.getElementById('fPrimaryColorHex').value = primary;
  document.getElementById('fSecondaryColor').value = secondary;
  document.getElementById('fSecondaryColorHex').value = secondary;
  updateColorPreview(primary);
}

// Sync color hex text inputs with color pickers
document.getElementById('fPrimaryColor').addEventListener('input', function() {
  document.getElementById('fPrimaryColorHex').value = this.value;
  updateColorPreview(this.value);
});
document.getElementById('fSecondaryColor').addEventListener('input', function() {
  document.getElementById('fSecondaryColorHex').value = this.value;
});

// Preview selected local image file instantly
function previewSelectedLogo(event) {
  const file = event.target.files[0];
  if (!file) return;
  document.getElementById('logoFileNameDisplay').value = file.name;
  const reader = new FileReader();
  reader.onload = function(e) {
    document.getElementById('logoLivePreview').src = e.target.result;
  };
  reader.readAsDataURL(file);
}

// Reset form values to default state
function resetForm() {
  document.getElementById('settingsForm').reset();
  document.getElementById('nameLivePreview').innerText = defaultAppName;
  document.getElementById('logoLivePreview').src = defaultAppLogo;
  document.getElementById('logoFileNameDisplay').value = 'No file chosen';
  document.getElementById('logoFileInput').value = '';
  updateColorPreview(defaultPrimary);
}

// Submit via AJAX (multipart/form-data for image uploading)
async function submitSystemSettings(e) {
  e.preventDefault();
  // Sync color hex values into color pickers before submit
  const hexInput = document.getElementById('fPrimaryColorHex').value;
  if (/^#[0-9A-Fa-f]{6}$/.test(hexInput)) {
    document.getElementById('fPrimaryColor').value = hexInput;
  }
  const hexInput2 = document.getElementById('fSecondaryColorHex').value;
  if (/^#[0-9A-Fa-f]{6}$/.test(hexInput2)) {
    document.getElementById('fSecondaryColor').value = hexInput2;
  }

  const form = e.target;
  const formData = new FormData(form);
  showSpinner();
  try {
    const r = await fetch('ajax/settings_crud.php', { method: 'POST', body: formData });
    const res = await r.json();
    hideSpinner();
    if (res.success) {
      toastSuccess(res.message);
      setTimeout(() => { location.reload(); }, 1200);
    } else {
      toastError(res.message || 'Operation failed.');
    }
  } catch (err) {
    hideSpinner();
    toastError('Server upload failed.');
  }
}
</script>

<?php include 'includes/footer.php'; ?>
