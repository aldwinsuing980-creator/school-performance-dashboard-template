<?php
require_once __DIR__ . '/../config/session.php';
require_login();

// Strictly restricted to Admins only
if (!has_role('Admin')) {
    json_response(['success' => false, 'message' => 'Access denied. Administrator privileges required.'], 403);
}

$action = $_POST['action'] ?? '';

// Helper: convert hex color to "R, G, B" format
function hexToRgb(string $hex): string {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = hexdec(substr($hex,0,2));
    $g = hexdec(substr($hex,2,2));
    $b = hexdec(substr($hex,4,2));
    return "$r, $g, $b";
}

// Helper: upsert a key/value pair into system_settings
function upsertSetting(PDO $pdo, string $key, string $value): void {
    $stmt = $pdo->prepare("
        INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)
        ON DUPLICATE KEY UPDATE setting_value = ?
    ");
    $stmt->execute([$key, $value, $value]);
}

try {
    if ($action === 'save_settings') {
        $school_name = clean($_POST['school_name'] ?? '');
        if (empty($school_name)) {
            json_response(['success' => false, 'message' => 'School name cannot be empty.'], 400);
        }

        // Save all text/number fields
        upsertSetting($pdo, 'school_name',              $school_name);
        upsertSetting($pdo, 'school_tagline',           clean($_POST['school_tagline']           ?? ''));
        upsertSetting($pdo, 'school_address',           clean($_POST['school_address']            ?? ''));
        upsertSetting($pdo, 'school_division',          clean($_POST['school_division']           ?? ''));
        upsertSetting($pdo, 'school_id',                clean($_POST['school_id']                 ?? ''));
        upsertSetting($pdo, 'school_contact',           clean($_POST['school_contact']            ?? ''));
        
        $offered_post = $_POST['offered_levels'] ?? [];
        $offered_str = implode(',', $offered_post);
        if (empty($offered_str)) {
            json_response(['success' => false, 'message' => 'Please select at least one academic level offered.'], 400);
        }
        upsertSetting($pdo, 'offered_levels', $offered_str);

        upsertSetting($pdo, 'deped_jhs_class_size',     clean($_POST['deped_jhs_class_size']      ?? '45'));
        upsertSetting($pdo, 'deped_shs_class_size',     clean($_POST['deped_shs_class_size']      ?? '40'));
        upsertSetting($pdo, 'deped_jhs_teacher_ratio',  clean($_POST['deped_jhs_teacher_ratio']   ?? '35'));
        upsertSetting($pdo, 'deped_shs_teacher_ratio',  clean($_POST['deped_shs_teacher_ratio']   ?? '35'));

        // Save primary color + auto-compute RGB version
        $primary_color = clean($_POST['primary_color'] ?? '#1B2A6B');
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $primary_color)) {
            $primary_color = '#1B2A6B';
        }
        upsertSetting($pdo, 'primary_color',     $primary_color);
        upsertSetting($pdo, 'primary_color_rgb', hexToRgb($primary_color));

        // Save secondary color
        $secondary_color = clean($_POST['secondary_color'] ?? '#C9A227');
        if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $secondary_color)) {
            $secondary_color = '#C9A227';
        }
        upsertSetting($pdo, 'secondary_color', $secondary_color);

        $logo_uploaded = false;
        $logo_path = '';

        // Handle logo file upload securely if provided
        if (isset($_FILES['school_logo']) && $_FILES['school_logo']['error'] === UPLOAD_ERR_OK) {
            $file      = $_FILES['school_logo'];
            $file_name = $file['name'];
            $file_tmp  = $file['tmp_name'];
            $file_size = $file['size'];

            $allowed_exts  = ['png', 'jpg', 'jpeg'];
            $file_ext      = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            $finfo         = finfo_open(FILEINFO_MIME_TYPE);
            $mime_type     = finfo_file($finfo, $file_tmp);
            finfo_close($finfo);
            $allowed_mimes = ['image/png', 'image/jpeg', 'image/pjpeg'];

            if (!in_array($file_ext, $allowed_exts) || !in_array($mime_type, $allowed_mimes)) {
                json_response(['success' => false, 'message' => 'Invalid file format. Only PNG, JPG, and JPEG are allowed.'], 400);
            }
            if ($file_size > 2 * 1024 * 1024) {
                json_response(['success' => false, 'message' => 'File size exceeds 2MB limit.'], 400);
            }

            $upload_dir = __DIR__ . '/../uploads';
            if (!is_dir($upload_dir)) { mkdir($upload_dir, 0777, true); }

            $new_filename = 'logo_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $file_ext;
            $destination  = $upload_dir . '/' . $new_filename;

            if (move_uploaded_file($file_tmp, $destination)) {
                $logo_path = 'uploads/' . $new_filename;
                upsertSetting($pdo, 'school_logo', $logo_path);
                $logo_uploaded = true;
            } else {
                json_response(['success' => false, 'message' => 'Failed to save uploaded file.'], 500);
            }
        }

        $msg = 'System settings saved successfully.';
        if ($logo_uploaded) $msg = 'Branding profile and school logo successfully updated.';

        log_activity($pdo, current_user_id(), "Updated system settings (School Name: '{$school_name}')", 'Settings');
        json_response(['success' => true, 'message' => $msg, 'school_name' => $school_name, 'school_logo' => $logo_path]);

    } else {
        json_response(['success' => false, 'message' => 'Unknown action request.'], 400);
    }
} catch (Exception $e) {
    json_response(['success' => false, 'message' => 'Operation failed: ' . $e->getMessage()], 500);
}
?>
